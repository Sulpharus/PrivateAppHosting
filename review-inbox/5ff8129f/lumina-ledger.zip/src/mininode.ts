import { Group, Expense, Settlement, Member, ActivityLog } from './types';

// Declare global interface for window.MiniNode
declare global {
  interface Window {
    MiniNode?: any;
  }
}

export interface MiniNodeUser {
  id: string;
  username: string;
  isGuest: boolean;
  email?: string;
  avatarUrl?: string;
}

export const getMiniNode = () => {
  return typeof window !== 'undefined' ? window.MiniNode : undefined;
};

// Safe local storage helper for Bill the Splitter
const STORAGE_PREFIX = 'bts_data_';

const localStore = {
  getItem: <T = any>(key: string, defaultValue?: T): T => {
    try {
      const val = localStorage.getItem(`${STORAGE_PREFIX}${key}`);
      return val ? JSON.parse(val) : (defaultValue as T);
    } catch {
      return defaultValue as T;
    }
  },
  setItem: (key: string, value: any): void => {
    try {
      localStorage.setItem(`${STORAGE_PREFIX}${key}`, JSON.stringify(value));
    } catch (err) {
      console.warn('LocalStorage save failed:', err);
    }
  },
  removeItem: (key: string): void => {
    try {
      localStorage.removeItem(`${STORAGE_PREFIX}${key}`);
    } catch {}
  }
};

// Unique ID generator
export const generateId = (prefix: string) => {
  return `${prefix}_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
};

/**
 * Clean MiniNode API bridge:
 * Directly integrates with MiniNode when embedded in the Mininode host environment,
 * with standard browser persistence fallback.
 */
export const MiniNodeAPI = {
  isAvailable: (): boolean => {
    return !!getMiniNode();
  },

  // Auth & Profile Management (Real user from host or stored real user)
  auth: {
    getCurrentUser: (): MiniNodeUser => {
      const MN = getMiniNode();
      // Check for real host user
      if (MN?.user) {
        return {
          id: MN.user.id || 'user_host',
          username: MN.user.name || MN.user.username || 'User',
          isGuest: !!MN.user.isGuest,
          email: MN.user.email,
          avatarUrl: MN.user.avatarUrl
        };
      }
      if (MN?.auth?.currentUser) {
        const u = typeof MN.auth.currentUser === 'function' ? MN.auth.currentUser() : MN.auth.currentUser;
        if (u) {
          return {
            id: u.id || 'user_host',
            username: u.name || u.username || 'User',
            isGuest: !!u.isGuest,
            email: u.email,
            avatarUrl: u.avatarUrl
          };
        }
      }

      // Check stored user profile
      const stored = localStore.getItem<MiniNodeUser | null>('current_user', null);
      if (stored && stored.id && stored.username) {
        return stored;
      }

      // Default real user instance for this browser
      const defaultUser: MiniNodeUser = {
        id: 'user_me',
        username: 'You',
        isGuest: false
      };
      localStore.setItem('current_user', defaultUser);
      return defaultUser;
    },

    saveCurrentUser: (user: MiniNodeUser): void => {
      localStore.setItem('current_user', user);
    },

    requireLogin: async (): Promise<MiniNodeUser> => {
      return MiniNodeAPI.auth.getCurrentUser();
    },

    logout: async (): Promise<void> => {
      const MN = getMiniNode();
      if (MN?.auth?.logout) {
        try {
          await MN.auth.logout();
        } catch {}
      }
      localStore.removeItem('current_user');
    },

    onChange: (callback: (user: MiniNodeUser | null) => void): (() => void) => {
      const MN = getMiniNode();
      if (MN?.auth?.onChange) {
        return MN.auth.onChange(callback);
      }
      return () => {};
    }
  },

  // Database / Persistent Storage for Groups, Expenses, Settlements, Activities
  db: {
    listGroups: async (): Promise<Group[]> => {
      const MN = getMiniNode();
      if (MN?.db?.list) {
        try {
          const records = await MN.db.list('groups');
          if (records && Object.keys(records).length > 0) {
            return Object.values(records) as Group[];
          }
        } catch (err) {
          console.warn('MiniNode.db.list failed, using local storage:', err);
        }
      }
      return localStore.getItem<Group[]>('groups', []);
    },

    saveGroup: async (group: Group): Promise<void> => {
      const MN = getMiniNode();
      if (MN?.db?.set) {
        try {
          await MN.db.set('groups', group.id, group);
        } catch {}
      }
      const existing = localStore.getItem<Group[]>('groups', []);
      const index = existing.findIndex(g => g.id === group.id);
      if (index >= 0) {
        existing[index] = group;
      } else {
        existing.unshift(group);
      }
      localStore.setItem('groups', existing);
    },

    removeGroup: async (groupId: string): Promise<void> => {
      const MN = getMiniNode();
      if (MN?.db?.remove) {
        try {
          await MN.db.remove('groups', groupId);
        } catch {}
      }
      const existing = localStore.getItem<Group[]>('groups', []);
      localStore.setItem('groups', existing.filter(g => g.id !== groupId));

      // Also clean up expenses for this group
      const expenses = localStore.getItem<Expense[]>('expenses', []);
      localStore.setItem('expenses', expenses.filter(e => e.groupId !== groupId));
    },

    // Expenses persistence
    listExpenses: async (groupId?: string): Promise<Expense[]> => {
      const all = localStore.getItem<Expense[]>('expenses', []);
      return groupId ? all.filter(e => e.groupId === groupId) : all;
    },

    saveExpense: async (expense: Expense): Promise<void> => {
      const existing = localStore.getItem<Expense[]>('expenses', []);
      const index = existing.findIndex(e => e.id === expense.id);
      if (index >= 0) {
        existing[index] = expense;
      } else {
        existing.unshift(expense);
      }
      localStore.setItem('expenses', existing);
    },

    saveExpenses: async (expenses: Expense[]): Promise<void> => {
      localStore.setItem('expenses', expenses);
    },

    // Settlements persistence
    listSettlements: async (): Promise<Settlement[]> => {
      return localStore.getItem<Settlement[]>('settlements', []);
    },

    saveSettlements: async (settlements: Settlement[]): Promise<void> => {
      localStore.setItem('settlements', settlements);
    },

    // Activities persistence
    listActivities: async (): Promise<ActivityLog[]> => {
      return localStore.getItem<ActivityLog[]>('activities', []);
    },

    saveActivities: async (activities: ActivityLog[]): Promise<void> => {
      localStore.setItem('activities', activities);
    },

    // Members persistence
    listMembers: async (): Promise<Member[]> => {
      return localStore.getItem<Member[]>('members', []);
    },

    saveMembers: async (members: Member[]): Promise<void> => {
      localStore.setItem('members', members);
    },

    // Preferences (Payment Info, Currency, etc.)
    getPrefs: async (): Promise<any> => {
      const MN = getMiniNode();
      if (MN?.db?.getItem) {
        try {
          const prefs = await MN.db.getItem('prefs');
          if (prefs) return prefs;
        } catch {}
      }
      return localStore.getItem<any>('prefs', {});
    },

    setPrefs: async (prefs: any): Promise<void> => {
      const MN = getMiniNode();
      if (MN?.db?.setItem) {
        try {
          await MN.db.setItem('prefs', prefs);
        } catch {}
      }
      localStore.setItem('prefs', prefs);
    }
  },

  // Notification bridge
  notify: async (title: string, body: string, url: string = ''): Promise<void> => {
    const MN = getMiniNode();
    if (MN?.notify) {
      try {
        await MN.notify(title, body, url);
        return;
      } catch (err) {
        console.warn('MiniNode notify failed:', err);
      }
    }
    if (MN?.notifications?.notify) {
      try {
        await MN.notifications.notify(title, body, url);
        return;
      } catch {}
    }
    if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted') {
      try {
        new Notification(title, { body });
      } catch {}
    }
  },

  // Natural Language Expense Parser (clean regex-based, no fake mock names)
  ai: {
    parseExpense: async (sentence: string, memberNames: string[]): Promise<any> => {
      const MN = getMiniNode();
      if (MN?.ai?.generateOrConfigure) {
        try {
          const reply = await MN.ai.generateOrConfigure({
            system: 'Extract one expense as strict JSON: {"desc":string,"amount":number,"paidBy":string,"with":string[]}. ' +
                    'Names in "paidBy" and "with" MUST be chosen from this list: ' + memberNames.join(', ') + '. Reply with JSON only, no markdown blocks, no other text.',
            prompt: sentence,
          });
          
          let cleanReply = reply.trim();
          if (cleanReply.startsWith('```')) {
            cleanReply = cleanReply.replace(/^```json|```$/g, '').trim();
          }
          return JSON.parse(cleanReply);
        } catch (err) {
          console.warn('MiniNode AI parsing failed, falling back to local extractor:', err);
        }
      }
      
      // Clean local heuristic parser
      return parseExpenseSentenceLocally(sentence, memberNames);
    }
  }
};

/**
 * Intelligent local parsing without hardcoded mocks
 */
function parseExpenseSentenceLocally(sentence: string, memberNames: string[]): any {
  const lowercase = sentence.toLowerCase();

  // Extract amount (€ or $ or plain numbers)
  const amountMatch = sentence.match(/(?:€|\$|EUR|eur)?\s*(\d+(?:[.,]\d{1,2})?)\s*(?:€|\$|EUR|eur)?/);
  const amount = amountMatch ? parseFloat(amountMatch[1].replace(',', '.')) : 0;

  // Extract payer from actual group member names
  let paidBy = memberNames[0] || 'You';
  for (const name of memberNames) {
    if (name && lowercase.includes(name.toLowerCase())) {
      paidBy = name;
      break;
    }
  }

  // Extract description by removing numbers, currency symbols, and member names
  let desc = sentence;
  // Remove numbers
  desc = desc.replace(/(?:€|\$|EUR|eur)?\s*\d+(?:[.,]\d{1,2})?\s*(?:€|\$|EUR|eur)?/gi, '');
  // Remove keywords like "paid", "für", "for", "bought", "bezahlt", "mit", "with"
  desc = desc.replace(/\b(paid|bought|für|for|bezahlt|mit|with|by|von)\b/gi, ' ');
  // Remove member names from description
  memberNames.forEach(n => {
    if (n) desc = desc.replace(new RegExp(n, 'gi'), ' ');
  });
  desc = desc.replace(/\s+/g, ' ').trim();

  // Extract participants
  const withMembers = memberNames.filter(name => 
    name && lowercase.includes(name.toLowerCase()) && name.toLowerCase() !== paidBy.toLowerCase()
  );

  return {
    desc: desc || 'Expense',
    amount: amount > 0 ? amount : 0,
    paidBy,
    with: withMembers.length > 0 ? withMembers : memberNames
  };
}
