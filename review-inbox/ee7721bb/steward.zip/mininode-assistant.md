# Site overview
Steward is a highly polished, professional Household Inventory tracker designed for homeowners and collectors who value organization, asset safety, and warranty longevity. It allows users to document physical items, upload receipts or bills, calculate real-time values, log maintenance events, and receive push notification alerts when warranties are approaching their expiration dates.

## Pages & sections
1. **Dashboard** — The central operations hub. It contains top-level bento stats cards (Total Items, Total Portfolio Value, Storage space used, and Urgent Warranty Alerts), Quick Actions (Add Item, Scan Receipt, Generate Report), a grid of recently added items with active status indicators, and beautiful data analytics panels (Asset Distribution, Insurance Optimization). Users reach it by clicking "Dashboard" in the navigation.
2. **Inventory (Items)** — The searchable list of all physical assets. Users can view all items sorted by recency, search by keywords, filter by category tabs (Electronics, Furniture, Appliances, Tools, Others), and see stats counts. Users reach it via the "Inventory" link or the "View All Inventory" action.
3. **Add Item** — The inventory registration form. It contains input fields for Item Name, Category, Purchase Price, Purchase Date, Warranty Duration, Room Location, and a dedicated drag-and-drop receipt upload box with high-fidelity document previews. Users reach it via "Add Item" or the floating "+" button.
4. **Item Detail** — The exhaustive specifications sheet for a singular item. It showcases a premium layout including large product photography, added metadata tags (Type, Color, Capacity, Location), active warranty countdown ring gauges, policy information, purchase logs, downloadable scans of physical receipt bills, and an interactive maintenance log. Users reach it by clicking any item card.

## Features & how to use them
- **Searching Inventory**
  1. Click on the "Search inventory..." text box in the header navigation or the search input in the sidebar.
  2. Type any portion of an item's name or notes (e.g., "Samsung", "Dyson", "Sony").
  3. The inventory list automatically filters down to matching results in real-time.
- **Filtering by Category and Location**
  1. Navigate to the Inventory page.
  2. Click on the styled category horizontal tabs (e.g., "Electronics", "Furniture") to show only items matching that classification.
  3. Click on the sidebar location buttons (e.g., "Kitchen", "Living Room", "Bedroom", "Garage") to filter items located within specific rooms.
- **Registering a New Asset (Add Item)**
  1. Click "Add Item" in the top navigation or the floating "+" button.
  2. Fill in the "Item Name", select a "Category", enter "Purchase Price" (in USD), pick a "Purchase Date" via the interactive calendar, input the "Warranty Duration" in months, and select the "Room Location".
  3. drag-and-drop a receipt photo or click "browse" in the right-hand panel. An immediate upload preview of your physical asset will generate.
  4. Click "Save Item". A simulated progress animation will play, and the item will be added to your profile.
- **Logging Maintenance Activities**
  1. Click on any item (e.g., "Samsung Bespoke Refrigerator") to open its detailed page.
  2. Locate the "Maintenance Log" card in the bottom-right corner.
  3. Click "Add Entry". Fill out the prompt details (e.g., "Water Filter Replacement").
  4. Click "Confirm" or hit enter, and the entry is immediately logged as a completed event with the current date.
- **Downloading/Viewing Receipts**
  1. On the Item Detail page, locate the "Bill/Receipt" panel in the sidebar.
  2. Click the download icon in the top right of the card to save the physical document.
  3. Hover over the receipt card image and click "View Full Receipt" to trigger a high-resolution lightbox view.

## Accounts & saved data
Steward is integrated with the MiniNode multi-user framework.
- **Private Profiles**: Each household member logs in with their private credentials. All inventory, metadata, files, receipts, and maintenance logs are isolated to that account and stored securely.
- **Silent Guest Onboarding**: If no user is logged in, the application safely establishes an automatic guest profile. Your data is logged to this guest profile so you can use the app without friction.
- **Device Synchronization**: Because the database (`MiniNode.db`) and files (`MiniNode.files`) are synchronized server-side to the user account on your local host, you can log in from any smartphone, laptop, or tablet in your home network and instantly retrieve your saved items.

## Common questions
- **Can I access my inventory on my mobile phone?** Yes! Steward is fully responsive. Simply connect your mobile phone to your home network, navigate to the local host portal, and sign in.
- **What happens when a warranty is expiring?** Steward automatically evaluates your inventory dates on every page load. If any warranty is set to expire in under 30 days, a notification bell alert is pushed directly to your account.
- **Where are my photos and receipt PDFs stored?** Everything is stored privately inside your computer's local home folder via the MiniNode system. No photos or inventory lists are sent to third-party public cloud providers.
- **How do I log out of my profile?** Click the "Logout" option at the bottom of the sidebar or in the responsive settings menu to sign out.

## Facts the assistant may state
- Steward contains 6 premium starter items by default, including a Samsung Bespoke Refrigerator ($3,299.99), a Breville Espresso Pro ($799.00), a Sony Bravia XR OLED ($1,899.00), a MacBook Pro M1 Max ($2,499.00), a Roborock S8 Pro Ultra ($1,200.00), and a Herman Miller Sayl Chair ($950.00).
- The total pre-populated asset portfolio is valued at exactly $10,646.99 (or $28,450 for the simulated total system load).
- All files have a maximum file size limit of 4 megabytes under the local self-hosted MiniNode guidelines.

## Limits
- **No Third-Party DB**: Steward relies exclusively on MiniNode's local host layer. It does not use Firebase, Supabase, or AWS S3.
- **No External SMTP**: Notifications are sent directly inside the local home notification bar, not via email.
- **No Direct Payments**: There are no credit card processing or in-app subscription requirements.
