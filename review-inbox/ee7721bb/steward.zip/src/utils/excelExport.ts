import ExcelJS from "exceljs";
import { InventoryItem } from "../types";

export async function exportToExcel(items: InventoryItem[], language: string, insuranceLimit: number) {
  const workbook = new ExcelJS.Workbook();
  workbook.creator = "HomePal";
  workbook.lastModifiedBy = "HomePal";
  workbook.created = new Date();
  workbook.modified = new Date();

  const isDe = language === "de";

  // Define Styles & Palettes (Primary: Deep Slate / Navy `#1E293B`, Accent: Emerald `#059669`)
  const colors = {
    primaryHeader: "1E293B",
    primaryHeaderFont: "FFFFFF",
    accentEmerald: "059669",
    accentEmeraldLight: "ECFDF5",
    zebraBg: "F8FAFC",
    cardBg: "F1F5F9",
    borderLight: "E2E8F0",
    textDark: "0F172A",
    textMuted: "64748B",
    warningRedLight: "FEF2F2",
    warningRedBorder: "FCA5A5",
    warningRedText: "991B1B",
    successGreenLight: "F0FDF4",
    successGreenBorder: "BBF7D0",
    successGreenText: "166534"
  };

  // ==========================================
  // SHEET 1: DASHBOARD
  // ==========================================
  const dashSheet = workbook.addWorksheet(isDe ? "Übersicht" : "Dashboard", {
    views: [{ showGridLines: true }]
  });

  // Column definitions for spacing
  dashSheet.columns = [
    { width: 4 },   // A
    { width: 28 },  // B
    { width: 28 },  // C
    { width: 28 },  // D
    { width: 4 }    // E
  ];

  // Title Row
  dashSheet.mergeCells("B2:D2");
  const titleCell = dashSheet.getCell("B2");
  titleCell.value = isDe ? "HOMEPAL - DIGITALE VERMÖGENSÜBERSICHT" : "HOMEPAL - DIGITAL HOUSEHOLD ASSET REPORT";
  titleCell.font = { name: "Arial", size: 16, bold: true, color: { argb: colors.textDark } };
  titleCell.alignment = { vertical: "middle", horizontal: "left" };
  dashSheet.getRow(2).height = 40;

  // Horizontal Accent Line under Title
  dashSheet.mergeCells("B3:D3");
  const lineCell = dashSheet.getCell("B3");
  lineCell.fill = {
    type: "pattern",
    pattern: "solid",
    fgColor: { argb: colors.accentEmerald }
  };
  dashSheet.getRow(3).height = 4;

  // Subtitle/Date
  dashSheet.mergeCells("B4:D4");
  const subCell = dashSheet.getCell("B4");
  const dateStr = new Date().toLocaleDateString(isDe ? "de-DE" : "en-US", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric"
  });
  subCell.value = (isDe ? "Generiert am: " : "Generated on: ") + dateStr;
  subCell.font = { name: "Arial", size: 9, italic: true, color: { argb: colors.textMuted } };
  subCell.alignment = { vertical: "middle", horizontal: "left" };
  dashSheet.getRow(4).height = 24;

  // KPI Card Headers (Row 6)
  const kpiHeaders = [
    { cell: "B6", val: isDe ? "GESAMTWERT PORTFOLIO" : "TOTAL INVENTORY VALUE" },
    { cell: "C6", val: isDe ? "AKTIVE INVENTAR-ARTIKEL" : "TOTAL RECORDED ITEMS" },
    { cell: "D6", val: isDe ? "VERSICHERUNGSSUMME (LIMIT)" : "INSURANCE POLICY LIMIT" }
  ];

  kpiHeaders.forEach(k => {
    const cell = dashSheet.getCell(k.cell);
    cell.value = k.val;
    cell.font = { name: "Arial", size: 9, bold: true, color: { argb: colors.primaryHeaderFont } };
    cell.alignment = { horizontal: "center", vertical: "middle" };
    cell.fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: colors.primaryHeader }
    };
  });
  dashSheet.getRow(6).height = 24;

  // KPI Card Values (Row 7)
  // 1. Total Portfolio Value using SUM formula from Inventory Sheet
  const valCell1 = dashSheet.getCell("B7");
  valCell1.value = {
    formula: `SUM('${isDe ? "Inventar" : "Inventory"}'!E4:E1000)`,
    result: items.reduce((acc, curr) => acc + (Number(curr.purchasePrice) || 0), 0)
  };
  valCell1.numFmt = "[$€-2] #,##0.00";
  valCell1.font = { name: "Arial", size: 16, bold: true, color: { argb: colors.textDark } };
  valCell1.alignment = { horizontal: "center", vertical: "middle" };
  valCell1.fill = { type: "pattern", pattern: "solid", fgColor: { argb: colors.cardBg } };

  // 2. Count of active items using COUNTA formula
  const valCell2 = dashSheet.getCell("C7");
  valCell2.value = {
    formula: `COUNTA('${isDe ? "Inventar" : "Inventory"}'!A4:A1000)`,
    result: items.length
  };
  valCell2.font = { name: "Arial", size: 16, bold: true, color: { argb: colors.textDark } };
  valCell2.alignment = { horizontal: "center", vertical: "middle" };
  valCell2.fill = { type: "pattern", pattern: "solid", fgColor: { argb: colors.cardBg } };

  // 3. Insurance policy limit (hard value but editable in Excel!)
  const valCell3 = dashSheet.getCell("D7");
  valCell3.value = insuranceLimit;
  valCell3.numFmt = "[$€-2] #,##0.00";
  valCell3.font = { name: "Arial", size: 16, bold: true, color: { argb: colors.textDark } };
  valCell3.alignment = { horizontal: "center", vertical: "middle" };
  valCell3.fill = { type: "pattern", pattern: "solid", fgColor: { argb: colors.cardBg } };

  // Border formatting for KPI values
  ["B7", "C7", "D7"].forEach(c => {
    dashSheet.getCell(c).border = {
      left: { style: "thin", color: { argb: colors.borderLight } },
      right: { style: "thin", color: { argb: colors.borderLight } },
      bottom: { style: "medium", color: { argb: colors.primaryHeader } }
    };
  });
  dashSheet.getRow(7).height = 45;

  // Status Check Headline (Row 9)
  dashSheet.mergeCells("B9:D9");
  const statHeadline = dashSheet.getCell("B9");
  statHeadline.value = isDe ? "VERSICHERUNGSDECKUNG & ABSICHERUNGSANALYSE" : "INSURANCE COVERAGE & FIDUCIARY ANALYTICS";
  statHeadline.font = { name: "Arial", size: 11, bold: true, color: { argb: colors.textDark } };
  statHeadline.alignment = { vertical: "bottom", horizontal: "left" };
  dashSheet.getRow(9).height = 30;

  // Status Check Value box (Row 10 & 11 merged)
  dashSheet.mergeCells("B10:D11");
  const statBox = dashSheet.getCell("B10");
  // Formula checking if sum is greater than limit
  statBox.value = {
    formula: `IF(B7>D7, "${
      isDe 
        ? "⚠️ UNTERVERSICHERUNG ERKANNT: Ihr Haushaltswert übersteigt Ihr Versicherungslimit! Erwägen Sie eine Erhöhung der Deckung." 
        : "⚠️ UNDERINSURANCE DETECTED: Total assets exceed your insurance limit! Consider increasing your policy coverage."
    }", "${
      isDe 
        ? "✅ VOLLSTÄNDIG DECKUNGSKONFORM: Ihr Haushaltsvermögen ist optimal durch Ihr aktuelles Versicherungslimit abgesichert." 
        : "✅ COMPLIANCE COVERED: Your household assets are fully protected within your active coverage limits."
    }")`,
    result: items.reduce((acc, curr) => acc + (Number(curr.purchasePrice) || 0), 0) > insuranceLimit
      ? (isDe ? "⚠️ UNTERVERSICHERUNG ERKANNT: Ihr Haushaltswert übersteigt Ihr Versicherungslimit!" : "⚠️ UNDERINSURANCE DETECTED: Total assets exceed your insurance limit!")
      : (isDe ? "✅ VOLLSTÄNDIG DECKUNGSKONFORM: Optimal abgesichert." : "✅ COMPLIANCE COVERED: Fully protected.")
  };
  statBox.font = { name: "Arial", size: 10, bold: true };
  statBox.alignment = { horizontal: "center", vertical: "middle", wrapText: true };

  // Set conditional borders/colors for status bar programmatically in excel or initially format with dynamic Excel formula
  // Since full conditional formatting via formulas in exceljs is verbose, we style based on the current live state
  const isCurrentlyUnderinsured = items.reduce((acc, curr) => acc + (Number(curr.purchasePrice) || 0), 0) > insuranceLimit;
  if (isCurrentlyUnderinsured) {
    statBox.fill = { type: "pattern", pattern: "solid", fgColor: { argb: colors.warningRedLight } };
    statBox.border = {
      top: { style: "thin", color: { argb: colors.warningRedBorder } },
      left: { style: "thin", color: { argb: colors.warningRedBorder } },
      bottom: { style: "thin", color: { argb: colors.warningRedBorder } },
      right: { style: "thin", color: { argb: colors.warningRedBorder } }
    };
    statBox.font = { name: "Arial", size: 10, bold: true, color: { argb: colors.warningRedText } };
  } else {
    statBox.fill = { type: "pattern", pattern: "solid", fgColor: { argb: colors.successGreenLight } };
    statBox.border = {
      top: { style: "thin", color: { argb: colors.successGreenBorder } },
      left: { style: "thin", color: { argb: colors.successGreenBorder } },
      bottom: { style: "thin", color: { argb: colors.successGreenBorder } },
      right: { style: "thin", color: { argb: colors.successGreenBorder } }
    };
    statBox.font = { name: "Arial", size: 10, bold: true, color: { argb: colors.successGreenText } };
  }
  dashSheet.getRow(10).height = 25;
  dashSheet.getRow(11).height = 25;

  // Instructions Box (Row 13 to 17)
  dashSheet.mergeCells("B13:D16");
  const instrCell = dashSheet.getCell("B13");
  instrCell.value = isDe
    ? "ANLEITUNG FÜR EXCEL:\n" +
      "1. Fügen Sie neue Gegenstände direkt in die Tabelle '" + "Inventar" + "' ein.\n" +
      "2. Tragen Sie Namen, Zimmer, Kaufdatum, Wert und Ablaufdaten ein.\n" +
      "3. Dieses Dashboard liest automatisch die Summen und berechnet Ihre Deckungssumme in Echtzeit neu!\n" +
      "4. Sie können Ihr Versicherungslimit in Zelle D7 anpassen, um verschiedene Tarife zu simulieren."
    : "INSTRUCTIONS FOR EXCEL USE:\n" +
      "1. Add new items directly in the '" + "Inventory" + "' worksheet tab.\n" +
      "2. Enter Name, Room, Category, Purchase Date, Price, and Warranty/Maintenance dates.\n" +
      "3. This Dashboard automatically reads sums and computes coverage compliance in real-time!\n" +
      "4. Feel free to modify your Policy Limit in cell D7 to simulate different coverage packages.";
  instrCell.font = { name: "Arial", size: 10, color: { argb: colors.textDark } };
  instrCell.alignment = { vertical: "top", horizontal: "left", wrapText: true };
  instrCell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: colors.zebraBg } };
  instrCell.border = {
    top: { style: "dashed", color: { argb: colors.borderLight } },
    left: { style: "dashed", color: { argb: colors.borderLight } },
    bottom: { style: "dashed", color: { argb: colors.borderLight } },
    right: { style: "dashed", color: { argb: colors.borderLight } }
  };
  dashSheet.getRow(13).height = 25;
  dashSheet.getRow(14).height = 25;
  dashSheet.getRow(15).height = 25;
  dashSheet.getRow(16).height = 25;


  // ==========================================
  // SHEET 2: INVENTORY DETAIL LOG
  // ==========================================
  const logSheet = workbook.addWorksheet(isDe ? "Inventar" : "Inventory", {
    views: [{ showGridLines: true }]
  });

  // Setup headers
  const headers = [
    { key: "name", header: isDe ? "Name des Gegenstands" : "Item Name", width: 30 },
    { key: "room", header: isDe ? "Raum / Standort" : "Room / Location", width: 18 },
    { key: "category", header: isDe ? "Kategorie" : "Category", width: 18 },
    { key: "date", header: isDe ? "Kaufdatum" : "Purchase Date", width: 15 },
    { key: "price", header: isDe ? "Wert / Preis (€)" : "Asset Value (€)", width: 18 },
    { key: "warranty", header: isDe ? "Garantie bis" : "Warranty Expiration", width: 18 },
    { key: "maintenance", header: isDe ? "Nächste Wartung" : "Next Maintenance", width: 18 },
    { key: "serial", header: isDe ? "Seriennummer" : "Serial Number", width: 18 },
    { key: "notes", header: isDe ? "Beschreibung / Notizen" : "Notes / Descriptions", width: 35 }
  ];

  logSheet.columns = headers.map(h => ({
    header: h.header,
    key: h.key,
    width: h.width
  }));

  // Style the Header Row
  const headerRow = logSheet.getRow(1);
  headerRow.height = 30;
  headerRow.eachCell((cell) => {
    cell.font = { name: "Arial", size: 10, bold: true, color: { argb: colors.primaryHeaderFont } };
    cell.fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: colors.primaryHeader }
    };
    cell.alignment = { vertical: "middle", horizontal: "left" };
    cell.border = {
      bottom: { style: "medium", color: { argb: colors.accentEmerald } }
    };
  });

  // Populate actual items starting from Row 4 (to leave an empty buffer row)
  // Shift rows downwards by 2 rows so headers start at row 3
  logSheet.spliceRows(1, 0, [], []); // Add two empty rows at top
  
  // Re-write headers at Row 3
  headers.forEach((h, idx) => {
    const cell = logSheet.getCell(3, idx + 1);
    cell.value = h.header;
    cell.font = { name: "Arial", size: 10, bold: true, color: { argb: colors.primaryHeaderFont } };
    cell.fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: colors.primaryHeader }
    };
    cell.alignment = { vertical: "middle", horizontal: "left" };
    cell.border = {
      bottom: { style: "medium", color: { argb: colors.accentEmerald } }
    };
  });
  logSheet.getRow(3).height = 30;

  // Let's clear row 1 & 2 cells and write sheet title at B1
  logSheet.mergeCells("A1:I1");
  const logTitle = logSheet.getCell("A1");
  logTitle.value = isDe ? "HAUSHALTSINVENTAR-DATENBLATT" : "HOUSEHOLD ASSET MASTER LEDGER";
  logTitle.font = { name: "Arial", size: 12, bold: true, color: { argb: "FFFFFF" } };
  logTitle.fill = {
    type: "pattern",
    pattern: "solid",
    fgColor: { argb: colors.accentEmerald }
  };
  logTitle.alignment = { vertical: "middle", horizontal: "center" };
  logSheet.getRow(1).height = 26;
  logSheet.getRow(2).height = 10; // spacing row

  // Now, populate items starting from row 4
  items.forEach((item, index) => {
    const rowNum = 4 + index;
    const rowData = [
      item.name,
      item.location,
      item.category,
      item.purchaseDate || "",
      Number(item.purchasePrice) || 0,
      item.warrantyExpiry || "",
      item.nextMaintenanceDate || "",
      item.serialNumber || "",
      item.notes || ""
    ];

    logSheet.addRow(rowData);
    const row = logSheet.getRow(rowNum);
    row.height = 22;

    // Apply alternate zebra-striping
    const bgToUse = index % 2 === 1 ? colors.zebraBg : "FFFFFF";

    row.eachCell({ includeEmpty: true }, (cell, colNumber) => {
      cell.font = { name: "Arial", size: 10, color: { argb: colors.textDark } };
      cell.fill = {
        type: "pattern",
        pattern: "solid",
        fgColor: { argb: bgToUse }
      };
      cell.border = {
        bottom: { style: "thin", color: { argb: colors.borderLight } },
        left: { style: "thin", color: { argb: colors.borderLight } },
        right: { style: "thin", color: { argb: colors.borderLight } }
      };

      // Alignment & formatting rules per column
      if (colNumber === 4 || colNumber === 6 || colNumber === 7) {
        // Dates
        cell.alignment = { horizontal: "center", vertical: "middle" };
      } else if (colNumber === 5) {
        // Value/Price
        cell.numFmt = "[$€-2] #,##0.00";
        cell.alignment = { horizontal: "right", vertical: "middle" };
      } else {
        // Text columns
        cell.alignment = { horizontal: "left", vertical: "middle" };
      }
    });
  });

  // Append a Total Summary Row at the bottom of the table
  const totalRowNum = 4 + items.length;
  logSheet.getRow(totalRowNum).height = 26;

  // Let's set labels
  const labelCell = logSheet.getCell(totalRowNum, 1);
  labelCell.value = isDe ? "Gesamtportfolio-Wert (Berechnet)" : "Total Calculated Portfolio Value";
  labelCell.font = { name: "Arial", size: 10, bold: true, color: { argb: colors.primaryHeaderFont } };
  labelCell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: colors.primaryHeader } };
  labelCell.alignment = { horizontal: "left", vertical: "middle" };

  // Fill in other label cells in total row with primary header background
  for (let c = 2; c <= 9; c++) {
    if (c !== 5) {
      const cell = logSheet.getCell(totalRowNum, c);
      cell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: colors.primaryHeader } };
      cell.border = { top: { style: "medium", color: { argb: colors.accentEmerald } } };
    }
  }

  // Value Formula Cell in Column 5
  const sumCell = logSheet.getCell(totalRowNum, 5);
  sumCell.value = {
    formula: `SUM(E4:E${totalRowNum - 1})`,
    result: items.reduce((acc, curr) => acc + (Number(curr.purchasePrice) || 0), 0)
  };
  sumCell.numFmt = "[$€-2] #,##0.00";
  sumCell.font = { name: "Arial", size: 11, bold: true, color: { argb: colors.primaryHeaderFont } };
  sumCell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: colors.accentEmerald } };
  sumCell.alignment = { horizontal: "right", vertical: "middle" };
  sumCell.border = {
    top: { style: "medium", color: { argb: colors.accentEmerald } },
    bottom: { style: "double", color: { argb: "000000" } }
  };

  // Generate Excel File download blob
  const buffer = await workbook.xlsx.writeBuffer();
  const blob = new Blob([buffer], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
  const url = window.URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = `HomePal_Inventory_${new Date().toISOString().split("T")[0]}.xlsx`;
  anchor.click();
  window.URL.revokeObjectURL(url);
}
