/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { InventoryItem, MiniNodeUser, MiniNodeNotification } from "./types";

// Clean slate - No exemplary data
export const STARTER_ITEMS: InventoryItem[] = [];

// Fallback Implementation using localStorage for standalone preview
class LocalMiniNodeShim {
  private listeners: ((user: MiniNodeUser | null) => void)[] = [];
  private currentUserObj: MiniNodeUser | null = null;
  private storagePrefix = "haushalt_mn_";

  constructor() {
    // Clear any previous steward dummy data if present to ensure a clean slate
    try {
      localStorage.removeItem("steward_mn_db_items");
      localStorage.removeItem("steward_mn_notifications");
      localStorage.removeItem("steward_mn_kv_rooms_list");
      localStorage.removeItem("steward_mn_currentUser");
    } catch (e) {
      // ignore
    }

    const cached = localStorage.getItem(this.storagePrefix + "currentUser");
    if (cached) {
      this.currentUserObj = JSON.parse(cached);
    } else {
      this.currentUserObj = { id: "user-default", username: "Ich", isGuest: true };
      localStorage.setItem(this.storagePrefix + "currentUser", JSON.stringify(this.currentUserObj));
    }
    this.initializeDefaultData();
  }

  private initializeDefaultData() {
    const key = this.storagePrefix + "db_items";
    const data = localStorage.getItem(key);
    if (!data) {
      localStorage.setItem(key, JSON.stringify({}));
    }

    // Default notifications: empty
    const notifKey = this.storagePrefix + "notifications";
    if (!localStorage.getItem(notifKey)) {
      localStorage.setItem(notifKey, JSON.stringify([]));
    }
  }

  // Auth Methods
  auth = {
    currentUser: (): MiniNodeUser | null => {
      return this.currentUserObj;
    },

    me: async (): Promise<MiniNodeUser | null> => {
      return this.currentUserObj;
    },

    login: async (username: string, pass: string): Promise<MiniNodeUser> => {
      if (pass.length < 4) {
        throw new Error("Password must be at least 4 characters.");
      }
      const user = { id: "user-" + username.toLowerCase(), username, isGuest: false };
      this.currentUserObj = user;
      localStorage.setItem(this.storagePrefix + "currentUser", JSON.stringify(user));
      this.notifyListeners();
      return user;
    },

    signup: async (username: string, pass: string): Promise<MiniNodeUser> => {
      if (pass.length < 4) {
        throw new Error("Password must be at least 4 characters.");
      }
      const user = { id: "user-" + username.toLowerCase(), username, isGuest: false };
      this.currentUserObj = user;
      localStorage.setItem(this.storagePrefix + "currentUser", JSON.stringify(user));
      this.notifyListeners();
      return user;
    },

    guest: async (name?: string): Promise<MiniNodeUser> => {
      const user = { id: "user-guest-" + Date.now(), username: name || "JD", isGuest: true };
      this.currentUserObj = user;
      localStorage.setItem(this.storagePrefix + "currentUser", JSON.stringify(user));
      this.notifyListeners();
      return user;
    },

    logout: async (): Promise<void> => {
      this.currentUserObj = null;
      localStorage.removeItem(this.storagePrefix + "currentUser");
      this.notifyListeners();
    },

    onChange: (cb: (user: MiniNodeUser | null) => void): (() => void) => {
      this.listeners.push(cb);
      cb(this.currentUserObj);
      return () => {
        this.listeners = this.listeners.filter(l => l !== cb);
      };
    },

    requireLogin: async (): Promise<MiniNodeUser> => {
      if (this.currentUserObj) {
        return this.currentUserObj;
      }
      // Return a temporary user for demo inside preview
      const fallbackUser = { id: "user-default", username: "JD", isGuest: true };
      this.currentUserObj = fallbackUser;
      localStorage.setItem(this.storagePrefix + "currentUser", JSON.stringify(fallbackUser));
      this.notifyListeners();
      return fallbackUser;
    }
  };

  private notifyListeners() {
    this.listeners.forEach(cb => cb(this.currentUserObj));
  }

  // Database Methods
  db = {
    list: async (collection: string): Promise<Record<string, any>> => {
      const key = this.storagePrefix + "db_" + collection;
      const data = localStorage.getItem(key);
      return data ? JSON.parse(data) : {};
    },

    get: async (collection: string, itemKey: string): Promise<any | undefined> => {
      const key = this.storagePrefix + "db_" + collection;
      const data = localStorage.getItem(key);
      if (!data) return undefined;
      const map = JSON.parse(data);
      return map[itemKey];
    },

    set: async (collection: string, itemKey: string, value: any): Promise<void> => {
      const key = this.storagePrefix + "db_" + collection;
      const data = localStorage.getItem(key);
      const map = data ? JSON.parse(data) : {};
      map[itemKey] = value;
      localStorage.setItem(key, JSON.stringify(map));
    },

    remove: async (collection: string, itemKey: string): Promise<void> => {
      const key = this.storagePrefix + "db_" + collection;
      const data = localStorage.getItem(key);
      if (data) {
        const map = JSON.parse(data);
        delete map[itemKey];
        localStorage.setItem(key, JSON.stringify(map));
      }
    },

    // Convenience Key/Value helpers
    getItem: async (key: string): Promise<any | undefined> => {
      const data = localStorage.getItem(this.storagePrefix + "kv_" + key);
      return data ? JSON.parse(data) : undefined;
    },

    setItem: async (key: string, value: any): Promise<void> => {
      localStorage.setItem(this.storagePrefix + "kv_" + key, JSON.stringify(value));
    },

    removeItem: async (key: string): Promise<void> => {
      localStorage.removeItem(this.storagePrefix + "kv_" + key);
    }
  };

  // Files Mock Methods
  files = {
    upload: async (blob: Blob | File, options?: { name?: string; type?: string }): Promise<any> => {
      const name = options?.name || (blob as File).name || "uploaded_file";
      const type = options?.type || blob.type || "application/octet-stream";
      
      return new Promise((resolve) => {
        const reader = new FileReader();
        reader.onloadend = () => {
          const url = reader.result as string;
          const fileRecord = {
            id: "file-" + Date.now(),
            name,
            type,
            size: blob.size,
            url,
            created: Date.now()
          };
          
          const cachedFiles = localStorage.getItem(this.storagePrefix + "files") || "[]";
          const filesArray = JSON.parse(cachedFiles);
          filesArray.push(fileRecord);
          localStorage.setItem(this.storagePrefix + "files", JSON.stringify(filesArray));
          
          resolve(fileRecord);
        };
        reader.readAsDataURL(blob);
      });
    },

    list: async (): Promise<any[]> => {
      const cachedFiles = localStorage.getItem(this.storagePrefix + "files") || "[]";
      return JSON.parse(cachedFiles);
    },

    delete: async (id: string): Promise<void> => {
      const cachedFiles = localStorage.getItem(this.storagePrefix + "files") || "[]";
      const filesArray = JSON.parse(cachedFiles).filter((f: any) => f.id !== id);
      localStorage.setItem(this.storagePrefix + "files", JSON.stringify(filesArray));
    }
  };

  // Notifications
  notify = async (title: string, body: string, url?: string): Promise<void> => {
    const notificationsKey = this.storagePrefix + "notifications";
    const cached = localStorage.getItem(notificationsKey) || "[]";
    const notifs: MiniNodeNotification[] = JSON.parse(cached);
    
    // Check if duplicate notification for warranty exists to avoid alert-spamming
    const isDuplicate = notifs.some(n => n.title === title && Date.now() - n.timestamp < 12 * 60 * 60 * 1000);
    if (isDuplicate) return;

    notifs.unshift({
      id: "notif-" + Date.now() + "-" + Math.random().toString(36).slice(2, 5),
      title,
      body,
      url,
      timestamp: Date.now(),
      read: false
    });
    localStorage.setItem(notificationsKey, JSON.stringify(notifs));
  };
}

// Global Singleton Client
class MiniNodeClient {
  private shim: LocalMiniNodeShim | null = null;

  private get mn() {
    // Check if standard native window.MiniNode is present, if so, return it
    const nativeMN = (window as any).MiniNode;
    if (nativeMN && nativeMN.auth && nativeMN.db && nativeMN.files) {
      return nativeMN;
    }
    // Fallback to our high-fidelity emulated shim
    if (!this.shim) {
      this.shim = new LocalMiniNodeShim();
    }
    return this.shim;
  }

  public isStandalone(): boolean {
    return !((window as any).MiniNode && (window as any).MiniNode.db);
  }

  // Auth Operations
  public async requireLogin(): Promise<MiniNodeUser> {
    return this.mn.auth.requireLogin();
  }

  public currentUser(): MiniNodeUser | null {
    return this.mn.auth.currentUser();
  }

  public authOnChange(cb: (user: MiniNodeUser | null) => void): (() => void) {
    return this.mn.auth.onChange(cb);
  }

  public async login(user: string, pass: string): Promise<MiniNodeUser> {
    return this.mn.auth.login(user, pass);
  }

  public async signup(user: string, pass: string): Promise<MiniNodeUser> {
    return this.mn.auth.signup(user, pass);
  }

  public async guest(name?: string): Promise<MiniNodeUser> {
    return this.mn.auth.guest(name);
  }

  public async logout(): Promise<void> {
    return this.mn.auth.logout();
  }

  // Db Operations
  public async dbList(collection: string): Promise<Record<string, any>> {
    return this.mn.db.list(collection);
  }

  public async dbGet(collection: string, key: string): Promise<any> {
    return this.mn.db.get(collection, key);
  }

  public async dbSet(collection: string, key: string, value: any): Promise<void> {
    return this.mn.db.set(collection, key, value);
  }

  public async dbRemove(collection: string, key: string): Promise<void> {
    return this.mn.db.remove(collection, key);
  }

  public async dbGetItem(key: string): Promise<any> {
    return this.mn.db.getItem(key);
  }

  public async dbSetItem(key: string, value: any): Promise<void> {
    return this.mn.db.setItem(key, value);
  }

  public async dbRemoveItem(key: string): Promise<void> {
    return this.mn.db.removeItem(key);
  }

  // File Operations
  public async fileUpload(blob: Blob | File, options?: { name?: string; type?: string }): Promise<any> {
    return this.mn.files.upload(blob, options);
  }

  public async fileList(): Promise<any[]> {
    return this.mn.files.list();
  }

  public async fileDelete(id: string): Promise<void> {
    return this.mn.files.delete(id);
  }

  // Notifications
  public async notify(title: string, body: string, url?: string): Promise<void> {
    return this.mn.notify(title, body, url);
  }

  // Fetch all helper for Notifications inside standalone
  public async getLocalNotifications(): Promise<MiniNodeNotification[]> {
    const nativeMN = (window as any).MiniNode;
    if (nativeMN) {
      // Native MN doesn't expose a notifications list directly, we return empty or cached
      return [];
    }
    const cached = localStorage.getItem("haushalt_mn_notifications") || "[]";
    return JSON.parse(cached);
  }

  public async markNotificationsAsRead(): Promise<void> {
    const notificationsKey = "haushalt_mn_notifications";
    const cached = localStorage.getItem(notificationsKey) || "[]";
    const notifs: MiniNodeNotification[] = JSON.parse(cached);
    notifs.forEach(n => n.read = true);
    localStorage.setItem(notificationsKey, JSON.stringify(notifs));
  }
}

export const miniNode = new MiniNodeClient();
