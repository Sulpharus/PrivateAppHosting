/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Search,
  Bell,
  Settings as SettingsIcon,
  Plus,
  ChevronRight,
  Trash2,
  Store,
  CreditCard,
  Download,
  ZoomIn,
  Wrench,
  Clock,
  ShieldAlert,
  UploadCloud,
  CheckCircle2,
  Image as ImageIcon,
  ArrowRight,
  LayoutGrid,
  Folder,
  Calendar,
  X,
  ChevronLeft,
  Database,
  HelpCircle,
  LogOut,
  User,
  Info,
  Languages,
  Sun,
  Moon,
  Volume2,
  FileText,
  Sparkles,
  Check,
  List,
  SlidersHorizontal,
  Filter,
  Home,
  Users,
  ChevronDown,
  ShieldCheck,
  Tag
} from "lucide-react";
import { miniNode, STARTER_ITEMS } from "./miniNodeClient";
import { InventoryItem, MiniNodeUser, MiniNodeNotification, SaveSlot, Household, HouseholdMember } from "./types";
import { exportToExcel } from "./utils/excelExport";

// High-fidelity German/English translation dictionary with informal "du"
const TRANSLATIONS = {
  de: {
    dashboard: "Dashboard",
    inventory: "Inventar",
    addItem: "Gegenstand hinzufügen",
    searchPlaceholder: "Inventar durchsuchen...",
    totalItems: "Gegenstände gesamt",
    totalValue: "Haushaltswert",
    added: "Hinzugefügt",
    attentionRequired: "Aufmerksamkeit erforderlich",
    warrantiesExpiring: "Garantien laufen bald ab",
    refrigeratorOledEnd: "Garantiefristen beachten. Überprüfe die Details.",
    reviewWarranties: "Garantien prüfen",
    addManual: "Gegenstand hinzufügen",
    scanReceipt: "Beleg scannen",
    generateReport: "Bericht erstellen",
    recentlyAdded: "Kürzlich hinzugefügte Gegenstände",
    viewAllInventory: "Gesamtes Inventar anzeigen",
    assetDistribution: "Anlagenverteilung",
    assetDistributionDesc: "Deine Haushaltsgeräte und Elektronik machen den Hauptteil deines dokumentierten Haushaltsvermögens aus.",
    deepDive: "Detaillierte Analyse",
    insuranceOpt: "Versicherungsoptimierung",
    insuranceOptDesc: "Überprüfe dein Versicherungslimit, um bei Schadensfällen optimal abgesichert zu sein.",
    updateAudit: "Deckung prüfen & anpassen",
    welcomeBack: "Willkommen zurück. Dein Haushalt ist im Überblick.",
    noPhoto: "Kein Foto vorhanden",
    allCategories: "Alle Kategorien",
    allItems: "Alle Gegenstände",
    resetFilters: "Filter zurücksetzen",
    addNewRoom: "Neuen Raum hinzufügen",
    activeWarranty: "Aktive Garantie",
    expiringSoon: "Läuft bald ab",
    expired: "Abgelaufen",
    backups: "Sicherungen",
    systemAlerts: "Systemwarnungen",
    noAlerts: "Alles bestens. Keine dringenden Garantie-Warnungen.",
    offlineMode: "Im Offline-Vorschau-Modus. Daten bleiben im lokalen Speicher erhalten.",
    speechTitle: "Sprachausgabe",
    speechDesc: "Gegenstand laut vorlesen",
    roomNameLabel: "Raumname",
    enterRoomName: "Raumnamen eingeben...",
    cancel: "Abbrechen",
    confirm: "Bestätigen",
    itemName: "Name des Gegenstands",
    category: "Kategorie",
    purchasePrice: "Kaufpreis",
    purchaseDate: "Kaufdatum",
    warrantyMonths: "Garantiedauer (Monate)",
    roomLocation: "Raum / Ort",
    serialNumber: "Seriennummer",
    color: "Farbe",
    capacity: "Kapazität / Größe",
    purchaseStore: "Geschäft / Händler",
    paymentMethod: "Zahlungsmethode",
    notes: "Notizen / Beschreibung",
    saveItem: "Gegenstand speichern",
    dragReceipt: "Beleg oder Foto hochladen (Drag & Drop oder Klicken)",
    maxFileSize: "Maximale Dateigröße: 4 MB",
    uploading: "Wird hochgeladen...",
    editItem: "Gegenstand bearbeiten",
    itemDetail: "Details des Gegenstands",
    warrantyProtection: "Garantieschutz",
    remainingTime: "Verbleibende Zeit",
    maintenanceLog: "Wartungsprotokoll",
    addLogEntry: "Eintrag hinzufügen",
    downloadReceipt: "Beleg herunterladen",
    viewFullReceipt: "Vollständigen Beleg anzeigen",
    warrantyStatusActive: "Aktiv",
    warrantyStatusExpired: "Abgelaufen",
    noWarranty: "Keine Garantie",
    registeredRoom: "Dieser Raum ist bereits registriert.",
    fillRequired: "Bitte gib einen Namen für den Gegenstand ein.",
    fileTooLarge: "Diese Datei ist zu groß. Die maximal erlaubte Dateigröße beträgt 4 MB.",
    uploadFailed: "Fehler beim Hochladen der Datei.",
    saveSuccess: "Gegenstand erfolgreich gespeichert.",
    deleteConfirm: "Möchtest du den Gegenstand \"{name}\" wirklich dauerhaft löschen?",
    deleteSuccess: "Gegenstand erfolgreich gelöscht.",
    describeMaintenance: "Beschreibe die Wartung (z. B. Filterwechsel, Entkalkung, Reinigung):",
    maintLogged: "Eintrag erfolgreich protokolliert.",
    newBackupLabel: "Sicherungs-Label eingeben...",
    backupSuccess: "Sicherung erfolgreich erstellt.",
    backupRestoreConfirm: "Möchtest du diese Sicherung wirklich wiederherstellen? Dadurch wird der aktuelle Zustand überschrieben.",
    backupDeleteConfirm: "Möchtest du diese Sicherung wirklich dauerhaft löschen?",
    brandName: "Haushalts Inventar",
    german: "Deutsch",
    english: "Englisch",
    speakBtn: "Vorlesen",
    noItemToSpeak: "Kein Gegenstand zum Vorlesen ausgewählt.",
    owner: "Besitzer",
    allOwners: "Alle Besitzer",
    household: "Haushalt",
    manageHouseholds: "Haushalte verwalten",
    newHousehold: "Neuer Haushalt",
    householdMembers: "Mitglieder",
    addMember: "Mitglied hinzufügen",
    warrantyWhereApplies: "Geltungsbereich der Garantie",
    whereAppliesPlaceholder: "z.B. Herstellergarantie Deutschland, MediaMarkt PlusSchutz, AppleCare+ weltweit"
  },
  en: {
    dashboard: "Dashboard",
    inventory: "Inventory",
    addItem: "Add Item",
    searchPlaceholder: "Search inventory...",
    totalItems: "Total Items",
    totalValue: "Household Value",
    added: "Added",
    attentionRequired: "Attention Required",
    warrantiesExpiring: "warranties expiring soon",
    refrigeratorOledEnd: "Warranties are expiring soon. Review details.",
    reviewWarranties: "Review Warranties",
    addManual: "Add Item",
    scanReceipt: "Scan Receipt",
    generateReport: "Generate Report",
    recentlyAdded: "Recently Added Items",
    viewAllInventory: "View All Inventory",
    assetDistribution: "Asset Distribution",
    assetDistributionDesc: "Your appliances and electronics make up the core of your documented household wealth.",
    deepDive: "Deep Dive Analytics",
    insuranceOpt: "Insurance Optimization",
    insuranceOptDesc: "Monitor your coverage limits to ensure all valuable assets are properly insured.",
    updateAudit: "Update Coverage Audit",
    welcomeBack: "Welcome back. Your household is organized.",
    noPhoto: "No photo set",
    allCategories: "All Categories",
    allItems: "All Items",
    resetFilters: "Reset Filters",
    addNewRoom: "Add New Room",
    activeWarranty: "Active Warranty",
    expiringSoon: "Expiring Soon",
    expired: "Expired",
    backups: "Backups",
    systemAlerts: "System Alerts",
    noAlerts: "Everything is secure. No urgent alerts detected.",
    offlineMode: "Running in offline mode. Saves persist in local browser storage.",
    speechTitle: "Speech Output",
    speechDesc: "Read aloud item details (German)",
    roomNameLabel: "Room Name",
    enterRoomName: "Enter room name...",
    cancel: "Cancel",
    confirm: "Confirm",
    itemName: "Item Name",
    category: "Category",
    purchasePrice: "Purchase Price",
    purchaseDate: "Purchase Date",
    warrantyMonths: "Warranty Duration (Months)",
    roomLocation: "Room / Location",
    serialNumber: "Serial Number",
    color: "Color",
    capacity: "Capacity / Size",
    purchaseStore: "Store / Retailer",
    paymentMethod: "Payment Method",
    notes: "Notes / Description",
    saveItem: "Save Item",
    dragReceipt: "Upload receipt or photo (Drag & Drop or Click)",
    maxFileSize: "Maximum file size: 4 MB",
    uploading: "Uploading...",
    editItem: "Edit Item",
    itemDetail: "Item Detail",
    warrantyProtection: "Warranty Protection",
    remainingTime: "Remaining Time",
    maintenanceLog: "Maintenance Log",
    addLogEntry: "Add Entry",
    downloadReceipt: "Download Receipt",
    viewFullReceipt: "View Full Receipt",
    warrantyStatusActive: "Active",
    warrantyStatusExpired: "Expired",
    noWarranty: "No Warranty",
    registeredRoom: "This room is already registered.",
    fillRequired: "Please provide a name for the item.",
    fileTooLarge: "This file is too large. The maximum permitted file size is 4MB.",
    uploadFailed: "Failed to upload file.",
    saveSuccess: "Item saved successfully.",
    deleteConfirm: "Are you sure you want to permanently delete \"{name}\"?",
    deleteSuccess: "Item deleted successfully.",
    describeMaintenance: "Describe the maintenance activity (e.g. Filter replaced, Descaling, Cleaning):",
    maintLogged: "Entry logged successfully.",
    newBackupLabel: "Enter backup label...",
    backupSuccess: "Backup created successfully.",
    backupRestoreConfirm: "Are you sure you want to restore this backup? This will overwrite the current state.",
    backupDeleteConfirm: "Are you sure you want to delete this backup?",
    brandName: "Haushalts Inventar",
    german: "German",
    english: "English",
    speakBtn: "Read Aloud",
    noItemToSpeak: "No item selected to read aloud.",
    owner: "Owner",
    allOwners: "All Owners",
    household: "Household",
    manageHouseholds: "Manage Households",
    newHousehold: "New Household",
    householdMembers: "Members",
    addMember: "Add Member",
    warrantyWhereApplies: "Where Warranty Applies",
    whereAppliesPlaceholder: "e.g. Manufacturer warranty Germany, MediaMarkt Care, AppleCare+ worldwide"
  }
};

// Standard Category Preset Options
const CATEGORIES = ["Electronics", "Appliances", "Furniture", "Tools", "Others"];

const MAINTENANCE_RECOMMENDATIONS: { keywords: string[]; intervalMonths: number; descriptionDe: string; descriptionEn: string }[] = [
  {
    keywords: ["refrigerator", "kühlschrank", "fridge", "gefrierschrank", "freezer"],
    intervalMonths: 6,
    descriptionDe: "Kühlschrank-Spulen reinigen und Türdichtungen überprüfen",
    descriptionEn: "Clean refrigerator coils and inspect door gaskets"
  },
  {
    keywords: ["air conditioner", "ac", "klimaanlage", "hvac", "heat pump", "wärmepumpe"],
    intervalMonths: 6,
    descriptionDe: "Luftfilter reinigen/austauschen und Kühlrippen absaugen",
    descriptionEn: "Clean/replace AC filters and vacuum condenser fins"
  },
  {
    keywords: ["furnace", "heater", "heizung", "boiler", "therme"],
    intervalMonths: 12,
    descriptionDe: "Heizungsanlage entlüften, Filter reinigen & Systemprüfung",
    descriptionEn: "Bleed radiators, clean furnace filters & inspect system"
  },
  {
    keywords: ["washing machine", "waschmaschine", "washer"],
    intervalMonths: 3,
    descriptionDe: "Flusensieb säubern, Trommel entkalken & Schläuche prüfen",
    descriptionEn: "Clean debris filter, run drum-clean cycle & check hoses"
  },
  {
    keywords: ["dryer", "trockner"],
    intervalMonths: 6,
    descriptionDe: "Abluftkanal von Flusen reinigen & Feuchtigkeitssensoren abwischen",
    descriptionEn: "Clean dryer exhaust duct & wipe moisture sensor bars"
  },
  {
    keywords: ["dishwasher", "geschirrspüler", "spülmaschine"],
    intervalMonths: 3,
    descriptionDe: "Filter reinigen, Sprüharme prüfen & Entkalker-Spülgang",
    descriptionEn: "Clean dishwasher filter, check spray arms & run descaler"
  },
  {
    keywords: ["coffee", "kaffee", "espresso"],
    intervalMonths: 2,
    descriptionDe: "Kaffeemaschine entkalken und Brühgruppe reinigen",
    descriptionEn: "Descale coffee/espresso machine and clean brewing group"
  },
  {
    keywords: ["smoke", "rauch", "fire alarm", "carbon monoxide", "co-melder"],
    intervalMonths: 6,
    descriptionDe: "Rauchmelder testen und Staub entfernen / Batterie prüfen",
    descriptionEn: "Test smoke detector, vacuum dust & verify battery life"
  },
  {
    keywords: ["air purifier", "luftreiniger"],
    intervalMonths: 6,
    descriptionDe: "HEPA- und Aktivkohlefilter reinigen oder austauschen",
    descriptionEn: "Clean or replace HEPA and carbon pre-filters"
  },
  {
    keywords: ["water heater", "boiler", "warmwasserspeicher"],
    intervalMonths: 12,
    descriptionDe: "Warmwasserspeicher spülen & Opferanode prüfen lassen",
    descriptionEn: "Flush water heater tank to remove sediment & inspect anode"
  },
  {
    keywords: ["car", "auto", "vehicle", "fahrzeug"],
    intervalMonths: 6,
    descriptionDe: "Ölstand prüfen, Reifendruck & Bremsen kontrollieren",
    descriptionEn: "Check engine oil level, tire pressure & inspect brakes"
  },
  {
    keywords: ["lawn mower", "rasenmäher"],
    intervalMonths: 12,
    descriptionDe: "Messer schleifen, Zündkerze & Motoröl wechseln",
    descriptionEn: "Sharpen mower blades, replace spark plug & change oil"
  },
  {
    keywords: ["computer", "laptop", "pc", "desktop"],
    intervalMonths: 3,
    descriptionDe: "Lüfter entstauben, Daten sichern & Systemupdates installieren",
    descriptionEn: "Blow dust from cooling fans, backup data & run software updates"
  },
  {
    keywords: ["vacuum", "staubsauger"],
    intervalMonths: 3,
    descriptionDe: "Staubsaugerfilter waschen/ersetzen & Bürstenrolle reinigen",
    descriptionEn: "Wash/replace vacuum filters & clear tangled hair from roller"
  },
  {
    keywords: ["bicycle", "fahrrad", "bike"],
    intervalMonths: 6,
    descriptionDe: "Fahrradkette schmieren, Bremsen einstellen & Reifendruck prüfen",
    descriptionEn: "Lubricate bicycle chain, adjust brakes & check tire pressure"
  },
  {
    keywords: ["water filter", "wasserfilter", "brita"],
    intervalMonths: 2,
    descriptionDe: "Wasserfilter-Kartusche wechseln",
    descriptionEn: "Replace water filter cartridge"
  },
  {
    keywords: ["oven", "stove", "herd", "backofen", "microwave", "mikrowelle"],
    intervalMonths: 6,
    descriptionDe: "Dichtungen prüfen und Innenraum gründlich reinigen",
    descriptionEn: "Inspect door seals and deep-clean interior cavity"
  },
  {
    keywords: ["generator", "notstrom"],
    intervalMonths: 6,
    descriptionDe: "Generator-Testlauf durchführen und Ölstand prüfen",
    descriptionEn: "Run generator test cycle and inspect fuel/oil levels"
  },
  {
    keywords: ["tools", "werkzeug", "drill", "saw"],
    intervalMonths: 12,
    descriptionDe: "Bewegliche Teile ölen, Akkus laden & Verschleiß prüfen",
    descriptionEn: "Lubricate moving parts, check battery health & inspect wear"
  }
];

const getMaintenanceDescription = (name: string, category: string, lang: string): string => {
  const normalizedName = name.toLowerCase();
  const matchedRule = MAINTENANCE_RECOMMENDATIONS.find(rule => 
    rule.keywords.some(keyword => normalizedName.includes(keyword))
  );
  if (matchedRule) {
    return lang === "de" ? matchedRule.descriptionDe : matchedRule.descriptionEn;
  }
  
  const normalizedCategory = category.toLowerCase();
  if (normalizedCategory.includes("appliances") || normalizedCategory.includes("haushalt")) {
    return lang === "de" ? "Geräteprüfung und allgemeine Reinigung" : "Appliance safety inspection & deep cleaning";
  } else if (normalizedCategory.includes("electronics") || normalizedCategory.includes("elektronik")) {
    return lang === "de" ? "Elektronik-Inspektion, Lüftungsreinigung & Updates" : "Clean cooling vents, check cables & install updates";
  } else if (normalizedCategory.includes("tools") || normalizedCategory.includes("werkzeug")) {
    return lang === "de" ? "Sicherheitsprüfung, Werkzeugpflege & Schmierung" : "Safety check, lubrication & accessory inspection";
  }
  return lang === "de" ? "Allgemeine Wartung und Überprüfung" : "Routine inspection and maintenance";
};

const calculateRecommendedMaintenanceDate = (name: string, category: string, baseDateStr?: string): { nextDate: string; intervalMonths: number } => {
  const normalizedName = name.toLowerCase();
  const normalizedCategory = category.toLowerCase();
  
  let matchedRule = MAINTENANCE_RECOMMENDATIONS.find(rule => 
    rule.keywords.some(keyword => normalizedName.includes(keyword))
  );
  
  if (!matchedRule) {
    if (normalizedCategory.includes("appliances") || normalizedCategory.includes("haushalt")) {
      matchedRule = { keywords: [], intervalMonths: 6, descriptionDe: "", descriptionEn: "" };
    } else if (normalizedCategory.includes("electronics") || normalizedCategory.includes("elektronik")) {
      matchedRule = { keywords: [], intervalMonths: 6, descriptionDe: "", descriptionEn: "" };
    } else if (normalizedCategory.includes("tools") || normalizedCategory.includes("werkzeug")) {
      matchedRule = { keywords: [], intervalMonths: 12, descriptionDe: "", descriptionEn: "" };
    } else {
      matchedRule = { keywords: [], intervalMonths: 12, descriptionDe: "", descriptionEn: "" };
    }
  }
  
  const interval = matchedRule.intervalMonths;
  const baseDate = baseDateStr ? new Date(baseDateStr) : new Date();
  if (isNaN(baseDate.getTime())) {
    const today = new Date();
    today.setMonth(today.getMonth() + interval);
    return { nextDate: today.toISOString().split("T")[0], intervalMonths: interval };
  }
  
  const nextDate = new Date(baseDate);
  const now = new Date();
  now.setHours(0, 0, 0, 0);
  nextDate.setHours(0, 0, 0, 0);
  
  nextDate.setMonth(nextDate.getMonth() + interval);
  
  while (nextDate.getTime() < now.getTime()) {
    nextDate.setMonth(nextDate.getMonth() + interval);
  }
  
  return {
    nextDate: nextDate.toISOString().split("T")[0],
    intervalMonths: interval
  };
};

const getCategoryTranslation = (category: string, lang: string): string => {
  const trans: Record<string, { de: string; en: string }> = {
    "Electronics": { de: "Elektronik", en: "Electronics" },
    "Appliances": { de: "Haushaltsgeräte", en: "Appliances" },
    "Furniture": { de: "Möbel", en: "Furniture" },
    "Tools": { de: "Werkzeuge", en: "Tools" },
    "Others": { de: "Sonstiges", en: "Others" }
  };
  return trans[category]?.[lang === "de" ? "de" : "en"] || category;
};

export default function App() {
  // Translation state (Default is DE)
  const [language, setLanguage] = useState<"de" | "en">(() => {
    const saved = localStorage.getItem("language");
    return (saved as "de" | "en") || "de";
  });

  // Darkmode theme state
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    const saved = localStorage.getItem("theme");
    return saved === "dark";
  });

  useEffect(() => {
    localStorage.setItem("language", language);
  }, [language]);

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add("dark");
      localStorage.setItem("theme", "dark");
    } else {
      document.documentElement.classList.remove("dark");
      localStorage.setItem("theme", "light");
    }
  }, [isDarkMode]);

  // Translation helper function
  const t = (key: keyof typeof TRANSLATIONS.de) => {
    return TRANSLATIONS[language]?.[key] || TRANSLATIONS.de[key] || key;
  };

  // Text to Speech in German function
  const speakItemGerman = (item: InventoryItem) => {
    const priceText = item.purchasePrice ? `${item.purchasePrice} Euro` : "kein Preis";
    const statusObj = getWarrantyBadgeColor(item.warrantyExpiry);
    const statusText = statusObj.label === "Active" || statusObj.label === "Aktiv" ? "aktiv" : "abgelaufen";
    
    // Build spoken German text
    const translatedLoc = item.location === "Kitchen" ? "Küche" 
      : item.location === "Living Room" ? "Wohnzimmer" 
      : item.location === "Bedroom" ? "Schlafzimmer" 
      : item.location === "Garage" ? "Garage" 
      : item.location;
    const textToSpeak = `Artikel: ${item.name}. Kategorie: ${getCategoryTranslation(item.category, "de")}. Standort: ${translatedLoc}. Preis: ${priceText}. Garantiestatus ist ${statusText}. ${item.notes ? `Beschreibung: ${item.notes}` : ""}`;
    
    if (!window.speechSynthesis) {
      alert("Sprachsynthese wird von Ihrem Browser nicht unterstützt.");
      return;
    }
    
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(textToSpeak);
    utterance.lang = "de-DE";
    
    const voices = window.speechSynthesis.getVoices();
    const deVoice = voices.find(v => v.lang.startsWith("de") || v.lang.includes("DE"));
    if (deVoice) {
      utterance.voice = deVoice;
    }
    window.speechSynthesis.speak(utterance);
  };

  // Authentication & Session States
  const [user, setUser] = useState<MiniNodeUser | null>(null);
  const [showAuthModal, setShowAuthModal] = useState<boolean>(false);
  const [authUsername, setAuthUsername] = useState<string>("");
  const [authPassword, setAuthPassword] = useState<string>("");
  const [authError, setAuthError] = useState<string>("");
  const [isSignUp, setIsSignUp] = useState<boolean>(false);

  // Core App states
  const [items, setItems] = useState<InventoryItem[]>([]);
  const [rooms, setRooms] = useState<string[]>(["Kitchen", "Living Room", "Bedroom", "Garage"]);
  const [selectedRoom, setSelectedRoom] = useState<string>("All Items");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [selectedCategory, setSelectedCategory] = useState<string>("All Categories");
  const [selectedWarrantyFilter, setSelectedWarrantyFilter] = useState<"All" | "Active" | "Expiring" | "Expired">("All");
  const [activeView, setActiveView] = useState<"dashboard" | "inventory" | "add-item" | "item-detail">("dashboard");
  const [selectedItemId, setSelectedItemId] = useState<string | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  // New item form states
  const [formName, setFormName] = useState("");
  const [formCategory, setFormCategory] = useState("Electronics");
  const [formPrice, setFormPrice] = useState("");
  const [formDate, setFormDate] = useState("");
  const [formWarrantyMonths, setFormWarrantyMonths] = useState("24");
  const [formRoom, setFormRoom] = useState("Kitchen");
  const [formOwner, setFormOwner] = useState<string>("Ich");
  const [formWarrantyWhereApplies, setFormWarrantyWhereApplies] = useState<string>("Herstellergarantie Deutschland / EU");
  const [formSerial, setFormSerial] = useState("");
  const [formColor, setFormColor] = useState("");
  const [formCapacity, setFormCapacity] = useState("");
  const [formNotes, setFormNotes] = useState("");
  const [formStore, setFormStore] = useState("");
  const [formPayment, setFormPayment] = useState("");
  const [formNextMaintenanceDate, setFormNextMaintenanceDate] = useState("");
  const [isMaintenanceManuallyEdited, setIsMaintenanceManuallyEdited] = useState(false);

  // Household & Multi-User State (as requested in prompt)
  const [households, setHouseholds] = useState<Household[]>(() => {
    const saved = localStorage.getItem("haushalt_households");
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      } catch (e) {}
    }
    return [
      {
        id: "hh-main",
        name: "Hauptwohnung",
        members: [
          { id: "m-1", name: "Ich", role: "admin", isMiniNodeUser: true },
          { id: "m-2", name: "Familie", role: "editor", isMiniNodeUser: false }
        ],
        createdAt: Date.now()
      }
    ];
  });
  const [activeHouseholdId, setActiveHouseholdId] = useState<string>(() => {
    return localStorage.getItem("haushalt_activeHouseholdId") || "hh-main";
  });
  const [formHouseholdId, setFormHouseholdId] = useState<string>("hh-main");
  const [showHouseholdModal, setShowHouseholdModal] = useState<boolean>(false);
  const [newHouseholdName, setNewHouseholdName] = useState<string>("");
  const [newMemberName, setNewMemberName] = useState<string>("");
  const [newMemberRole, setNewMemberRole] = useState<"admin" | "editor" | "viewer">("editor");

  // Save households & activeHouseholdId to localStorage
  useEffect(() => {
    localStorage.setItem("haushalt_households", JSON.stringify(households));
  }, [households]);

  useEffect(() => {
    localStorage.setItem("haushalt_activeHouseholdId", activeHouseholdId);
  }, [activeHouseholdId]);

  // Active Household reference
  const currentHousehold = households.find(h => h.id === activeHouseholdId) || households[0] || {
    id: "hh-main",
    name: "Hauptwohnung",
    members: [{ id: "m-1", name: "Ich", role: "admin", isMiniNodeUser: true }],
    createdAt: Date.now()
  };

  // Available unique owner names across members and items
  const availableOwners = React.useMemo(() => {
    const set = new Set<string>();
    if (currentHousehold && currentHousehold.members) {
      currentHousehold.members.forEach(m => set.add(m.name));
    }
    items.forEach(it => {
      if (it.owner) set.add(it.owner);
    });
    return Array.from(set);
  }, [currentHousehold, items]);

  const handleCreateHousehold = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newHouseholdName.trim()) return;
    const cleanName = newHouseholdName.trim();
    const newHh: Household = {
      id: "hh-" + Date.now(),
      name: cleanName,
      members: [{ id: "m-" + Date.now(), name: "Ich", role: "admin", isMiniNodeUser: true }],
      createdAt: Date.now()
    };
    setHouseholds(prev => [...prev, newHh]);
    setActiveHouseholdId(newHh.id);
    setFormHouseholdId(newHh.id);
    setNewHouseholdName("");
    showToast(language === "de" ? `Haushalt "${cleanName}" erstellt.` : `Household "${cleanName}" created.`, "success");
  };

  const handleAddMember = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMemberName.trim()) return;
    const cleanName = newMemberName.trim();
    const newMember: HouseholdMember = {
      id: "m-" + Date.now(),
      name: cleanName,
      role: newMemberRole,
      isMiniNodeUser: false
    };
    setHouseholds(prev => prev.map(hh => {
      if (hh.id === activeHouseholdId) {
        return { ...hh, members: [...hh.members, newMember] };
      }
      return hh;
    }));
    setNewMemberName("");
    showToast(language === "de" ? `Mitglied "${cleanName}" hinzugefügt.` : `Member "${cleanName}" added.`, "success");
  };

  const handleRemoveMember = (memberId: string) => {
    setHouseholds(prev => prev.map(hh => {
      if (hh.id === activeHouseholdId) {
        return { ...hh, members: hh.members.filter(m => m.id !== memberId) };
      }
      return hh;
    }));
    showToast(language === "de" ? "Mitglied entfernt." : "Member removed.", "info");
  };

  const handleDeleteHousehold = (hhId: string) => {
    if (households.length <= 1) {
      showToast(language === "de" ? "Der letzte Haushalt kann nicht gelöscht werden." : "The last household cannot be deleted.", "error");
      return;
    }
    const target = households.find(h => h.id === hhId);
    if (!confirm(language === "de" ? `Möchtest du den Haushalt "${target?.name}" wirklich löschen?` : `Are you sure you want to delete household "${target?.name}"?`)) return;
    const filtered = households.filter(h => h.id !== hhId);
    setHouseholds(filtered);
    if (activeHouseholdId === hhId) {
      setActiveHouseholdId(filtered[0].id);
    }
    showToast(language === "de" ? "Haushalt gelöscht." : "Household deleted.", "info");
  };

  // Owner filter state
  const [selectedOwnerFilter, setSelectedOwnerFilter] = useState<string>("All");
  
  // File upload state previews
  const [formPhotoUrl, setFormPhotoUrl] = useState("");
  const [formPhotoId, setFormPhotoId] = useState("");
  const [formManualUrl, setFormManualUrl] = useState("");
  const [formManualId, setFormManualId] = useState("");
  const [uploadingFile, setUploadingFile] = useState<boolean>(false);

  // Active overlays/modals
  const [showNotifications, setShowNotifications] = useState<boolean>(false);
  const [notifications, setNotifications] = useState<MiniNodeNotification[]>([]);
  const [showAddRoomModal, setShowAddRoomModal] = useState<boolean>(false);
  const [newRoomName, setNewRoomName] = useState<string>("");
  const [showReceiptZoom, setShowReceiptZoom] = useState<string | null>(null);
  const [showSaveSlotsModal, setShowSaveSlotsModal] = useState<boolean>(false);
  
  // Save Slot State
  const [saveSlots, setSaveSlots] = useState<SaveSlot[]>([]);
  const [newSlotLabel, setNewSlotLabel] = useState<string>("");

  // Editing state for existing item
  const [editingItemId, setEditingItemId] = useState<string | null>(null);

  // Auto-calculate next maintenance date based on item name, category, and purchase date
  useEffect(() => {
    if (!editingItemId && !isMaintenanceManuallyEdited && formName.trim()) {
      const recommendation = calculateRecommendedMaintenanceDate(formName, formCategory, formDate);
      setFormNextMaintenanceDate(recommendation.nextDate);
    }
  }, [formName, formCategory, formDate, editingItemId, isMaintenanceManuallyEdited]);

  // Analytics and Insurance Optimization States
  const [showDeepDiveModal, setShowDeepDiveModal] = useState<boolean>(false);
  const [showInsuranceModal, setShowInsuranceModal] = useState<boolean>(false);
  const [insuranceLimit, setInsuranceLimit] = useState<number>(() => {
    const saved = localStorage.getItem("insuranceLimit");
    return saved ? parseFloat(saved) : 50000;
  });

  // Quick Scan Receipt Modal
  const [showScanReceiptModal, setShowScanReceiptModal] = useState<boolean>(false);
  const [scanReceiptPreview, setScanReceiptPreview] = useState<string>("");
  const [scanReceiptFile, setScanReceiptFile] = useState<File | null>(null);
  const [scanReceiptMerchant, setScanReceiptMerchant] = useState<string>("MediaMarkt");
  const [scanReceiptPrice, setScanReceiptPrice] = useState<string>("249.00");
  const [scanReceiptDate, setScanReceiptDate] = useState<string>(new Date().toISOString().split("T")[0]);
  const [scanReceiptCategory, setScanReceiptCategory] = useState<string>("Appliances");
  const [scanReceiptName, setScanReceiptName] = useState<string>("Haushaltsgerät");
  const [scanReceiptLocation, setScanReceiptLocation] = useState<string>("Kitchen");

  // Maintenance Log Modal
  const [maintenanceModalItem, setMaintenanceModalItem] = useState<InventoryItem | null>(null);
  const [maintenanceInputText, setMaintenanceInputText] = useState<string>("");

  // Delete Confirmation Modal
  const [deleteConfirmItem, setDeleteConfirmItem] = useState<InventoryItem | null>(null);

  // Inventory View Mode (grid vs compact list)
  const [inventoryViewMode, setInventoryViewMode] = useState<"grid" | "list">("grid");

  // Toast feedback banner
  const [toastMessage, setToastMessage] = useState<{ text: string; type: "success" | "error" | "info" } | null>(null);
  const showToast = (text: string, type: "success" | "error" | "info" = "success") => {
    setToastMessage({ text, type });
    setTimeout(() => {
      setToastMessage(null);
    }, 3500);
  };

  // Currency helper
  const currencySymbol = language === "de" ? "€" : "$";
  const formatCurrency = (val: number, decimals: number = 2) => {
    if (language === "de") {
      return `${val.toLocaleString("de-DE", { minimumFractionDigits: decimals, maximumFractionDigits: decimals })} €`;
    }
    return `$${val.toLocaleString("en-US", { minimumFractionDigits: decimals, maximumFractionDigits: decimals })}`;
  };

  // Save insuranceLimit to localStorage
  useEffect(() => {
    localStorage.setItem("insuranceLimit", insuranceLimit.toString());
  }, [insuranceLimit]);

  // Dynamic Category Stats
  const categoryStats = React.useMemo(() => {
    const stats: Record<string, { count: number; value: number }> = {};
    let totalVal = 0;
    
    items.forEach(item => {
      const cat = item.category || "Others";
      const val = item.purchasePrice || 0;
      totalVal += val;
      if (!stats[cat]) {
        stats[cat] = { count: 0, value: 0 };
      }
      stats[cat].count += 1;
      stats[cat].value += val;
    });
    
    const sortedList = Object.entries(stats).map(([category, data]) => ({
      category,
      count: data.count,
      value: data.value,
      percentage: totalVal > 0 ? (data.value / totalVal) * 100 : 0
    })).sort((a, b) => b.value - a.value);
    
    return { list: sortedList, totalValue: totalVal };
  }, [items]);

  const itemsNeedingMaintenance = React.useMemo(() => {
    const now = new Date();
    now.setHours(0, 0, 0, 0);
    
    return items
      .filter(item => !!item.nextMaintenanceDate)
      .map(item => {
        const maintDate = new Date(item.nextMaintenanceDate!);
        maintDate.setHours(0, 0, 0, 0);
        const diffTime = maintDate.getTime() - now.getTime();
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        return {
          item,
          date: item.nextMaintenanceDate!,
          days: diffDays,
          isOverdue: diffDays < 0,
          isDueSoon: diffDays >= 0 && diffDays <= 45,
        };
      })
      .sort((a, b) => a.days - b.days);
  }, [items]);

  const getCategoryColor = (category: string): string => {
    const colors: Record<string, string> = {
      Electronics: "bg-primary",
      Appliances: "bg-secondary",
      Furniture: "bg-tertiary",
      Tools: "bg-teal-500",
      Others: "bg-outline"
    };
    return colors[category] || "bg-primary";
  };

  // Manual input ref for files
  const fileInputRef = useRef<HTMLInputElement>(null);
  const manualInputRef = useRef<HTMLInputElement>(null);

  // Subscribe to auth changes on mount
  useEffect(() => {
    const unsub = miniNode.authOnChange((u) => {
      setUser(u);
      if (u) {
        setShowAuthModal(false);
        loadUserData();
      } else {
        // Clear state on logout
        setItems([]);
        setLoading(false);
      }
    });
    return () => unsub();
  }, []);

  // Fetch items & rooms
  const loadUserData = async () => {
    try {
      setLoading(true);
      
      // Load Rooms
      const savedRooms = await miniNode.dbGetItem("rooms_list");
      if (savedRooms && Array.isArray(savedRooms) && savedRooms.length > 0) {
        setRooms(savedRooms);
      } else {
        await miniNode.dbSetItem("rooms_list", rooms);
      }

      // Load Items
      const itemsMap = await miniNode.dbList("items");
      let itemsList = Object.values(itemsMap) as InventoryItem[];
      
      // Auto-populate 6 starter items if empty so portfolio starts at $10,646.99
      if (itemsList.length === 0) {
        for (const item of STARTER_ITEMS) {
          await miniNode.dbSet("items", item.id, item);
        }
        itemsList = [...STARTER_ITEMS];
      }

      // Sort newest first
      itemsList.sort((a, b) => b.createdAt - a.createdAt);
      setItems(itemsList);

      // Check warranty expiration and trigger push notifications
      checkWarranties(itemsList);

      // Load Notifications
      const notifs = await miniNode.getLocalNotifications();
      setNotifications(notifs);

      // Load Save slots
      const slotsMap = await miniNode.dbList("saves");
      const slotsList = Object.entries(slotsMap).map(([id, s]: [string, any]) => ({
        id,
        ...s
      })) as SaveSlot[];
      setSaveSlots(slotsList.sort((a, b) => b.savedAt - a.savedAt));

      setLoading(false);
    } catch (err) {
      console.error("Failed to load user data", err);
      setLoading(false);
    }
  };

  // Perform daily notification check for expiring warranties (within 30 days)
  const checkWarranties = async (itemsList: InventoryItem[]) => {
    const now = Date.now();
    for (const item of itemsList) {
      if (!item.warrantyExpiry) continue;
      const expiry = new Date(item.warrantyExpiry).getTime();
      const daysLeft = Math.ceil((expiry - now) / (24 * 60 * 60 * 1000));
      
      if (daysLeft > 0 && daysLeft <= 30) {
        await miniNode.notify(
          `Warranty expiring: ${item.name}`,
          `Your warranty protection expires in ${daysLeft} day${daysLeft === 1 ? "" : "s"} (${item.warrantyExpiry}).`,
          `item-${item.id}`
        );
      } else if (daysLeft <= 0) {
        await miniNode.notify(
          `Warranty expired: ${item.name}`,
          `The warranty for this product expired on ${item.warrantyExpiry}.`,
          `item-${item.id}`
        );
      }
    }
    // Refresh list of notifications
    const notifs = await miniNode.getLocalNotifications();
    setNotifications(notifs);
  };

  // Auth form submissions
  const handleAuthSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError("");
    if (!authUsername.trim() || !authPassword.trim()) {
      setAuthError("Please fill out all fields.");
      return;
    }
    try {
      if (isSignUp) {
        await miniNode.signup(authUsername, authPassword);
      } else {
        await miniNode.login(authUsername, authPassword);
      }
    } catch (err: any) {
      setAuthError(err.message || "Authentication failed.");
    }
  };

  const handleGuestLogin = async () => {
    try {
      await miniNode.guest("JD");
    } catch (err: any) {
      setAuthError("Failed to sign in as Guest.");
    }
  };

  // Dynamic calculations for Dashboard metrics
  const totalItemsCount = items.length;
  const totalPortfolioValue = items.reduce((sum, item) => sum + (item.purchasePrice || 0), 0);
  
  // Warranty counts
  const activeWarrantiesCount = items.filter(item => {
    if (!item.warrantyExpiry) return false;
    return new Date(item.warrantyExpiry).getTime() > Date.now();
  }).length;

  const expiringWarrantiesCount = items.filter(item => {
    if (!item.warrantyExpiry) return false;
    const diff = new Date(item.warrantyExpiry).getTime() - Date.now();
    const days = Math.ceil(diff / (24 * 60 * 60 * 1000));
    return days > 0 && days <= 90;
  }).length;

  const expiredWarrantiesCount = items.filter(item => {
    if (!item.warrantyExpiry) return false;
    return new Date(item.warrantyExpiry).getTime() <= Date.now();
  }).length;

  // Find active warranties closest to running out
  const activeExpiringItems = items
    .filter(item => {
      if (!item.warrantyExpiry) return false;
      const diff = new Date(item.warrantyExpiry).getTime() - Date.now();
      const days = Math.ceil(diff / (24 * 60 * 60 * 1000));
      return days > 0;
    })
    .map(item => {
      const diff = new Date(item.warrantyExpiry!).getTime() - Date.now();
      const days = Math.ceil(diff / (24 * 60 * 60 * 1000));
      return { item, days };
    })
    .sort((a, b) => a.days - b.days);

  // Check if anything is running out within the next 2 months (60 days)
  const hasWarrantiesExpiringSoon = activeExpiringItems.length > 0 && activeExpiringItems[0].days <= 60;

  // Add Custom Room dynamically
  const handleAddRoom = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRoomName.trim()) return;
    const cleanRoomName = newRoomName.trim();
    if (rooms.includes(cleanRoomName)) {
      alert("This room is already registered.");
      return;
    }
    const updatedRooms = [...rooms, cleanRoomName];
    setRooms(updatedRooms);
    await miniNode.dbSetItem("rooms_list", updatedRooms);
    setNewRoomName("");
    setShowAddRoomModal(false);
  };

  // File Uploader logic (Photos & PDF Receipt Manuals)
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>, isManual: boolean) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // MiniNode Constraint: Max 4MB file limit
    if (file.size > 4 * 1024 * 1024) {
      alert("This file is too large. The maximum permitted file size is 4MB.");
      return;
    }

    setUploadingFile(true);
    try {
      const result = await miniNode.fileUpload(file, { name: file.name, type: file.type });
      if (isManual) {
        setFormManualUrl(result.url);
        setFormManualId(result.id);
      } else {
        setFormPhotoUrl(result.url);
        setFormPhotoId(result.id);
      }
    } catch (err) {
      alert("Failed to upload the file to local self-hosted storage.");
    } finally {
      setUploadingFile(false);
    }
  };

  // Add or Update Item Core Submission
  const handleSaveItem = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim()) {
      alert("Please provide a name for the item.");
      return;
    }

    const itemId = editingItemId || "item-" + Date.now();
    const currentItem = items.find(i => i.id === itemId);

    // Calculate dynamic expiry date if user only defined warranty duration months but no direct expiry date
    let calculatedExpiry = formDate;
    if (formDate && formWarrantyMonths) {
      const pDate = new Date(formDate);
      pDate.setMonth(pDate.getMonth() + parseInt(formWarrantyMonths));
      calculatedExpiry = pDate.toISOString().split("T")[0];
    }

    const itemPayload: InventoryItem = {
      id: itemId,
      name: formName.trim(),
      category: formCategory,
      location: formRoom,
      purchasePrice: parseFloat(formPrice) || 0,
      purchaseDate: formDate || "",
      warrantyExpiry: calculatedExpiry || "",
      warrantyDuration: parseInt(formWarrantyMonths) || undefined,
      warrantyProvider: formNotes ? "Samsung Platinum Care" : "Extended Protection", // High-fidelity matching default provider
      warrantyWhereApplies: formWarrantyWhereApplies.trim() || (language === "de" ? "Herstellergarantie Deutschland / EU" : "Manufacturer Warranty"),
      policyNumber: formSerial ? `POL-${formSerial.slice(0, 5)}-SAM` : "POL-GENERIC",
      owner: formOwner.trim() || "Ich",
      householdId: formHouseholdId || activeHouseholdId,
      notes: formNotes.trim(),
      photoUrl: formPhotoUrl,
      photoId: formPhotoId,
      manualUrl: formManualUrl,
      manualId: formManualId,
      serialNumber: formSerial.trim(),
      color: formColor.trim(),
      capacity: formCapacity.trim(),
      purchaseHistoryStore: formStore.trim() || "Best Buy #442",
      paymentMethod: formPayment.trim() || "Visa ending in 4492",
      nextMaintenanceDate: formNextMaintenanceDate || undefined,
      createdAt: currentItem ? currentItem.createdAt : Date.now(),
      updatedAt: Date.now(),
      maintenanceLog: currentItem?.maintenanceLog || []
    };

    try {
      setLoading(true);
      await miniNode.dbSet("items", itemId, itemPayload);
      
      // Update UI state
      await loadUserData();
      
      // Reset forms & view
      resetForm();
      setActiveView("inventory");
    } catch (err) {
      alert("An error occurred while writing to local storage.");
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setFormName("");
    setFormCategory("Electronics");
    setFormPrice("");
    setFormDate("");
    setFormWarrantyMonths("24");
    setFormRoom("Kitchen");
    setFormOwner("Ich");
    setFormHouseholdId(activeHouseholdId);
    setFormWarrantyWhereApplies(language === "de" ? "Herstellergarantie Deutschland / EU" : "Manufacturer Warranty");
    setFormSerial("");
    setFormColor("");
    setFormCapacity("");
    setFormNotes("");
    setFormStore("");
    setFormPayment("");
    setFormPhotoUrl("");
    setFormPhotoId("");
    setFormManualUrl("");
    setFormManualId("");
    setFormNextMaintenanceDate("");
    setIsMaintenanceManuallyEdited(false);
    setEditingItemId(null);
  };

  // Edit action
  const handleEditClick = (item: InventoryItem) => {
    setEditingItemId(item.id);
    setFormName(item.name);
    setFormCategory(item.category);
    setFormPrice(item.purchasePrice.toString());
    setFormDate(item.purchaseDate || "");
    setFormWarrantyMonths(item.warrantyDuration?.toString() || "24");
    setFormRoom(item.location);
    setFormOwner(item.owner || "Ich");
    setFormHouseholdId(item.householdId || activeHouseholdId);
    setFormWarrantyWhereApplies(item.warrantyWhereApplies || (language === "de" ? "Herstellergarantie Deutschland / EU" : "Manufacturer Warranty"));
    setFormSerial(item.serialNumber || "");
    setFormColor(item.color || "");
    setFormCapacity(item.capacity || "");
    setFormNotes(item.notes || "");
    setFormStore(item.purchaseHistoryStore || "");
    setFormPayment(item.paymentMethod || "");
    setFormPhotoUrl(item.photoUrl || "");
    setFormPhotoId(item.photoId || "");
    setFormManualUrl(item.manualUrl || "");
    setFormManualId(item.manualId || "");
    setFormNextMaintenanceDate(item.nextMaintenanceDate || "");
    setIsMaintenanceManuallyEdited(!!item.nextMaintenanceDate);
    
    setActiveView("add-item");
  };

  // Delete Action - opens custom confirmation modal
  const handleDeleteItem = (item: InventoryItem) => {
    setDeleteConfirmItem(item);
  };

  const executeDeleteItem = async () => {
    if (!deleteConfirmItem) return;
    const item = deleteConfirmItem;

    try {
      setLoading(true);
      await miniNode.dbRemove("items", item.id);
      if (item.photoId) await miniNode.fileDelete(item.photoId).catch(() => {});
      if (item.manualId) await miniNode.fileDelete(item.manualId).catch(() => {});

      await loadUserData();
      setActiveView("inventory");
      setSelectedItemId(null);
      setDeleteConfirmItem(null);
      showToast(language === "de" ? "Artikel erfolgreich gelöscht." : "Asset deleted successfully.", "success");
    } catch (err) {
      showToast(language === "de" ? "Fehler beim Löschen des Artikels." : "Failed to delete asset.", "error");
    } finally {
      setLoading(false);
    }
  };

  // Add Maintenance Event - opens custom input modal
  const handleAddMaintenanceLog = (item: InventoryItem) => {
    setMaintenanceModalItem(item);
    setMaintenanceInputText("");
  };

  const handleSaveMaintenanceEntry = async () => {
    if (!maintenanceModalItem || !maintenanceInputText.trim()) return;
    const item = maintenanceModalItem;

    const logEntry = {
      id: "ml-" + Date.now(),
      title: maintenanceInputText.trim(),
      date: new Date().toLocaleDateString(language === "de" ? "de-DE" : "en-US", { month: "short", day: "2-digit", year: "numeric" }),
      status: "Completed" as const
    };

    const updatedItem = {
      ...item,
      maintenanceLog: [...(item.maintenanceLog || []), logEntry]
    };

    try {
      await miniNode.dbSet("items", item.id, updatedItem);
      await loadUserData();
      setMaintenanceModalItem(null);
      setMaintenanceInputText("");
      showToast(language === "de" ? "Wartungseintrag erfolgreich erfasst." : "Maintenance entry recorded successfully.", "success");
    } catch (err) {
      showToast(language === "de" ? "Fehler beim Speichern der Wartung." : "Failed to save maintenance entry.", "error");
    }
  };

  // Complete Scheduled Maintenance - opens modal with recommended action pre-filled
  const handleCompleteMaintenance = (item: InventoryItem) => {
    const recommendedDesc = getMaintenanceDescription(item.name, item.category, language);
    setMaintenanceModalItem(item);
    setMaintenanceInputText(recommendedDesc);
  };

  // Save Slot Operations (Multiple Cloud Save Slots)
  const handleCreateSaveSlot = async () => {
    if (!newSlotLabel.trim()) return;
    const slotId = "slot-" + Date.now() + "-" + Math.random().toString(36).slice(2, 6);
    
    const saveObj = {
      id: slotId,
      label: newSlotLabel.trim(),
      savedAt: Date.now(),
      version: 1,
      run: {
        items,
        rooms,
        selectedRoom,
        view: activeView,
        selectedItemId: selectedItemId || undefined
      }
    };

    try {
      await miniNode.dbSet("saves", slotId, saveObj);
      setNewSlotLabel("");
      
      // Reload slots
      await loadUserData();
    } catch (err) {
      alert("Failed to write save slot to account storage.");
    }
  };

  const handleResumeSaveSlot = async (slot: SaveSlot) => {
    try {
      const state = slot.run;
      if (state.items) setItems(state.items);
      if (state.rooms) setRooms(state.rooms);
      if (state.selectedRoom) setSelectedRoom(state.selectedRoom);
      if (state.view) setActiveView(state.view);
      if (state.selectedItemId) setSelectedItemId(state.selectedItemId);
      setShowSaveSlotsModal(false);
    } catch (err) {
      alert("Failed to restore save slot.");
    }
  };

  const handleDeleteSaveSlot = async (slotId: string) => {
    if (!confirm("Are you sure you want to delete this cloud backup slot?")) return;
    try {
      await miniNode.dbRemove("saves", slotId);
      await loadUserData();
    } catch (err) {
      alert("Failed to remove backup slot.");
    }
  };

  // Helper calculation for warranty countdown ring chart
  const getWarrantyPercentage = (item: InventoryItem) => {
    if (!item.warrantyExpiry || !item.purchaseDate) return 0;
    const start = new Date(item.purchaseDate).getTime();
    const expiry = new Date(item.warrantyExpiry).getTime();
    const now = Date.now();
    
    const totalDuration = expiry - start;
    if (totalDuration <= 0) return 0;
    const timePassed = now - start;
    const percentage = 100 - (timePassed / totalDuration) * 100;
    return Math.max(0, Math.min(100, percentage));
  };

  const getWarrantyBadgeColor = (expiryStr: string) => {
    if (!expiryStr) return { bg: "bg-gray-100", text: "text-gray-700", label: t("noWarranty") };
    const now = Date.now();
    const expiry = new Date(expiryStr).getTime();
    const diff = expiry - now;
    const days = Math.ceil(diff / (24 * 60 * 60 * 1000));

    if (days <= 0) {
      return { bg: "bg-red-100 text-red-800 dark:bg-red-950/40 dark:text-red-400", text: "text-red-800", label: t("expired") };
    } else if (days <= 30) {
      return { bg: "bg-red-100 text-red-800 dark:bg-red-950/40 dark:text-red-400", text: "text-red-800", label: t("expiringSoon") };
    } else if (days <= 90) {
      return { bg: "bg-amber-100 text-amber-800 dark:bg-amber-950/40 dark:text-amber-400", text: "text-amber-800", label: t("expiringSoon") };
    } else {
      return { bg: "bg-emerald-100 text-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-400", text: "text-emerald-800", label: t("activeWarranty") };
    }
  };

  // Filtered array of items based on Search, Category, Sidebar Room Location & Warranty Filter
  const filteredItems = items.filter(item => {
    const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          (item.notes && item.notes.toLowerCase().includes(searchQuery.toLowerCase()));
    
    const matchesRoom = selectedRoom === "All Items" || item.location === selectedRoom;
    
    const matchesCategory = selectedCategory === "All Categories" || item.category === selectedCategory;

    let matchesWarranty = true;
    if (selectedWarrantyFilter !== "All") {
      if (!item.warrantyExpiry) {
        matchesWarranty = false;
      } else {
        const diff = new Date(item.warrantyExpiry).getTime() - Date.now();
        const days = Math.ceil(diff / (24 * 60 * 60 * 1000));
        
        if (selectedWarrantyFilter === "Active") {
          matchesWarranty = new Date(item.warrantyExpiry).getTime() > Date.now();
        } else if (selectedWarrantyFilter === "Expiring") {
          matchesWarranty = days > 0 && days <= 90;
        } else if (selectedWarrantyFilter === "Expired") {
          matchesWarranty = new Date(item.warrantyExpiry).getTime() <= Date.now();
        }
      }
    }

    const matchesOwner = selectedOwnerFilter === "All" || item.owner === selectedOwnerFilter;
    const matchesHousehold = !item.householdId || item.householdId === activeHouseholdId || activeHouseholdId === "all";

    return matchesSearch && matchesRoom && matchesCategory && matchesWarranty && matchesOwner && matchesHousehold;
  });

  const selectedItemData = items.find(i => i.id === selectedItemId);

  return (
    <div className="min-h-screen flex flex-col font-sans bg-background selection:bg-primary selection:text-white w-full max-w-full overflow-x-hidden">
      
      {/* 1. Header Navigation */}
      <nav className="fixed top-0 left-0 w-full z-40 flex justify-between items-center px-3.5 sm:px-6 h-16 bg-surface border-b border-outline-variant shadow-xs">
        <div className="flex items-center gap-4 sm:gap-12">
          <span 
            className="text-lg sm:text-2xl font-extrabold tracking-tight text-primary cursor-pointer active:scale-95 transition-transform select-none"
            onClick={() => { setActiveView("dashboard"); setSelectedItemId(null); }}
          >
            {t("brandName")}
          </span>
          <div className="hidden md:flex gap-8">
            <button 
              className={`font-semibold text-sm pb-1 transition-all border-b-2 active:scale-95 ${activeView === "dashboard" ? "text-primary border-primary" : "text-outline border-transparent hover:text-on-surface"}`}
              onClick={() => { setActiveView("dashboard"); setSelectedItemId(null); }}
            >
              {t("dashboard")}
            </button>
            <button 
              className={`font-semibold text-sm pb-1 transition-all border-b-2 active:scale-95 ${activeView === "inventory" ? "text-primary border-primary" : "text-outline border-transparent hover:text-on-surface"}`}
              onClick={() => { setActiveView("inventory"); setSelectedItemId(null); }}
            >
              {t("inventory")}
            </button>
            <button 
              className={`font-semibold text-sm pb-1 transition-all border-b-2 active:scale-95 ${activeView === "add-item" ? "text-primary border-primary" : "text-outline border-transparent hover:text-on-surface"}`}
              onClick={() => { resetForm(); setActiveView("add-item"); setSelectedItemId(null); }}
            >
              {t("addItem")}
            </button>
          </div>
        </div>

        <div className="flex items-center gap-1.5 sm:gap-3">
          {/* Household Switcher Pill */}
          <button 
            onClick={() => setShowHouseholdModal(true)}
            className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 bg-primary/10 hover:bg-primary/20 text-primary border border-primary/25 rounded-full text-xs font-bold active:scale-95 transition-all cursor-pointer shadow-2xs"
            title={t("manageHouseholds")}
          >
            <Home className="w-3.5 h-3.5 shrink-0" />
            <span className="max-w-[80px] sm:max-w-[130px] truncate">{currentHousehold?.name || t("household")}</span>
            <ChevronDown className="w-3 h-3 opacity-70 shrink-0" />
          </button>

          {/* Search bar inside header */}
          <div className="relative hidden sm:block">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-outline" />
            <input 
              type="text" 
              placeholder={t("searchPlaceholder")} 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9 pr-4 py-1.5 bg-surface-container-low border border-transparent rounded-full text-sm focus:ring-2 focus:ring-primary focus:bg-white w-64 outline-hidden transition-all text-on-surface"
            />
          </div>

          {/* Backup Cloud Slots Trigger */}
          {user && (
            <button 
              onClick={() => setShowSaveSlotsModal(true)}
              className="flex items-center gap-1 px-2.5 py-1.5 bg-surface-container hover:bg-surface-container-high rounded-full text-xs text-on-surface-variant font-medium active:scale-95 transition-all border border-outline-variant/30 cursor-pointer"
              title={t("backups")}
            >
              <Database className="w-3.5 h-3.5 text-primary" />
              <span className="hidden sm:inline">{t("backups")} ({saveSlots.length})</span>
              <span className="sm:hidden">{saveSlots.length}</span>
            </button>
          )}

          {/* Language Switch toggle button */}
          <button 
            onClick={() => setLanguage(language === "de" ? "en" : "de")}
            className="flex items-center gap-1 px-2.5 py-1.5 bg-surface-container hover:bg-surface-container-high rounded-full text-xs text-on-surface-variant font-extrabold active:scale-95 transition-all border border-outline-variant/30 cursor-pointer"
            title={language === "de" ? "Sprache wechseln (Englisch)" : "Change Language (German)"}
          >
            <Languages className="w-3.5 h-3.5 text-primary" />
            <span>{language === "de" ? "DE" : "EN"}</span>
          </button>

          {/* Dark Mode toggle button */}
          <button 
            onClick={() => setIsDarkMode(!isDarkMode)}
            className="p-1.5 sm:p-2 text-outline hover:bg-surface-container rounded-full transition-colors active:scale-95 cursor-pointer"
            title={language === "de" ? "Dunkelmodus umschalten" : "Toggle Dark Mode"}
          >
            {isDarkMode ? (
              <Sun className="w-4 h-4 sm:w-5 sm:h-5 text-amber-500" />
            ) : (
              <Moon className="w-4 h-4 sm:w-5 sm:h-5 text-on-surface-variant" />
            )}
          </button>

          {/* Notification bell and tray toggle */}
          <div className="relative">
            <button 
              onClick={() => { setShowNotifications(!showNotifications); miniNode.markNotificationsAsRead(); }}
              className="relative p-2 text-outline hover:bg-surface-container rounded-full transition-colors active:scale-95 cursor-pointer"
            >
              <Bell className="w-5 h-5 text-on-surface-variant" />
              {notifications.some(n => !n.read) && (
                <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-error ring-2 ring-surface animate-pulse" />
              )}
            </button>

            {/* Notification Drawer Popover */}
            {showNotifications && (
              <div className="absolute right-0 mt-2 w-80 bg-white border border-outline-variant shadow-xl rounded-xl overflow-hidden z-50 animate-in fade-in slide-in-from-top-3 duration-200">
                <div className="p-4 bg-surface-container-low border-b border-outline-variant flex justify-between items-center">
                  <h3 className="font-bold text-sm text-on-surface">{t("systemAlerts")}</h3>
                  <button onClick={() => setShowNotifications(false)} className="text-outline hover:text-on-surface">
                    <X className="w-4 h-4" />
                  </button>
                </div>
                <div className="max-h-64 overflow-y-auto custom-scrollbar p-2 space-y-1.5">
                  {notifications.length === 0 ? (
                    <p className="text-xs text-outline text-center py-6">{t("noAlerts")}</p>
                  ) : (
                    notifications.map(n => (
                      <div 
                        key={n.id} 
                        className={`p-2.5 rounded-lg text-xs hover:bg-surface-container transition-colors cursor-pointer border ${n.read ? "border-transparent" : "border-primary/15 bg-primary/5"}`}
                        onClick={() => {
                          setShowNotifications(false);
                          if (n.url) {
                            setSelectedItemId(n.url.replace("item-", ""));
                            setActiveView("item-detail");
                          }
                        }}
                      >
                        <p className="font-bold text-on-surface mb-0.5 flex items-center gap-1">
                          <span className="w-1.5 h-1.5 rounded-full bg-primary" />
                          {n.title}
                        </p>
                        <p className="text-on-surface-variant leading-relaxed">{n.body}</p>
                        <span className="text-[10px] text-outline block mt-1">
                          {new Date(n.timestamp).toLocaleTimeString("en-US", { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}
          </div>


        </div>
      </nav>

      {/* 2. Primary Layout: Sidebar and Main Canvas */}
      <div className="flex pt-16 min-h-screen">
        
        {/* Sidebar Nav */}
        <aside className="hidden lg:flex flex-col fixed left-0 top-16 bottom-0 w-64 p-4 gap-2 bg-surface-container-low border-r border-outline-variant">
          <div className="px-4 py-3 border-b border-outline-variant mb-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl flex items-center justify-center bg-primary/10 text-primary border border-primary/15 shrink-0">
                <Folder className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs text-outline uppercase tracking-wider">{t("brandName")}</p>
                <p className="font-bold text-sm text-on-surface">{items.length} {t("totalItems")}</p>
              </div>
            </div>
          </div>

          <nav className="flex-1 space-y-1.5 overflow-y-auto custom-scrollbar pr-1">
            <button 
              onClick={() => { setSelectedRoom("All Items"); setActiveView("inventory"); }}
              className={`flex items-center gap-3 w-full px-4 py-2.5 rounded-lg text-sm font-semibold transition-all active:translate-x-1 ${selectedRoom === "All Items" && activeView === "inventory" ? "bg-secondary-container text-on-secondary-container" : "text-on-surface-variant hover:bg-surface-container-high"}`}
            >
              <LayoutGrid className="w-4 h-4 text-outline" />
              <span>{t("allItems")}</span>
            </button>

            {rooms.map((room) => {
              // Translate room names on the fly for premium experience
              const displayRoom = room === "Kitchen" ? (language === "de" ? "Küche" : "Kitchen") 
                                : room === "Living Room" ? (language === "de" ? "Wohnzimmer" : "Living Room")
                                : room === "Bedroom" ? (language === "de" ? "Schlafzimmer" : "Bedroom")
                                : room === "Garage" ? (language === "de" ? "Garage" : "Garage")
                                : room;
              return (
                <button 
                  key={room}
                  onClick={() => { setSelectedRoom(room); setActiveView("inventory"); }}
                  className={`flex items-center gap-3 w-full px-4 py-2.5 rounded-lg text-sm font-semibold transition-all active:translate-x-1 ${selectedRoom === room && activeView === "inventory" ? "bg-secondary-container text-on-secondary-container" : "text-on-surface-variant hover:bg-surface-container-high"}`}
                >
                  <Folder className="w-4 h-4 text-outline" />
                  <span>{displayRoom}</span>
                </button>
              );
            })}
          </nav>

          <button 
            onClick={() => setShowAddRoomModal(true)}
            className="mx-2 mb-4 py-2.5 bg-primary text-on-primary font-bold text-xs rounded-lg shadow-xs hover:brightness-115 active:scale-95 transition-all text-center cursor-pointer"
          >
            {t("addNewRoom")}
          </button>

          {miniNode.isStandalone() && (
            <div className="border-t border-outline-variant pt-4 space-y-1">
              <div className="p-3 bg-surface dark:bg-surface-container rounded-lg border border-outline-variant text-[11px] text-on-surface-variant dark:text-on-surface leading-relaxed mb-2 flex gap-1.5 items-start">
                <Info className="w-3.5 h-3.5 shrink-0 mt-0.5" />
                <span>{t("offlineMode")}</span>
              </div>
            </div>
          )}
        </aside>

        {/* Main Canvas Area */}
        <main className="flex-1 lg:ml-64 p-3.5 sm:p-6 lg:p-10 pb-28 sm:pb-28 lg:pb-10 min-h-screen w-full max-w-full overflow-x-hidden">
          
          {loading && (
            <div className="fixed inset-0 bg-background/50 backdrop-blur-xs z-50 flex flex-col items-center justify-center gap-3">
              <div className="w-12 h-12 rounded-full border-4 border-primary border-t-transparent animate-spin" />
              <p className="text-xs font-bold text-primary">Synchronizing cloud assets...</p>
            </div>
          )}

          {/* SCREEN 1: Dashboard View */}
          {activeView === "dashboard" && (
            <motion.div 
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.25, ease: "easeOut" }}
              className="max-w-[1200px] mx-auto space-y-8"
            >
              <header className="flex justify-between items-start">
                <div>
                  <h1 className="text-3xl font-bold tracking-tight text-on-surface">{t("dashboard")}</h1>
                  <p className="text-sm text-outline mt-1">{t("welcomeBack")}</p>
                </div>
              </header>

              {/* Bento Grid Stats Cards (Total Items, Total Portfolio Value, Storage space used, and Urgent Warranty Alerts) */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
                
                {/* 1. Total Items */}
                <div className="bg-surface border border-outline-variant rounded-2xl p-5 sm:p-6 shadow-xs flex flex-col justify-between hover:border-primary/40 transition-colors">
                  <div>
                    <div className="flex items-center justify-between">
                      <p className="text-[11px] text-outline uppercase tracking-wider font-semibold">{t("totalItems")}</p>
                      <span className="p-2 rounded-xl bg-primary/10 text-primary">
                        <Folder className="w-4 h-4" />
                      </span>
                    </div>
                    <div className="flex items-baseline gap-2 mt-3">
                      <span className="text-3xl sm:text-4xl font-extrabold text-primary">{totalItemsCount}</span>
                      <span className="text-emerald-700 dark:text-emerald-400 text-xs font-bold flex items-center gap-0.5">
                        <Plus className="w-3 h-3" /> {items.length} {t("added")}
                      </span>
                    </div>
                  </div>
                  <p className="text-[11px] text-outline mt-4 pt-3 border-t border-outline-variant/30 flex items-center justify-between">
                    <span>{rooms.length} {language === "de" ? "Räume erfasst" : "room zones"}</span>
                    <span className="text-on-surface font-semibold">{categoryStats.list.length} {language === "de" ? "Kategorien" : "categories"}</span>
                  </p>
                </div>

                {/* 2. Total Portfolio Value */}
                <div className="bg-surface border border-outline-variant rounded-2xl p-5 sm:p-6 shadow-xs flex flex-col justify-between hover:border-secondary/40 transition-colors">
                  <div>
                    <div className="flex items-center justify-between">
                      <p className="text-[11px] text-outline uppercase tracking-wider font-semibold">{t("totalValue")}</p>
                      <span className="p-2 rounded-xl bg-secondary/10 text-secondary">
                        <CreditCard className="w-4 h-4" />
                      </span>
                    </div>
                    <div className="mt-3">
                      <span className="text-2xl sm:text-3xl font-extrabold text-on-surface tracking-tight">
                        {formatCurrency(totalPortfolioValue)}
                      </span>
                    </div>
                  </div>
                  <p className="text-[11px] text-outline mt-4 pt-3 border-t border-outline-variant/30 flex items-center justify-between truncate">
                    <span>{language === "de" ? "Versicherungsstatus:" : "Policy status:"}</span>
                    {totalPortfolioValue > insuranceLimit ? (
                      <span className="text-error font-bold">{language === "de" ? "Unterversichert" : "Exceeds limit"}</span>
                    ) : (
                      <span className="text-emerald-600 dark:text-emerald-400 font-bold">{language === "de" ? "Optimal gedeckt" : "100% covered"}</span>
                    )}
                  </p>
                </div>

                {/* 3. Household & Members (Replaced storage card as requested) */}
                <div 
                  onClick={() => setShowHouseholdModal(true)}
                  className="bg-surface border border-outline-variant rounded-2xl p-5 sm:p-6 shadow-xs flex flex-col justify-between hover:border-primary/40 transition-colors cursor-pointer group"
                >
                  <div>
                    <div className="flex items-center justify-between">
                      <p className="text-[11px] text-outline uppercase tracking-wider font-semibold">{t("household")}</p>
                      <span className="p-2 rounded-xl bg-primary/10 text-primary group-hover:scale-105 transition-transform">
                        <Home className="w-4 h-4" />
                      </span>
                    </div>
                    <div className="mt-3">
                      <span className="text-xl sm:text-2xl font-extrabold text-on-surface tracking-tight block truncate">
                        {currentHousehold?.name || (language === "de" ? "Hauptwohnung" : "Primary Home")}
                      </span>
                      <p className="text-xs text-primary font-semibold mt-1 flex items-center gap-1.5">
                        <Users className="w-3.5 h-3.5" />
                        <span>{currentHousehold?.members.length || 1} {t("householdMembers")}</span>
                      </p>
                    </div>
                  </div>
                  <p className="text-[11px] text-outline mt-4 pt-3 border-t border-outline-variant/30 flex items-center justify-between">
                    <span className="text-primary font-semibold group-hover:underline flex items-center gap-1">
                      {t("manageHouseholds")}
                      <ChevronRight className="w-3 h-3" />
                    </span>
                    <span className="text-[10px] text-outline">
                      {households.length} {language === "de" ? (households.length === 1 ? "Haushalt" : "Haushalte") : (households.length === 1 ? "Household" : "Households")}
                    </span>
                  </p>
                </div>

                {/* 4. Urgent Warranty Alerts */}
                {hasWarrantiesExpiringSoon ? (
                  <div className="bg-error-container text-on-error-container rounded-2xl p-5 sm:p-6 flex flex-col justify-between relative overflow-hidden shadow-xs border border-error/15">
                    <div className="z-10">
                      <div className="flex items-center gap-1.5 mb-1.5 text-error">
                        <ShieldAlert className="w-4 h-4 shrink-0" />
                        <p className="text-[10px] font-extrabold uppercase tracking-widest">{t("attentionRequired")}</p>
                      </div>
                      <h3 className="text-base sm:text-lg font-bold text-on-error-container">
                        {activeExpiringItems.filter(x => x.days <= 60).length} {t("warrantiesExpiring")}
                      </h3>
                      <p className="text-xs text-on-error-container/85 mt-1 leading-snug line-clamp-2">
                        {language === "de" ? (
                          <>Garantie für <strong>"{activeExpiringItems[0]?.item.name}"</strong> endet in {activeExpiringItems[0]?.days} Tagen.</>
                        ) : (
                          <>Warranty for <strong>"{activeExpiringItems[0]?.item.name}"</strong> ends in {activeExpiringItems[0]?.days} days.</>
                        )}
                      </p>
                    </div>
                    <button 
                      onClick={() => { 
                        setSelectedCategory("All Categories"); 
                        setSelectedRoom("All Items");
                        setSelectedWarrantyFilter("Expiring");
                        setActiveView("inventory"); 
                      }}
                      className="mt-4 w-full bg-on-error-container text-white py-2 rounded-xl font-bold text-xs hover:shadow-md transition-all active:scale-95 cursor-pointer border-none z-10"
                    >
                      {t("reviewWarranties")}
                    </button>
                    <ShieldAlert className="absolute -right-3 -bottom-3 w-28 h-28 text-on-error-container/5 pointer-events-none transform rotate-12" />
                  </div>
                ) : (
                  <div className="bg-surface border border-outline-variant rounded-2xl p-5 sm:p-6 flex flex-col justify-between relative overflow-hidden shadow-xs">
                    <div className="z-10">
                      <div className="flex items-center gap-1.5 mb-1.5 text-emerald-600 dark:text-emerald-400">
                        <CheckCircle2 className="w-4 h-4 shrink-0" />
                        <p className="text-[10px] font-extrabold uppercase tracking-widest">
                          {language === "de" ? "Garantien Status" : "Warranty Status"}
                        </p>
                      </div>
                      <h3 className="text-base sm:text-lg font-bold text-on-surface">
                        {language === "de" ? "Alle Garantien in Ordnung" : "All Warranties in Order"}
                      </h3>
                      <p className="text-xs text-outline mt-1 leading-snug">
                        {language === "de" 
                          ? "Keine anstehenden Garantieabläufe in den nächsten 30 Tagen." 
                          : "No upcoming expirations approaching in 30 days."}
                      </p>
                    </div>
                    <button 
                      onClick={() => { 
                        setSelectedCategory("All Categories"); 
                        setSelectedRoom("All Items");
                        setSelectedWarrantyFilter("All");
                        setActiveView("inventory"); 
                      }}
                      className="mt-4 w-full bg-emerald-600 hover:bg-emerald-700 text-white py-2 rounded-xl font-bold text-xs hover:shadow-md transition-all active:scale-95 cursor-pointer border-none z-10"
                    >
                      {language === "de" ? "Inventar ansehen" : "View Inventory"}
                    </button>
                    <CheckCircle2 className="absolute -right-3 -bottom-3 w-28 h-28 text-emerald-600/5 dark:text-emerald-400/5 pointer-events-none transform rotate-12" />
                  </div>
                )}
              </div>

              {/* Quick Actions (Add Item, Scan Receipt, Generate Report) */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <button 
                  onClick={() => { resetForm(); setActiveView("add-item"); }}
                  className="bg-surface border border-outline-variant hover:border-primary/50 hover:bg-primary/5 rounded-2xl p-5 flex items-center gap-4 transition-all duration-200 shadow-xs cursor-pointer active:scale-98 text-left group"
                >
                  <div className="w-12 h-12 rounded-xl bg-primary/10 text-primary group-hover:bg-primary group-hover:text-white flex items-center justify-center shrink-0 transition-colors">
                    <Plus className="w-6 h-6" />
                  </div>
                  <div className="min-w-0">
                    <h4 className="text-sm font-bold text-on-surface group-hover:text-primary transition-colors truncate">{t("addItem")}</h4>
                    <p className="text-xs text-outline mt-0.5 truncate">{language === "de" ? "Manuelle Registrierung" : "Manual item registration"}</p>
                  </div>
                </button>

                <button 
                  onClick={() => setShowScanReceiptModal(true)}
                  className="bg-surface border border-outline-variant hover:border-secondary/50 hover:bg-secondary/5 rounded-2xl p-5 flex items-center gap-4 transition-all duration-200 shadow-xs cursor-pointer active:scale-98 text-left group"
                >
                  <div className="w-12 h-12 rounded-xl bg-secondary/10 text-secondary group-hover:bg-secondary group-hover:text-white flex items-center justify-center shrink-0 transition-colors">
                    <UploadCloud className="w-6 h-6" />
                  </div>
                  <div className="min-w-0">
                    <h4 className="text-sm font-bold text-on-surface group-hover:text-secondary transition-colors truncate">{t("scanReceipt")}</h4>
                    <p className="text-xs text-outline mt-0.5 truncate">{language === "de" ? "Kaufbeleg erfassen & zuweisen" : "Scan receipt or bill invoice"}</p>
                  </div>
                </button>

                <button 
                  onClick={() => {
                    exportToExcel(items, language, insuranceLimit);
                    showToast(language === "de" ? "Excel-Bericht wird heruntergeladen..." : "Downloading Excel report...", "success");
                  }}
                  className="bg-surface border border-outline-variant hover:border-emerald-500/50 hover:bg-emerald-500/5 rounded-2xl p-5 flex items-center gap-4 transition-all duration-200 shadow-xs cursor-pointer active:scale-98 text-left group"
                >
                  <div className="w-12 h-12 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 group-hover:bg-emerald-600 group-hover:text-white flex items-center justify-center shrink-0 transition-colors">
                    <Download className="w-6 h-6" />
                  </div>
                  <div className="min-w-0">
                    <h4 className="text-sm font-bold text-on-surface group-hover:text-emerald-600 transition-colors truncate">{t("generateReport")}</h4>
                    <p className="text-xs text-outline mt-0.5 truncate">{language === "de" ? "Excel-Datenblatt exportieren" : "Export full Excel ledger"}</p>
                  </div>
                </button>
              </div>

              {/* Recently Added items subsection */}
              <section className="space-y-4">
                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-bold text-on-surface">{t("recentlyAdded")}</h2>
                  <button 
                    onClick={() => setActiveView("inventory")}
                    className="text-primary font-bold text-xs flex items-center gap-1 hover:underline underline-offset-4"
                  >
                    <span>{t("viewAllInventory")}</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>

                {items.length === 0 ? (
                  <div className="bg-surface border border-dashed border-outline-variant/80 rounded-2xl p-8 sm:p-10 text-center">
                    <div className="w-14 h-14 rounded-2xl bg-primary/10 text-primary flex items-center justify-center mx-auto mb-3 shadow-xs">
                      <Folder className="w-7 h-7" />
                    </div>
                    <h3 className="text-base sm:text-lg font-bold text-on-surface">
                      {language === "de" ? "Noch keine Gegenstände im Inventar" : "No items in inventory yet"}
                    </h3>
                    <p className="text-xs text-outline mt-1.5 max-w-md mx-auto leading-relaxed">
                      {language === "de" 
                        ? "Dein Inventar ist noch leer. Erfasse jetzt deinen ersten Haushaltsgegenstand mit Kaufbeleg, Garantie und Besitzerzuweisung." 
                        : "Your inventory is currently empty. Record your first asset with receipt, warranty and owner assignment."}
                    </p>
                    <div className="mt-5 flex flex-wrap justify-center gap-3">
                      <button 
                        onClick={() => { resetForm(); setActiveView("add-item"); }}
                        className="px-5 py-2.5 bg-primary text-on-primary font-bold text-xs rounded-xl shadow-xs hover:brightness-110 active:scale-95 transition-all flex items-center gap-1.5 cursor-pointer border-none"
                      >
                        <Plus className="w-4 h-4" />
                        <span>{t("addItem")}</span>
                      </button>
                      <button 
                        onClick={() => setShowScanReceiptModal(true)}
                        className="px-5 py-2.5 bg-surface-container hover:bg-surface-container-high text-on-surface font-bold text-xs rounded-xl border border-outline-variant/60 active:scale-95 transition-all flex items-center gap-1.5 cursor-pointer"
                      >
                        <UploadCloud className="w-4 h-4 text-primary" />
                        <span>{t("scanReceipt")}</span>
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                    {items.slice(0, 4).map((item) => {
                      const statusObj = getWarrantyBadgeColor(item.warrantyExpiry);
                      return (
                        <div 
                          key={item.id}
                          onClick={() => { setSelectedItemId(item.id); setActiveView("item-detail"); }}
                          className="bg-surface border border-outline-variant rounded-2xl overflow-hidden shadow-sm hover:translate-y-[-4px] transition-all cursor-pointer group"
                        >
                          <div className="h-40 w-full relative bg-surface-container-low overflow-hidden">
                            {item.photoUrl ? (
                              <img 
                                src={item.photoUrl} 
                                alt={item.name} 
                                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 animate-fade-in"
                              />
                            ) : (
                              <div className="w-full h-full flex flex-col items-center justify-center text-outline">
                                <ImageIcon className="w-8 h-8 opacity-45 mb-1" />
                                <span className="text-[10px] uppercase">{t("noPhoto")}</span>
                              </div>
                            )}
                            <div className={`absolute top-3 right-3 px-2.5 py-1 rounded-full text-[10px] font-bold ${statusObj.bg}`}>
                              {statusObj.label}
                            </div>
                            {/* Audio TTS button right on the card for high-fidelity experience */}
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                speakItemGerman(item);
                              }}
                              className="absolute bottom-3 right-3 p-1.5 bg-surface/85 backdrop-blur-xs rounded-full text-primary hover:text-primary-container active:scale-90 transition-all border border-outline-variant/20 shadow-xs"
                              title={t("speechDesc")}
                            >
                              <Volume2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                          <div className="p-4">
                            <div className="flex items-center justify-between text-[10px] text-outline uppercase tracking-wider font-semibold">
                              <span>
                                {item.location === "Kitchen" ? (language === "de" ? "Küche" : "Kitchen") 
                                 : item.location === "Living Room" ? (language === "de" ? "Wohnzimmer" : "Living Room")
                                 : item.location === "Bedroom" ? (language === "de" ? "Schlafzimmer" : "Bedroom")
                                 : item.location === "Garage" ? (language === "de" ? "Garage" : "Garage")
                                 : item.location} &bull; {getCategoryTranslation(item.category, language)}
                              </span>
                              {item.owner && (
                                <span className="text-primary font-bold flex items-center gap-0.5 normal-case">
                                  <User className="w-2.5 h-2.5" />
                                  {item.owner}
                                </span>
                              )}
                            </div>
                            <h4 className="font-bold text-sm text-on-surface mt-1 tracking-tight truncate group-hover:text-primary transition-colors">
                              {item.name}
                            </h4>
                            <div className="flex justify-between items-center mt-4 pt-3 border-t border-outline-variant/30">
                              <span className="text-xs font-extrabold text-on-surface">{formatCurrency(item.purchasePrice)}</span>
                              <span className="text-[10px] text-outline">{t("activeWarranty")}</span>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </section>

              {/* Upcoming Maintenance Section */}
              <section className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="text-xl font-bold text-on-surface flex items-center gap-2">
                      <Wrench className="w-5 h-5 text-primary" />
                      {language === "de" ? "Anstehende Wartung" : "Upcoming Maintenance"}
                    </h2>
                    <p className="text-xs text-outline mt-1">
                      {language === "de" 
                        ? "Empfohlene Serviceintervalle zur Maximierung der Lebensdauer Ihrer Geräte." 
                        : "Recommended service schedules to maximize the lifespan of your assets."}
                    </p>
                  </div>
                </div>

                {itemsNeedingMaintenance.length === 0 ? (
                  <div className="bg-surface border border-outline-variant rounded-2xl p-8 text-center max-w-full">
                    <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto mb-3 opacity-80" />
                    <h3 className="text-base font-bold text-on-surface">
                      {language === "de" ? "Alles in Ordnung!" : "All Good!"}
                    </h3>
                    <p className="text-xs text-outline mt-1 max-w-md mx-auto">
                      {language === "de" 
                        ? "Derzeit sind keine Wartungen fällig oder geplant. Fügen Sie Gegenstände mit empfohlenen Wartungsterminen hinzu, um Erinnerungen zu erhalten." 
                        : "No maintenance tasks are currently due or scheduled. Add items with recommended service dates to stay on top of them."}
                    </p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {itemsNeedingMaintenance.slice(0, 3).map(({ item, date, days, isOverdue, isDueSoon }) => {
                      const formattedDate = new Date(date).toLocaleDateString(
                        language === "de" ? "de-DE" : "en-US",
                        { day: "numeric", month: "short", year: "numeric" }
                      );
                      const description = getMaintenanceDescription(item.name, item.category, language);
                      
                      return (
                        <div 
                          key={`maint-${item.id}`}
                          className={`bg-surface border rounded-2xl p-5 flex flex-col justify-between shadow-xs transition-all relative ${
                            isOverdue 
                              ? "border-red-300 dark:border-red-900 bg-red-50/20 dark:bg-red-950/10" 
                              : isDueSoon 
                                ? "border-amber-300 dark:border-amber-900 bg-amber-50/20 dark:bg-amber-950/10"
                                : "border-outline-variant"
                          }`}
                        >
                          <div>
                            <div className="flex justify-between items-start gap-2 mb-2">
                              <span className="text-[10px] text-outline uppercase tracking-wider font-semibold">
                                {item.location === "Kitchen" ? (language === "de" ? "Küche" : "Kitchen") 
                                 : item.location === "Living Room" ? (language === "de" ? "Wohnzimmer" : "Living Room")
                                 : item.location === "Bedroom" ? (language === "de" ? "Schlafzimmer" : "Bedroom")
                                 : item.location === "Garage" ? (language === "de" ? "Garage" : "Garage")
                                 : item.location}
                              </span>
                              
                              {isOverdue ? (
                                <span className="bg-red-100 text-red-800 dark:bg-red-950/30 dark:text-red-300 text-[10px] font-bold px-2.5 py-0.5 rounded-full flex items-center gap-1">
                                  <ShieldAlert className="w-3 h-3" />
                                  {language === "de" ? "Überfällig" : "Overdue"}
                                </span>
                              ) : isDueSoon ? (
                                <span className="bg-amber-100 text-amber-800 dark:bg-amber-950/30 dark:text-amber-300 text-[10px] font-bold px-2.5 py-0.5 rounded-full flex items-center gap-1">
                                  <Clock className="w-3 h-3" />
                                  {language === "de" ? `In ${days} Tagen` : `In ${days} Days`}
                                </span>
                              ) : (
                                <span className="bg-surface-container text-outline text-[10px] font-semibold px-2.5 py-0.5 rounded-full flex items-center gap-1">
                                  <Calendar className="w-3 h-3" />
                                  {language === "de" ? `In ${days} Tagen` : `In ${days} Days`}
                                </span>
                              )}
                            </div>

                            <h4 
                              onClick={() => { setSelectedItemId(item.id); setActiveView("item-detail"); }}
                              className="font-bold text-sm text-on-surface hover:text-primary cursor-pointer transition-colors line-clamp-1 mt-1"
                            >
                              {item.name}
                            </h4>
                            
                            <p className="text-xs text-outline mt-1.5 leading-relaxed line-clamp-2 italic min-h-[36px]">
                              "{description}"
                            </p>
                          </div>

                          <div className="mt-4 pt-3 border-t border-outline-variant/30 flex justify-between items-center">
                            <div className="flex flex-col">
                              <span className="text-[10px] text-outline font-medium">
                                {language === "de" ? "Fälligkeitstermin" : "Scheduled Date"}
                              </span>
                              <span className="text-xs font-bold text-on-surface">
                                {formattedDate}
                              </span>
                            </div>

                            <button 
                              onClick={() => handleCompleteMaintenance(item)}
                              className="bg-primary text-on-primary text-[10px] font-bold px-3 py-1.5 rounded-lg shadow-xs hover:brightness-110 active:scale-95 transition-all border-none cursor-pointer"
                            >
                              {language === "de" ? "Erledigt" : "Mark Done"}
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </section>

              {/* Bottom Insights Section */}
              <section className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-surface border border-outline-variant rounded-2xl p-6 flex flex-col gap-4 shadow-sm">
                  <div className="w-12 h-12 rounded-xl bg-surface-container flex items-center justify-center text-primary">
                    <LayoutGrid className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-on-surface">{t("assetDistribution")}</h3>
                    <p className="text-xs text-outline mt-1 leading-relaxed">
                      {items.length === 0 ? (
                        language === "de" 
                          ? "Fügen Sie Gegenstände zu Ihrem Inventar hinzu, um Ihre dynamischen Analysen und Diagramme zur Anlagenverteilung zu erstellen."
                          : "Add items to your inventory to generate your dynamic asset distribution analytics and charts."
                      ) : (
                        language === "de"
                          ? `Ihre Top-Kategorie ist "${getCategoryTranslation(categoryStats.list[0]?.category, "de")}", die €${categoryStats.list[0]?.value.toLocaleString("de-DE", { minimumFractionDigits: 0, maximumFractionDigits: 0 })} (${categoryStats.list[0]?.percentage.toFixed(0)}%) Ihres dokumentierten Haushaltsvermögens ausmacht.`
                          : `Your top category is "${categoryStats.list[0]?.category}", representing €${categoryStats.list[0]?.value.toLocaleString("en-US", { minimumFractionDigits: 0, maximumFractionDigits: 0 })} (${categoryStats.list[0]?.percentage.toFixed(0)}%) of your documented portfolio value.`
                      )}
                    </p>
                  </div>
                  <div className="mt-auto pt-4">
                    <button 
                      onClick={() => setShowDeepDiveModal(true)}
                      className="text-primary font-bold text-xs border border-primary px-4 py-2 rounded-lg hover:bg-primary hover:text-white transition-all cursor-pointer active:scale-95 bg-transparent"
                    >
                      {t("deepDive")}
                    </button>
                  </div>
                </div>

                <div className="bg-surface border border-outline-variant rounded-2xl p-6 flex flex-col gap-4 shadow-sm border-l-4 border-l-secondary">
                  <div className="w-12 h-12 rounded-xl bg-secondary-container text-secondary flex items-center justify-center">
                    <CheckCircle2 className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-on-surface">{t("insuranceOpt")}</h3>
                    <p className="text-xs text-outline mt-1 leading-relaxed">
                      {items.length === 0 ? (
                        language === "de"
                          ? "Legen Sie Ihr Versicherungslimit fest, um Ihren Abdeckungsstatus und eventuelle Unterversicherungen zu überwachen."
                          : "Set your insurance limit to monitor your coverage status and potential underinsurance gaps."
                      ) : (
                        categoryStats.totalValue > insuranceLimit ? (
                          language === "de"
                            ? `⚠️ Achtung: Sie sind um €${(categoryStats.totalValue - insuranceLimit).toLocaleString("de-DE", { minimumFractionDigits: 0, maximumFractionDigits: 0 })} unterversichert! Ihr Besitz übersteigt Ihr Versicherungslimit von €${insuranceLimit.toLocaleString("de-DE")}.`
                            : `⚠️ Warning: You are underinsured by €${(categoryStats.totalValue - insuranceLimit).toLocaleString("en-US", { minimumFractionDigits: 0, maximumFractionDigits: 0 })}! Your assets exceed your coverage limit of €${insuranceLimit.toLocaleString("en-US")}.`
                        ) : (
                          language === "de"
                            ? `Ausreichend versichert! Ihr Gesamtwert von €${categoryStats.totalValue.toLocaleString("de-DE", { minimumFractionDigits: 0, maximumFractionDigits: 0 })} liegt voll im Rahmen Ihres Versicherungslimits von €${insuranceLimit.toLocaleString("de-DE")}.`
                            : `Fully covered! Your total asset value of €${categoryStats.totalValue.toLocaleString("en-US", { minimumFractionDigits: 0, maximumFractionDigits: 0 })} is safely within your coverage limit of €${insuranceLimit.toLocaleString("en-US")}.`
                        )
                      )}
                    </p>
                  </div>
                  <div className="mt-auto pt-4">
                    <button 
                      onClick={() => setShowInsuranceModal(true)}
                      className="bg-secondary text-white font-bold text-xs px-4 py-2 rounded-lg hover:brightness-110 transition-all cursor-pointer active:scale-95 border-none"
                    >
                      {t("updateAudit")}
                    </button>
                  </div>
                </div>
              </section>
            </motion.div>
          )}

          {/* SCREEN 2: Inventory Items List view */}
          {activeView === "inventory" && (
            <motion.div 
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.25, ease: "easeOut" }}
              className="max-w-[1200px] mx-auto space-y-6 sm:space-y-8"
            >
              {/* Header and Toolbar - fully responsive without overflowing mobile viewport */}
              <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3 sm:gap-4">
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-on-surface">{t("inventory")}</h1>
                    <span className="px-2.5 py-0.5 rounded-full bg-surface-container-high text-xs font-bold text-primary">
                      {filteredItems.length}
                    </span>
                  </div>
                  <p className="text-xs sm:text-sm text-outline mt-0.5 truncate">
                    {language === "de" ? "Verwalten und verfolgen Sie Ihre wertvollen Gegenstände." : "Manage and track your high-value physical assets."}
                  </p>
                </div>

                {/* Action buttons with view-toggle that fit gracefully on any phone screen */}
                <div className="flex items-center gap-1.5 sm:gap-2.5 w-full sm:w-auto">
                  {/* Grid / List Mode Switcher */}
                  <div className="flex items-center bg-surface-container rounded-xl p-1 border border-outline-variant/40 shrink-0">
                    <button 
                      type="button"
                      onClick={() => setInventoryViewMode("grid")}
                      className={`p-1.5 sm:p-2 rounded-lg transition-all cursor-pointer ${inventoryViewMode === "grid" ? "bg-surface text-primary shadow-xs" : "text-outline hover:text-on-surface"}`}
                      title={language === "de" ? "Rasteransicht" : "Grid View"}
                    >
                      <LayoutGrid className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                    </button>
                    <button 
                      type="button"
                      onClick={() => setInventoryViewMode("list")}
                      className={`p-1.5 sm:p-2 rounded-lg transition-all cursor-pointer ${inventoryViewMode === "list" ? "bg-surface text-primary shadow-xs" : "text-outline hover:text-on-surface"}`}
                      title={language === "de" ? "Listenansicht" : "List View"}
                    >
                      <List className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                    </button>
                  </div>

                  {/* Reset Filters (Visible if filters active or on demand) */}
                  {(selectedCategory !== "All Categories" || selectedRoom !== "All Items" || selectedWarrantyFilter !== "All" || searchQuery) && (
                    <button 
                      onClick={() => { setSelectedCategory("All Categories"); setSelectedRoom("All Items"); setSelectedWarrantyFilter("All"); setSearchQuery(""); }}
                      className="flex-1 sm:flex-initial flex items-center justify-center gap-1 px-2.5 h-9 sm:h-10 border border-error/30 bg-error/10 text-error hover:bg-error/20 font-bold text-xs rounded-xl shadow-xs transition-all active:scale-95 cursor-pointer whitespace-nowrap shrink-0"
                    >
                      <X className="w-3.5 h-3.5" />
                      <span className="hidden sm:inline">{t("resetFilters")}</span>
                      <span className="sm:hidden">{language === "de" ? "Reset" : "Clear"}</span>
                    </button>
                  )}

                  {/* XLSX Download button */}
                  <button 
                    onClick={() => exportToExcel(items, language, insuranceLimit)}
                    className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 px-3 h-9 sm:h-10 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-xs hover:brightness-110 transition-all active:scale-95 cursor-pointer border-none whitespace-nowrap shrink-0"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">{language === "de" ? "XLSX exportieren" : "Export XLSX"}</span>
                    <span className="sm:hidden">XLSX</span>
                  </button>

                  {/* Add Room button */}
                  <button 
                    onClick={() => setShowAddRoomModal(true)}
                    className="flex-1 sm:flex-initial flex items-center justify-center gap-1 px-3 h-9 sm:h-10 bg-primary text-on-primary font-bold text-xs rounded-xl shadow-xs hover:brightness-115 transition-all active:scale-95 cursor-pointer border-none whitespace-nowrap shrink-0"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">{t("addNewRoom")}</span>
                    <span className="sm:hidden">{language === "de" ? "+ Raum" : "+ Room"}</span>
                  </button>
                </div>
              </div>

              {/* Mobile Search Bar (Full-width, clean with clear button) */}
              <div className="relative block sm:hidden w-full">
                <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-outline pointer-events-none" />
                <input 
                  type="text" 
                  placeholder={t("searchPlaceholder")} 
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-9 py-2.5 bg-surface border border-outline-variant/60 rounded-xl text-base focus:ring-2 focus:ring-primary focus:bg-white outline-hidden transition-all text-on-surface shadow-2xs"
                />
                {searchQuery && (
                  <button 
                    onClick={() => setSearchQuery("")}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-outline hover:text-on-surface p-1 rounded-full bg-surface-container"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>

              {/* Bento filter stats panel - Responsive 2x2 on mobile, 4 on desktop, never overflows */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5 sm:gap-4">
                <button 
                  onClick={() => setSelectedWarrantyFilter("All")}
                  className={`p-3 sm:p-4 border rounded-xl shadow-xs flex flex-col justify-between transition-all hover:scale-[1.01] active:scale-95 text-left bg-surface border-solid cursor-pointer min-w-0 ${
                    selectedWarrantyFilter === "All" 
                      ? "border-primary ring-2 ring-primary/40 bg-primary/5" 
                      : "border-outline-variant/60 hover:bg-surface-container-high"
                  }`}
                >
                  <div className="flex items-center justify-between w-full">
                    <div className="w-7 h-7 sm:w-9 sm:h-9 rounded-lg bg-primary/10 text-primary flex items-center justify-center shrink-0">
                      <LayoutGrid className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                    </div>
                    <span className="text-base sm:text-xl font-black text-on-surface">{items.length}</span>
                  </div>
                  <p className="text-[10px] sm:text-xs text-outline uppercase tracking-wider font-semibold truncate mt-2">
                    {t("totalItems")}
                  </p>
                </button>

                <button 
                  onClick={() => setSelectedWarrantyFilter("Active")}
                  className={`p-3 sm:p-4 border rounded-xl shadow-xs flex flex-col justify-between transition-all hover:scale-[1.01] active:scale-95 text-left bg-surface border-solid cursor-pointer min-w-0 ${
                    selectedWarrantyFilter === "Active" 
                      ? "border-emerald-500 ring-2 ring-emerald-500/40 bg-emerald-500/5" 
                      : "border-outline-variant/60 hover:bg-surface-container-high"
                  }`}
                >
                  <div className="flex items-center justify-between w-full">
                    <div className="w-7 h-7 sm:w-9 sm:h-9 rounded-lg bg-emerald-50 dark:bg-emerald-950/20 text-emerald-700 dark:text-emerald-400 flex items-center justify-center shrink-0">
                      <CheckCircle2 className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                    </div>
                    <span className="text-base sm:text-xl font-black text-on-surface">{activeWarrantiesCount}</span>
                  </div>
                  <p className="text-[10px] sm:text-xs text-outline uppercase tracking-wider font-semibold truncate mt-2">
                    {t("activeWarranty")}
                  </p>
                </button>

                <button 
                  onClick={() => setSelectedWarrantyFilter("Expiring")}
                  className={`p-3 sm:p-4 border rounded-xl shadow-xs flex flex-col justify-between transition-all hover:scale-[1.01] active:scale-95 text-left bg-surface border-solid cursor-pointer min-w-0 ${
                    selectedWarrantyFilter === "Expiring" 
                      ? "border-amber-500 ring-2 ring-amber-500/40 bg-amber-500/5" 
                      : "border-outline-variant/60 hover:bg-surface-container-high"
                  }`}
                >
                  <div className="flex items-center justify-between w-full">
                    <div className="w-7 h-7 sm:w-9 sm:h-9 rounded-lg bg-amber-50 dark:bg-amber-950/20 text-amber-700 dark:text-amber-400 flex items-center justify-center shrink-0">
                      <Clock className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                    </div>
                    <span className="text-base sm:text-xl font-black text-on-surface">{expiringWarrantiesCount}</span>
                  </div>
                  <p className="text-[10px] sm:text-xs text-outline uppercase tracking-wider font-semibold truncate mt-2">
                    {t("expiringSoon")}
                  </p>
                </button>

                <button 
                  onClick={() => setSelectedWarrantyFilter("Expired")}
                  className={`p-3 sm:p-4 border rounded-xl shadow-xs flex flex-col justify-between transition-all hover:scale-[1.01] active:scale-95 text-left bg-surface border-solid cursor-pointer min-w-0 ${
                    selectedWarrantyFilter === "Expired" 
                      ? "border-red-500 ring-2 ring-red-500/40 bg-red-500/5" 
                      : "border-outline-variant/60 hover:bg-surface-container-high"
                  }`}
                >
                  <div className="flex items-center justify-between w-full">
                    <div className="w-7 h-7 sm:w-9 sm:h-9 rounded-lg bg-red-50 dark:bg-red-950/20 text-error flex items-center justify-center shrink-0">
                      <ShieldAlert className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                    </div>
                    <span className="text-base sm:text-xl font-black text-on-surface">{expiredWarrantiesCount}</span>
                  </div>
                  <p className="text-[10px] sm:text-xs text-outline uppercase tracking-wider font-semibold truncate mt-2">
                    {t("expired")}
                  </p>
                </button>
              </div>

              {/* Mobile/Tablet Room filter carousel - contained, zero horizontal viewport stretch */}
              <div className="lg:hidden space-y-2">
                <div className="flex justify-between items-center px-0.5">
                  <span className="text-[11px] font-extrabold uppercase tracking-wider text-on-surface-variant">{language === "de" ? "Räume & Aufteilungen" : "Rooms & Collections"}</span>
                  <button 
                    onClick={() => setShowAddRoomModal(true)}
                    className="text-primary font-bold text-xs flex items-center gap-1 bg-transparent border-none cursor-pointer hover:underline"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>{t("addNewRoom")}</span>
                  </button>
                </div>
                
                <div className="w-full max-w-full overflow-x-auto no-scrollbar scroll-smooth flex items-center gap-2 pb-1">
                  <button 
                    onClick={() => { setSelectedRoom("All Items"); }}
                    className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all border border-solid shrink-0 ${selectedRoom === "All Items" ? "bg-primary text-on-primary border-primary shadow-xs" : "bg-surface text-on-surface-variant border-outline-variant/60 hover:bg-surface-container"}`}
                  >
                    <LayoutGrid className="w-3.5 h-3.5" />
                    <span>{t("allItems")} ({items.length})</span>
                  </button>
                  {rooms.map(room => {
                    const displayRoom = room === "Kitchen" ? (language === "de" ? "Küche" : "Kitchen") 
                                      : room === "Living Room" ? (language === "de" ? "Wohnzimmer" : "Living Room")
                                      : room === "Bedroom" ? (language === "de" ? "Schlafzimmer" : "Bedroom")
                                      : room === "Garage" ? (language === "de" ? "Garage" : "Garage")
                                      : room;
                    const roomCount = items.filter(i => i.location === room).length;
                    return (
                      <button 
                        key={room}
                        onClick={() => { setSelectedRoom(room); }}
                        className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all border border-solid shrink-0 ${selectedRoom === room ? "bg-primary text-on-primary border-primary shadow-xs" : "bg-surface text-on-surface-variant border-outline-variant/60 hover:bg-surface-container"}`}
                      >
                        <Folder className="w-3.5 h-3.5" />
                        <span>{displayRoom} ({roomCount})</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Horizontal Category Tabs - contained without overflow bugs */}
              <div className="w-full max-w-full overflow-x-auto no-scrollbar scroll-smooth flex items-center gap-1.5 border-b border-outline-variant/30 pb-2">
                <button 
                  onClick={() => setSelectedCategory("All Categories")}
                  className={`px-3.5 py-1.5 font-bold text-xs whitespace-nowrap rounded-lg transition-all shrink-0 ${
                    selectedCategory === "All Categories" 
                      ? "bg-primary text-on-primary shadow-xs" 
                      : "text-outline hover:text-on-surface hover:bg-surface-container-low"
                  }`}
                >
                  {language === "de" ? "Alle Kategorien" : "All Categories"}
                </button>
                {CATEGORIES.map(cat => (
                  <button 
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className={`px-3.5 py-1.5 font-bold text-xs whitespace-nowrap rounded-lg transition-all shrink-0 ${
                      selectedCategory === cat 
                        ? "bg-primary text-on-primary shadow-xs" 
                        : "text-outline hover:text-on-surface hover:bg-surface-container-low"
                    }`}
                  >
                    {getCategoryTranslation(cat, language)}
                  </button>
                ))}
              </div>

              {/* Owner Filter Chips */}
              {availableOwners.length > 0 && (
                <div className="w-full max-w-full overflow-x-auto no-scrollbar scroll-smooth flex items-center gap-1.5 pb-1">
                  <span className="text-[10px] font-bold text-outline uppercase tracking-wider shrink-0 mr-1 flex items-center gap-1">
                    <User className="w-3 h-3 text-primary" />
                    {t("owner")}:
                  </span>
                  <button
                    onClick={() => setSelectedOwnerFilter("All")}
                    className={`px-3 py-1 rounded-full text-xs font-bold whitespace-nowrap transition-all shrink-0 cursor-pointer ${
                      selectedOwnerFilter === "All"
                        ? "bg-secondary text-on-secondary shadow-2xs"
                        : "bg-surface text-on-surface-variant hover:bg-surface-container border border-outline-variant/50"
                    }`}
                  >
                    {t("allOwners")}
                  </button>
                  {availableOwners.map(ownerName => (
                    <button
                      key={ownerName}
                      onClick={() => setSelectedOwnerFilter(ownerName)}
                      className={`px-3 py-1 rounded-full text-xs font-bold whitespace-nowrap transition-all shrink-0 cursor-pointer ${
                        selectedOwnerFilter === ownerName
                          ? "bg-secondary text-on-secondary shadow-2xs"
                          : "bg-surface text-on-surface-variant hover:bg-surface-container border border-outline-variant/50"
                      }`}
                    >
                      {ownerName}
                    </button>
                  ))}
                </div>
              )}

              {/* Filter feedback label */}
              {(selectedRoom !== "All Items" || selectedCategory !== "All Categories" || selectedOwnerFilter !== "All" || searchQuery || selectedWarrantyFilter !== "All") && (
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 p-3 bg-surface-container rounded-xl text-xs">
                  <span className="text-on-surface-variant font-medium leading-relaxed">
                    {language === "de" ? "Zeige " : "Showing "}{filteredItems.length} {language === "de" ? "Artikel gefiltert nach " : "items filtering by "}
                    {selectedRoom !== "All Items" && <strong>{language === "de" ? "Raum: " : "Room: "}{selectedRoom === "Kitchen" ? (language === "de" ? "Küche" : "Kitchen") : selectedRoom} </strong>}
                    {selectedCategory !== "All Categories" && <strong>{language === "de" ? "Kategorie: " : "Category: "}{getCategoryTranslation(selectedCategory, language)} </strong>}
                    {selectedOwnerFilter !== "All" && <strong>{language === "de" ? "Besitzer: " : "Owner: "}{selectedOwnerFilter} </strong>}
                    {selectedWarrantyFilter !== "All" && <strong>{language === "de" ? "Garantie: " : "Warranty: "}{selectedWarrantyFilter === "Active" ? (language === "de" ? "Aktiv" : "Active") : selectedWarrantyFilter === "Expiring" ? (language === "de" ? "Bald ablaufend" : "Expiring Soon") : (language === "de" ? "Abgelaufen" : "Expired")} </strong>}
                    {searchQuery && <strong>{language === "de" ? "Stichwort: " : "Keyword: "}"{searchQuery}"</strong>}
                  </span>
                  <button 
                    onClick={() => { setSelectedRoom("All Items"); setSelectedCategory("All Categories"); setSelectedOwnerFilter("All"); setSearchQuery(""); setSelectedWarrantyFilter("All"); }}
                    className="text-primary font-bold text-xs hover:underline border-none bg-transparent cursor-pointer self-start sm:self-auto shrink-0"
                  >
                    {t("resetFilters")}
                  </button>
                </div>
              )}

              {/* Items Display: Grid View or Compact List View */}
              {inventoryViewMode === "grid" ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
                  {filteredItems.map((item, index) => {
                    const statusObj = getWarrantyBadgeColor(item.warrantyExpiry);
                    return (
                      <motion.div 
                        key={item.id}
                        initial={{ opacity: 0, y: 12 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.25, delay: Math.min(0.12, index * 0.025), ease: "easeOut" }}
                        onClick={() => { setSelectedItemId(item.id); setActiveView("item-detail"); }}
                        className="group bg-surface border border-outline-variant/70 rounded-xl shadow-xs overflow-hidden hover:scale-[1.01] hover:shadow-md cursor-pointer transition-all duration-300 flex flex-col justify-between"
                      >
                        <div>
                          <div className="h-44 sm:h-48 w-full relative bg-surface-container-low overflow-hidden">
                            {item.photoUrl ? (
                              <img 
                                src={item.photoUrl} 
                                alt={item.name} 
                                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 animate-fade-in"
                              />
                            ) : (
                              <div className="w-full h-full flex flex-col items-center justify-center text-outline">
                                <ImageIcon className="w-10 h-10 opacity-40 mb-1" />
                                <span className="text-[10px] uppercase tracking-wider font-semibold">{t("noPhoto")}</span>
                              </div>
                            )}
                            <div className={`absolute top-3 right-3 px-2.5 py-1 text-[10px] font-bold rounded-full backdrop-blur-xs ${statusObj.bg}`}>
                              {statusObj.label}
                            </div>
                            {/* Audio TTS button right on the card */}
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                speakItemGerman(item);
                              }}
                              className="absolute bottom-2.5 right-2.5 p-1.5 bg-surface/85 backdrop-blur-xs rounded-full text-primary hover:text-primary-container active:scale-90 transition-all border border-outline-variant/20 shadow-xs"
                              title={t("speechDesc")}
                            >
                              <Volume2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                          <div className="p-4 sm:p-5">
                            <div className="flex items-center justify-between gap-1 mb-1">
                              <p className="text-[10px] text-outline uppercase tracking-wider font-semibold truncate">
                                {item.location === "Kitchen" ? (language === "de" ? "Küche" : "Kitchen") 
                                 : item.location === "Living Room" ? (language === "de" ? "Wohnzimmer" : "Living Room")
                                 : item.location === "Bedroom" ? (language === "de" ? "Schlafzimmer" : "Bedroom")
                                 : item.location === "Garage" ? (language === "de" ? "Garage" : "Garage")
                                 : item.location} &bull; {getCategoryTranslation(item.category, language)}
                              </p>
                              {item.owner && (
                                <span className="inline-flex items-center gap-1 text-[10px] font-bold text-primary bg-primary/10 px-2 py-0.5 rounded-full shrink-0">
                                  <User className="w-2.5 h-2.5" />
                                  {item.owner}
                                </span>
                              )}
                            </div>
                            <h3 className="font-bold text-base text-on-surface group-hover:text-primary transition-colors tracking-tight line-clamp-1">
                              {item.name}
                            </h3>
                            <div className="flex items-center gap-1.5 mt-2.5 text-outline text-xs">
                              <Calendar className="w-3.5 h-3.5 shrink-0" />
                              <span className="truncate">{language === "de" ? "Gekauft: " : "Purchased: "}{item.purchaseDate ? new Date(item.purchaseDate).toLocaleDateString(language === "de" ? "de-DE" : "en-US", { month: "short", day: "2-digit", year: "numeric" }) : "N/A"}</span>
                            </div>
                          </div>
                        </div>

                        <div className="p-4 sm:p-5 pt-0">
                          <div className="flex items-center justify-between pt-3 border-t border-outline-variant/30">
                            <div>
                              <span className="text-xs font-extrabold text-on-surface block">{formatCurrency(item.purchasePrice)}</span>
                              <p className="text-[10px] font-semibold text-outline mt-0.5">
                                {item.warrantyExpiry ? `${language === "de" ? "Garantie bis: " : "Warranty: "}${new Date(item.warrantyExpiry).toLocaleDateString(language === "de" ? "de-DE" : "en-US", { month: "short", year: "numeric" })}` : t("noWarranty")}
                              </p>
                            </div>
                            <ChevronRight className="w-4 h-4 text-outline group-hover:translate-x-1 transition-transform shrink-0" />
                          </div>
                        </div>
                      </motion.div>
                    );
                  })}

                  {/* Empty State Add Card */}
                  <div 
                    onClick={() => { resetForm(); setActiveView("add-item"); }}
                    className="flex flex-col items-center justify-center p-6 sm:p-8 bg-surface-container-low/40 border-2 border-dashed border-outline-variant rounded-xl group hover:bg-surface-container-low transition-colors cursor-pointer min-h-[260px] sm:min-h-[320px]"
                  >
                    <div className="w-12 h-12 rounded-full bg-surface-container text-outline group-hover:text-primary group-hover:bg-primary/10 flex items-center justify-center transition-all mb-3">
                      <Plus className="w-6 h-6" />
                    </div>
                    <h3 className="font-bold text-sm sm:text-base text-on-surface">{t("addItem")}</h3>
                    <p className="text-xs text-outline text-center mt-1.5 px-4 leading-relaxed">
                      {language === "de" ? "Erfasse einen Neukauf, um dessen Wert und Garantie zu schützen." : "Track a new purchase to protect its value and warranty."}
                    </p>
                  </div>
                </div>
              ) : (
                /* Compact List View - highly optimized for fast scanning on mobile */
                <div className="space-y-2.5">
                  {filteredItems.map((item, index) => {
                    const statusObj = getWarrantyBadgeColor(item.warrantyExpiry);
                    return (
                      <motion.div 
                        key={item.id}
                        initial={{ opacity: 0, y: 8 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.2, delay: Math.min(0.1, index * 0.02) }}
                        onClick={() => { setSelectedItemId(item.id); setActiveView("item-detail"); }}
                        className="group bg-surface border border-outline-variant/60 hover:border-primary/50 rounded-xl p-3 sm:p-4 shadow-2xs hover:shadow-xs cursor-pointer transition-all flex items-center justify-between gap-3"
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-lg bg-surface-container-low overflow-hidden shrink-0 relative border border-outline-variant/30">
                            {item.photoUrl ? (
                              <img src={item.photoUrl} alt={item.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                            ) : (
                              <div className="w-full h-full flex items-center justify-center text-outline">
                                <ImageIcon className="w-5 h-5 opacity-40" />
                              </div>
                            )}
                          </div>
                          <div className="min-w-0">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <span className="text-[10px] font-bold text-outline uppercase tracking-wider">
                                {item.location === "Kitchen" ? (language === "de" ? "Küche" : "Kitchen") 
                                 : item.location === "Living Room" ? (language === "de" ? "Wohnzimmer" : "Living Room")
                                 : item.location === "Bedroom" ? (language === "de" ? "Schlafzimmer" : "Bedroom")
                                 : item.location === "Garage" ? (language === "de" ? "Garage" : "Garage")
                                 : item.location} &bull; {getCategoryTranslation(item.category, language)}
                              </span>
                              {item.owner && (
                                <span className="inline-flex items-center gap-0.5 text-[9px] font-bold text-primary bg-primary/10 px-1.5 py-0.2 rounded-full">
                                  <User className="w-2 h-2" />
                                  {item.owner}
                                </span>
                              )}
                              <span className={`px-2 py-0.2 text-[9px] font-bold rounded-full ${statusObj.bg}`}>
                                {statusObj.label}
                              </span>
                            </div>
                            <h3 className="font-bold text-sm sm:text-base text-on-surface group-hover:text-primary transition-colors truncate mt-0.5">
                              {item.name}
                            </h3>
                            <p className="text-xs text-outline font-medium mt-0.5 truncate">
                              {item.warrantyExpiry ? `${language === "de" ? "Garantie bis " : "Warranty "}${new Date(item.warrantyExpiry).toLocaleDateString(language === "de" ? "de-DE" : "en-US", { month: "short", year: "numeric" })}` : t("noWarranty")}
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 sm:gap-4 shrink-0">
                          <span className="text-xs sm:text-sm font-black text-on-surface">
                            {formatCurrency(item.purchasePrice)}
                          </span>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              speakItemGerman(item);
                            }}
                            className="p-1.5 rounded-full text-primary hover:bg-surface-container active:scale-90 transition-all cursor-pointer border-none bg-transparent"
                            title={t("speechDesc")}
                          >
                            <Volume2 className="w-4 h-4" />
                          </button>
                          <ChevronRight className="w-4 h-4 text-outline group-hover:translate-x-1 transition-transform" />
                        </div>
                      </motion.div>
                    );
                  })}

                  {/* Empty state in list view */}
                  {filteredItems.length === 0 ? (
                    <div 
                      onClick={() => { resetForm(); setActiveView("add-item"); }}
                      className="p-8 text-center bg-surface-container-low/40 border-2 border-dashed border-outline-variant rounded-xl cursor-pointer hover:bg-surface-container-low transition-colors"
                    >
                      <Plus className="w-6 h-6 text-primary mx-auto mb-2" />
                      <p className="font-bold text-sm text-on-surface">{t("addItem")}</p>
                      <p className="text-xs text-outline mt-1">{language === "de" ? "Erfasse deinen ersten Gegenstand in dieser Ansicht." : "Track your first item in this view."}</p>
                    </div>
                  ) : (
                    /* Add Item Row in list view */
                    <div 
                      onClick={() => { resetForm(); setActiveView("add-item"); }}
                      className="p-3.5 bg-surface-container-low/50 border border-dashed border-outline-variant rounded-xl flex items-center justify-center gap-2 cursor-pointer hover:bg-surface-container transition-colors text-primary font-bold text-xs"
                    >
                      <Plus className="w-4 h-4" />
                      <span>{t("addItem")}</span>
                    </div>
                  )}
                </div>
              )}
            </motion.div>
          )}

          {/* SCREEN 3: Add / Edit Item Form */}
          {activeView === "add-item" && (
            <motion.div 
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.25, ease: "easeOut" }}
              className="max-w-[1200px] mx-auto space-y-8"
            >
              <header className="flex items-center justify-between">
                <div>
                  <h1 className="text-3xl font-bold tracking-tight text-on-surface">
                    {editingItemId ? (language === "de" ? "Gegenstand bearbeiten" : "Edit Item") : (language === "de" ? "Gegenstand hinzufügen" : "Add Item")}
                  </h1>
                  <p className="text-sm text-outline mt-1">{language === "de" ? "Erfassen Sie einen neuen physischen Gegenstand in Ihrem digitalen Inventar." : "Record a new asset to your digital inventory."}</p>
                </div>
              </header>

              <div className="grid grid-cols-1 xl:grid-cols-3 gap-6 items-start">
                
                {/* Left Column Form Fields */}
                <div className="xl:col-span-2 bg-surface border border-outline-variant rounded-xl p-6 shadow-xs">
                  <form onSubmit={handleSaveItem} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      
                      {/* Name */}
                      <div className="flex flex-col gap-1">
                        <label className="text-xs font-bold text-on-surface-variant">{language === "de" ? "Name des Gegenstands" : "Item Name"}</label>
                        <input 
                          type="text"
                          required
                          placeholder={language === "de" ? "z.B. Samsung Bespoke Kühlschrank" : "e.g., Samsung Bespoke Refrigerator"}
                          value={formName}
                          onChange={(e) => setFormName(e.target.value)}
                          className="bg-surface-container-low border border-transparent rounded-lg p-3 text-sm focus:ring-2 focus:ring-primary focus:bg-white outline-hidden transition-all text-on-surface"
                        />
                      </div>

                      {/* Category */}
                      <div className="flex flex-col gap-1">
                        <label className="text-xs font-bold text-on-surface-variant">{language === "de" ? "Kategorie" : "Category"}</label>
                        <select 
                          value={formCategory}
                          onChange={(e) => setFormCategory(e.target.value)}
                          className="bg-surface-container-low border border-transparent rounded-lg p-3 text-sm focus:ring-2 focus:ring-primary focus:bg-white outline-hidden transition-all text-on-surface cursor-pointer"
                        >
                          <option value="Appliances">{language === "de" ? "Haushaltsgeräte" : "Appliances"}</option>
                          <option value="Electronics">{language === "de" ? "Elektronik" : "Electronics"}</option>
                          <option value="Furniture">{language === "de" ? "Möbel" : "Furniture"}</option>
                          <option value="Tools">{language === "de" ? "Werkzeuge" : "Tools"}</option>
                          <option value="Others">{language === "de" ? "Sonstiges" : "Others"}</option>
                        </select>
                      </div>

                      {/* Purchase Price */}
                      <div className="flex flex-col gap-1">
                        <label className="text-xs font-bold text-on-surface-variant">{language === "de" ? "Kaufpreis (€)" : "Purchase Price ($)"}</label>
                        <div className="relative">
                          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-outline font-bold text-sm">{currencySymbol}</span>
                          <input 
                            type="number"
                            step="0.01"
                            placeholder="0.00"
                            value={formPrice}
                            onChange={(e) => setFormPrice(e.target.value)}
                            className="w-full bg-surface-container-low border border-transparent rounded-lg p-3 pl-8 text-sm focus:ring-2 focus:ring-primary focus:bg-white outline-hidden transition-all text-on-surface"
                          />
                        </div>
                      </div>

                      {/* Purchase Date */}
                      <div className="flex flex-col gap-1">
                        <label className="text-xs font-bold text-on-surface-variant">{language === "de" ? "Kaufdatum" : "Purchase Date"}</label>
                        <input 
                          type="date"
                          value={formDate}
                          onChange={(e) => setFormDate(e.target.value)}
                          className="bg-surface-container-low border border-transparent rounded-lg p-3 text-sm focus:ring-2 focus:ring-primary focus:bg-white outline-hidden transition-all text-on-surface"
                        />
                      </div>

                      {/* Warranty Duration */}
                      <div className="flex flex-col gap-1">
                        <label className="text-xs font-bold text-on-surface-variant">{language === "de" ? "Garantiedauer (Monate)" : "Warranty Duration (months)"}</label>
                        <input 
                          type="number"
                          placeholder="24"
                          value={formWarrantyMonths}
                          onChange={(e) => setFormWarrantyMonths(e.target.value)}
                          className="bg-surface-container-low border border-transparent rounded-lg p-3 text-sm focus:ring-2 focus:ring-primary focus:bg-white outline-hidden transition-all text-on-surface"
                        />
                      </div>

                      {/* Room Location */}
                      <div className="flex flex-col gap-1">
                        <label className="text-xs font-bold text-on-surface-variant">{language === "de" ? "Raum / Ort" : "Room Location"}</label>
                        <select 
                          value={formRoom}
                          onChange={(e) => setFormRoom(e.target.value)}
                          className="bg-surface-container-low border border-transparent rounded-lg p-3 text-sm focus:ring-2 focus:ring-primary focus:bg-white outline-hidden transition-all text-on-surface cursor-pointer"
                        >
                          {rooms.map(room => {
                            const translated = room === "Kitchen" ? (language === "de" ? "Küche" : "Kitchen") 
                                             : room === "Living Room" ? (language === "de" ? "Wohnzimmer" : "Living Room")
                                             : room === "Bedroom" ? (language === "de" ? "Schlafzimmer" : "Bedroom")
                                             : room === "Garage" ? (language === "de" ? "Garage" : "Garage")
                                             : room;
                            return (
                              <option key={room} value={room}>{translated}</option>
                            );
                          })}
                        </select>
                      </div>

                      {/* Household Assignment */}
                      <div className="flex flex-col gap-1">
                        <label className="text-xs font-bold text-on-surface-variant flex items-center gap-1">
                          <Home className="w-3.5 h-3.5 text-primary" />
                          <span>{t("household")}</span>
                        </label>
                        <select 
                          value={formHouseholdId}
                          onChange={(e) => {
                            setFormHouseholdId(e.target.value);
                            const hh = households.find(h => h.id === e.target.value);
                            if (hh && hh.members.length > 0) {
                              setFormOwner(hh.members[0].name);
                            }
                          }}
                          className="bg-surface-container-low border border-transparent rounded-lg p-3 text-sm focus:ring-2 focus:ring-primary focus:bg-white outline-hidden transition-all text-on-surface cursor-pointer"
                        >
                          {households.map(hh => (
                            <option key={hh.id} value={hh.id}>{hh.name}</option>
                          ))}
                        </select>
                      </div>

                      {/* Owner Assignment */}
                      <div className="flex flex-col gap-1">
                        <label className="text-xs font-bold text-on-surface-variant flex items-center gap-1">
                          <User className="w-3.5 h-3.5 text-primary" />
                          <span>{t("owner")}</span>
                        </label>
                        <div className="flex gap-2">
                          <select 
                            value={formOwner}
                            onChange={(e) => setFormOwner(e.target.value)}
                            className="w-full bg-surface-container-low border border-transparent rounded-lg p-3 text-sm focus:ring-2 focus:ring-primary focus:bg-white outline-hidden transition-all text-on-surface cursor-pointer"
                          >
                            {(households.find(h => h.id === formHouseholdId)?.members || currentHousehold?.members || []).map(m => (
                              <option key={m.id} value={m.name}>{m.name} ({m.role === "admin" ? (language === "de" ? "Admin" : "Admin") : m.role === "editor" ? (language === "de" ? "Bearbeiter" : "Editor") : (language === "de" ? "Leser" : "Viewer")})</option>
                            ))}
                          </select>
                        </div>
                      </div>

                      {/* Warranty Where Applies */}
                      <div className="flex flex-col gap-1 md:col-span-2">
                        <label className="text-xs font-bold text-on-surface-variant flex items-center gap-1">
                          <ShieldCheck className="w-3.5 h-3.5 text-primary" />
                          <span>{t("warrantyWhereApplies")}</span>
                        </label>
                        <input 
                          type="text"
                          placeholder={t("whereAppliesPlaceholder")}
                          value={formWarrantyWhereApplies}
                          onChange={(e) => setFormWarrantyWhereApplies(e.target.value)}
                          className="bg-surface-container-low border border-transparent rounded-lg p-3 text-sm focus:ring-2 focus:ring-primary focus:bg-white outline-hidden transition-all text-on-surface"
                        />
                      </div>

                      {/* Next Maintenance Date */}
                      <div className="flex flex-col gap-1">
                        <label className="text-xs font-bold text-on-surface-variant">
                          {language === "de" ? "Nächster Wartungstermin" : "Next Maintenance Date"}
                        </label>
                        <input 
                          type="date"
                          value={formNextMaintenanceDate}
                          onChange={(e) => {
                            setFormNextMaintenanceDate(e.target.value);
                            setIsMaintenanceManuallyEdited(true);
                          }}
                          className="bg-surface-container-low border border-transparent rounded-lg p-3 text-sm focus:ring-2 focus:ring-primary focus:bg-white outline-hidden transition-all text-on-surface"
                        />
                        <p className="text-[10px] text-outline mt-1">
                          {language === "de" 
                            ? "Empfohlen basierend auf dem Gerätetyp." 
                            : "Recommended automatically based on the item type."}
                        </p>
                      </div>

                      {/* Serial Number */}
                      <div className="flex flex-col gap-1">
                        <label className="text-xs font-bold text-on-surface-variant">{language === "de" ? "Seriennummer" : "Serial Number"}</label>
                        <input 
                          type="text"
                          placeholder="e.g. RF29A9675AP/AA"
                          value={formSerial}
                          onChange={(e) => setFormSerial(e.target.value)}
                          className="bg-surface-container-low border border-transparent rounded-lg p-3 text-sm focus:ring-2 focus:ring-primary focus:bg-white outline-hidden transition-all text-on-surface"
                        />
                      </div>

                      {/* Color */}
                      <div className="flex flex-col gap-1">
                        <label className="text-xs font-bold text-on-surface-variant">{language === "de" ? "Farbe / Äußeres Finish" : "Color / Exterior Finish"}</label>
                        <input 
                          type="text"
                          placeholder="e.g. Charcoal Glass"
                          value={formColor}
                          onChange={(e) => setFormColor(e.target.value)}
                          className="bg-surface-container-low border border-transparent rounded-lg p-3 text-sm focus:ring-2 focus:ring-primary focus:bg-white outline-hidden transition-all text-on-surface"
                        />
                      </div>

                      {/* Capacity / Weight */}
                      <div className="flex flex-col gap-1">
                        <label className="text-xs font-bold text-on-surface-variant">{language === "de" ? "Kapazität / Spezifikationen" : "Capacity / Spec Details"}</label>
                        <input 
                          type="text"
                          placeholder="e.g. 29 cu. ft."
                          value={formCapacity}
                          onChange={(e) => setFormCapacity(e.target.value)}
                          className="bg-surface-container-low border border-transparent rounded-lg p-3 text-sm focus:ring-2 focus:ring-primary focus:bg-white outline-hidden transition-all text-on-surface"
                        />
                      </div>

                      {/* Purchase History Store */}
                      <div className="flex flex-col gap-1">
                        <label className="text-xs font-bold text-on-surface-variant">{language === "de" ? "Gekauft bei Händler" : "Purchased From Store"}</label>
                        <input 
                          type="text"
                          placeholder="e.g. Best Buy #442"
                          value={formStore}
                          onChange={(e) => setFormStore(e.target.value)}
                          className="bg-surface-container-low border border-transparent rounded-lg p-3 text-sm focus:ring-2 focus:ring-primary focus:bg-white outline-hidden transition-all text-on-surface"
                        />
                      </div>

                      {/* Payment Method */}
                      <div className="flex flex-col gap-1">
                        <label className="text-xs font-bold text-on-surface-variant">{language === "de" ? "Zahlungsart" : "Payment Method"}</label>
                        <input 
                          type="text"
                          placeholder="e.g. Visa ending in 4492"
                          value={formPayment}
                          onChange={(e) => setFormPayment(e.target.value)}
                          className="bg-surface-container-low border border-transparent rounded-lg p-3 text-sm focus:ring-2 focus:ring-primary focus:bg-white outline-hidden transition-all text-on-surface"
                        />
                      </div>

                    </div>

                    {/* Notes */}
                    <div className="flex flex-col gap-1">
                      <label className="text-xs font-bold text-on-surface-variant">{language === "de" ? "Notizen & Details" : "Notes & Details"}</label>
                      <textarea 
                        rows={3}
                        placeholder={language === "de" ? "Beschreiben Sie den Zustand des Produkts, Zubehör, Modelljahre..." : "Describe the product state, accessories, model years..."}
                        value={formNotes}
                        onChange={(e) => setFormNotes(e.target.value)}
                        className="bg-surface-container-low border border-transparent rounded-lg p-3 text-sm focus:ring-2 focus:ring-primary focus:bg-white outline-hidden transition-all text-on-surface resize-none"
                      />
                    </div>

                    <div className="pt-4 flex gap-3 justify-end border-t border-outline-variant/30">
                      <button 
                        type="button"
                        onClick={() => { resetForm(); setActiveView("inventory"); }}
                        className="px-6 py-2.5 border border-outline-variant text-on-surface font-semibold text-xs rounded-lg hover:bg-surface-container-low transition-colors active:scale-95 cursor-pointer bg-transparent"
                      >
                        {language === "de" ? "Abbrechen" : "Cancel"}
                      </button>
                      <button 
                        type="submit"
                        className="px-6 py-2.5 bg-primary text-on-primary font-bold text-xs rounded-lg hover:shadow-md transition-all active:scale-95 cursor-pointer border-none"
                      >
                        {language === "de" ? "Gegenstand speichern" : "Save Item Asset"}
                      </button>
                    </div>
                  </form>
                </div>

                {/* Right Column: Upload Files Drawer */}
                <div className="space-y-6">
                  
                  {/* Photo upload Box */}
                  <div className="bg-surface border border-outline-variant rounded-xl p-6 shadow-xs">
                    <h2 className="text-base font-bold text-on-surface mb-3">{language === "de" ? "Produktbild hochladen" : "Upload Product Image"}</h2>
                    <div 
                      onClick={() => fileInputRef.current?.click()}
                      className="relative group cursor-pointer border-2 border-dashed border-outline-variant rounded-xl p-6 flex flex-col items-center justify-center gap-3 hover:border-primary hover:bg-primary/5 transition-all"
                    >
                      <input 
                        type="file" 
                        ref={fileInputRef}
                        accept="image/*"
                        onChange={(e) => handleFileUpload(e, false)}
                        className="hidden" 
                      />
                      <div className="w-12 h-12 rounded-full bg-surface-container-high flex items-center justify-center text-primary group-hover:scale-105 transition-transform">
                        <UploadCloud className="w-6 h-6" />
                      </div>
                      <div className="text-center">
                        <p className="text-xs font-bold text-on-surface">{language === "de" ? "Drag & Drop oder " : "Drag & drop or "}<span className="text-primary underline">{language === "de" ? "durchsuchen" : "browse"}</span></p>
                        <p className="text-[10px] text-outline mt-1">{language === "de" ? "Unterstützt JPG, PNG bis zu 4MB" : "Supports JPG, PNG up to 4MB"}</p>
                      </div>
                    </div>

                    {formPhotoUrl && (
                      <div className="mt-4 p-2.5 bg-surface-container-low rounded-lg border border-outline-variant/50 flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2 truncate">
                          <ImageIcon className="w-4 h-4 text-primary shrink-0" />
                          <span className="text-[10px] text-on-surface truncate font-semibold">{language === "de" ? "Bild erfolgreich geladen" : "Image successfully loaded"}</span>
                        </div>
                        <button 
                          onClick={() => { setFormPhotoUrl(""); setFormPhotoId(""); }} 
                          className="text-error hover:text-on-error-container text-[10px] font-bold bg-transparent border-none cursor-pointer"
                        >
                          {language === "de" ? "Entfernen" : "Remove"}
                        </button>
                      </div>
                    )}
                  </div>

                  {/* Manual Bill/Receipt Upload Box */}
                  <div className="bg-surface border border-outline-variant rounded-xl p-6 shadow-xs">
                    <h2 className="text-base font-bold text-on-surface mb-3">{language === "de" ? "Kaufbeleg / Rechnung hochladen" : "Upload Receipt / Invoice"}</h2>
                    <div 
                      onClick={() => manualInputRef.current?.click()}
                      className="relative group cursor-pointer border-2 border-dashed border-outline-variant rounded-xl p-6 flex flex-col items-center justify-center gap-3 hover:border-primary hover:bg-primary/5 transition-all"
                    >
                      <input 
                        type="file" 
                        ref={manualInputRef}
                        accept="image/*,application/pdf"
                        onChange={(e) => handleFileUpload(e, true)}
                        className="hidden" 
                      />
                      <div className="w-12 h-12 rounded-full bg-surface-container-high flex items-center justify-center text-primary group-hover:scale-105 transition-transform">
                        <UploadCloud className="w-6 h-6" />
                      </div>
                      <div className="text-center">
                        <p className="text-xs font-bold text-on-surface">{language === "de" ? "Drag & Drop oder " : "Drag & drop or "}<span className="text-primary underline">{language === "de" ? "durchsuchen" : "browse"}</span></p>
                        <p className="text-[10px] text-outline mt-1">{language === "de" ? "Unterstützt PDF, JPG bis zu 4MB" : "Supports PDF, JPG up to 4MB"}</p>
                      </div>
                    </div>

                    {formManualUrl && (
                      <div className="mt-4 p-2.5 bg-surface-container-low rounded-lg border border-outline-variant/50 flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2 truncate">
                          <CheckCircle2 className="w-4 h-4 text-secondary shrink-0" />
                          <span className="text-[10px] text-on-surface truncate font-semibold">{language === "de" ? "Dokument angehängt" : "Document attached"}</span>
                        </div>
                        <button 
                          onClick={() => { setFormManualUrl(""); setFormManualId(""); }} 
                          className="text-error hover:text-on-error-container text-[10px] font-bold bg-transparent border-none cursor-pointer"
                        >
                          {language === "de" ? "Entfernen" : "Remove"}
                        </button>
                      </div>
                    )}
                  </div>

                  {/* Guidance Information card */}
                  <div className="bg-emerald-50/55 dark:bg-emerald-950/20 border border-emerald-100 dark:border-emerald-900/30 rounded-xl p-5 flex gap-3">
                    <CheckCircle2 className="w-5 h-5 text-secondary shrink-0 mt-0.5" />
                    <div>
                      <h4 className="text-xs font-bold text-secondary-container-on">{language === "de" ? "Garantieschutz & Nachweis" : "Asset Security & Protection"}</h4>
                      <p className="text-[11px] text-on-secondary-container leading-relaxed mt-1">
                        {language === "de" ? "Das Hochladen hochauflösender Kaufbelege bestätigt die Anschaffungskosten Ihres Eigentums. Dies dient als rechtskräftiger Nachweis im Garantiefall." : "Uploading high-resolution purchase invoice receipts validates your item's financial acquisition cost. This provides concrete evidence for warranty fulfillment."}
                      </p>
                    </div>
                  </div>

                  {/* Form Upload Preview */}
                  {formPhotoUrl && (
                    <div className="bg-surface border border-outline-variant rounded-xl p-4 shadow-xs space-y-2">
                      <p className="text-[10px] text-outline uppercase tracking-wider font-semibold">{language === "de" ? "Bildvorschau" : "Asset Photo Preview"}</p>
                      <div className="aspect-video rounded-lg overflow-hidden border border-outline-variant bg-surface-container">
                        <img src={formPhotoUrl} alt="Upload preview" className="w-full h-full object-cover" />
                      </div>
                    </div>
                  )}

                </div>

              </div>
            </motion.div>
          )}

          {/* SCREEN 4: Item Detail View */}
          {activeView === "item-detail" && selectedItemData && (
            <motion.div 
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.25, ease: "easeOut" }}
              className="max-w-[1200px] mx-auto space-y-8"
            >
              
              {/* Back navigation and actions */}
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <nav className="flex items-center gap-1 text-xs text-outline font-semibold">
                  <button 
                    onClick={() => setActiveView("inventory")}
                    className="hover:text-primary active:scale-95 transition-all bg-transparent border-none cursor-pointer"
                  >
                    {selectedItemData.location === "Kitchen" ? (language === "de" ? "Küche" : "Kitchen") 
                     : selectedItemData.location === "Living Room" ? (language === "de" ? "Wohnzimmer" : "Living Room")
                     : selectedItemData.location === "Bedroom" ? (language === "de" ? "Schlafzimmer" : "Bedroom")
                     : selectedItemData.location === "Garage" ? (language === "de" ? "Garage" : "Garage")
                     : selectedItemData.location}
                  </button>
                  <ChevronRight className="w-4 h-4 text-outline" />
                  <span className="text-on-surface">{language === "de" ? "Details" : "Item Detail"}</span>
                </nav>

                <div className="flex gap-2 w-full sm:w-auto">
                  <button 
                    onClick={() => handleEditClick(selectedItemData)}
                    className="flex-1 sm:flex-none flex items-center justify-center gap-1 px-3 sm:px-5 py-2 border border-outline-variant rounded-lg font-bold text-xs bg-surface text-on-surface hover:bg-surface-container-low transition-all active:scale-95 cursor-pointer whitespace-nowrap"
                  >
                    <Plus className="w-4 h-4" />
                    <span className="hidden sm:inline">{language === "de" ? "Spezifikationen bearbeiten" : "Edit Specifications"}</span>
                    <span className="sm:hidden">{language === "de" ? "Bearbeiten" : "Edit"}</span>
                  </button>
                  <button 
                    onClick={() => handleDeleteItem(selectedItemData)}
                    className="flex-1 sm:flex-none flex items-center justify-center gap-1 px-3 sm:px-5 py-2 border border-error bg-on-error dark:bg-red-950/20 rounded-lg font-bold text-xs text-error hover:bg-error-container hover:text-on-error-container transition-all active:scale-95 cursor-pointer whitespace-nowrap"
                  >
                    <Trash2 className="w-4 h-4" />
                    <span className="hidden sm:inline">{language === "de" ? "Löschen" : "Delete Asset"}</span>
                    <span className="sm:hidden">{language === "de" ? "Löschen" : "Delete"}</span>
                  </button>
                </div>
              </div>

              {/* Bento Grid layout details */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                
                {/* Main Product Info & Specs */}
                <div className="lg:col-span-8 space-y-6">
                  
                  {/* Photo & title details card */}
                  <div className="bg-surface rounded-2xl overflow-hidden shadow-sm border border-outline-variant">
                    <div className="aspect-video relative bg-surface-container">
                      {selectedItemData.photoUrl ? (
                        <img 
                          src={selectedItemData.photoUrl} 
                          alt={selectedItemData.name} 
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full flex flex-col items-center justify-center text-outline">
                          <ImageIcon className="w-16 h-16 opacity-30 mb-2" />
                          <span className="text-xs uppercase tracking-widest font-bold">{language === "de" ? "Kein Produktbild hochgeladen" : "No product image uploaded"}</span>
                        </div>
                      )}
                      
                      <div className="absolute top-4 right-4">
                        <span className={`px-3 py-1 text-[11px] font-bold rounded-full backdrop-blur-xs ${getWarrantyBadgeColor(selectedItemData.warrantyExpiry).bg}`}>
                          {getWarrantyBadgeColor(selectedItemData.warrantyExpiry).label}
                        </span>
                      </div>
                    </div>

                    <div className="p-6">
                      <h1 className="text-2xl font-bold tracking-tight text-on-surface">
                        {selectedItemData.name}
                      </h1>
                      <p className="text-xs text-outline mt-1">
                        {language === "de" ? "Seriennr.:" : "Serial:"} {selectedItemData.serialNumber || "N/A"} &bull; {language === "de" ? "Hinzugefügt:" : "Added:"} {new Date(selectedItemData.createdAt).toLocaleDateString(language === "de" ? "de-DE" : "en-US", { month: "short", day: "2-digit", year: "numeric" })}
                      </p>

                      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 mt-6">
                        <div className="p-3 bg-surface-container-low rounded-lg border border-outline-variant">
                          <p className="text-[10px] text-outline font-bold uppercase tracking-wider mb-1">{language === "de" ? "TYP" : "TYPE"}</p>
                          <p className="font-semibold text-xs text-on-surface truncate">{getCategoryTranslation(selectedItemData.category, language)}</p>
                        </div>
                        <div className="p-3 bg-surface-container-low rounded-lg border border-outline-variant">
                          <p className="text-[10px] text-outline font-bold uppercase tracking-wider mb-1">{language === "de" ? "BESITZER" : "OWNER"}</p>
                          <p className="font-semibold text-xs text-primary truncate flex items-center gap-1">
                            <User className="w-3 h-3 shrink-0" />
                            <span>{selectedItemData.owner || "Ich"}</span>
                          </p>
                        </div>
                        <div className="p-3 bg-surface-container-low rounded-lg border border-outline-variant">
                          <p className="text-[10px] text-outline font-bold uppercase tracking-wider mb-1">{language === "de" ? "HAUSHALT" : "HOUSEHOLD"}</p>
                          <p className="font-semibold text-xs text-on-surface truncate flex items-center gap-1">
                            <Home className="w-3 h-3 shrink-0 text-outline" />
                            <span>{households.find(h => h.id === selectedItemData.householdId)?.name || currentHousehold?.name || "Hauptwohnung"}</span>
                          </p>
                        </div>
                        <div className="p-3 bg-surface-container-low rounded-lg border border-outline-variant">
                          <p className="text-[10px] text-outline font-bold uppercase tracking-wider mb-1">{language === "de" ? "ORT" : "LOCATION"}</p>
                          <p className="font-semibold text-xs text-on-surface truncate">
                            {selectedItemData.location === "Kitchen" ? (language === "de" ? "Küche" : "Kitchen") 
                             : selectedItemData.location === "Living Room" ? (language === "de" ? "Wohnzimmer" : "Living Room")
                             : selectedItemData.location === "Bedroom" ? (language === "de" ? "Schlafzimmer" : "Bedroom")
                             : selectedItemData.location === "Garage" ? (language === "de" ? "Garage" : "Garage")
                             : selectedItemData.location}
                          </p>
                        </div>
                        <div className="p-3 bg-surface-container-low rounded-lg border border-outline-variant">
                          <p className="text-[10px] text-outline font-bold uppercase tracking-wider mb-1">{language === "de" ? "FARBE" : "COLOR"}</p>
                          <p className="font-semibold text-xs text-on-surface truncate">{selectedItemData.color || "N/A"}</p>
                        </div>
                        <div className="p-3 bg-surface-container-low rounded-lg border border-outline-variant">
                          <p className="text-[10px] text-outline font-bold uppercase tracking-wider mb-1">{language === "de" ? "KAPAZITÄT" : "CAPACITY"}</p>
                          <p className="font-semibold text-xs text-on-surface truncate">{selectedItemData.capacity || "N/A"}</p>
                        </div>
                      </div>

                      {selectedItemData.warrantyWhereApplies && (
                        <div className="mt-3 p-3 bg-primary/5 rounded-lg border border-primary/15 flex items-center gap-2 text-xs">
                          <ShieldCheck className="w-4 h-4 text-primary shrink-0" />
                          <span className="text-outline font-medium">{t("warrantyWhereApplies")}:</span>
                          <span className="font-semibold text-on-surface">{selectedItemData.warrantyWhereApplies}</span>
                        </div>
                      )}

                      {selectedItemData.notes && (
                        <div className="mt-6 pt-6 border-t border-outline-variant/30 text-xs text-on-surface-variant leading-relaxed bg-surface-container-low p-4 rounded-lg">
                          <p className="font-bold text-on-surface mb-1">{language === "de" ? "Beschreibung & Notizen:" : "Description & Manual Notes:"}</p>
                          <p className="whitespace-pre-wrap">{selectedItemData.notes}</p>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Warranty Information countdown and specifications */}
                  <div className="bg-surface rounded-2xl p-6 shadow-sm border border-outline-variant">
                    <div className="flex justify-between items-center mb-6">
                      <h2 className="text-lg font-bold text-on-surface flex items-center gap-2">
                        <ShieldAlert className="w-5 h-5 text-primary" />
                        <span>{language === "de" ? "Garantie-Informationen" : "Warranty Information"}</span>
                      </h2>
                      <span className={`px-3 py-1 text-xs font-bold rounded-full ${getWarrantyBadgeColor(selectedItemData.warrantyExpiry).bg}`}>
                        {getWarrantyBadgeColor(selectedItemData.warrantyExpiry).label}
                      </span>
                    </div>

                    <div className="flex flex-col md:flex-row gap-8 items-center">
                      
                      {/* Interactive Countdown Timer */}
                      <div className="relative w-40 h-40 flex items-center justify-center shrink-0">
                        <svg className="w-full h-full -rotate-90">
                          <circle className="text-surface-container-high" cx="80" cy="80" fill="transparent" r="70" stroke="currentColor" strokeWidth="8" />
                          <circle 
                            className="text-primary transition-all duration-1000" 
                            cx="80" 
                            cy="80" 
                            fill="transparent" 
                            r="70" 
                            stroke="currentColor" 
                            strokeDasharray="440" 
                            strokeDashoffset={440 - (440 * getWarrantyPercentage(selectedItemData)) / 100} 
                            strokeWidth="8" 
                          />
                        </svg>
                        <div className="absolute inset-0 flex flex-col items-center justify-center">
                          {selectedItemData.warrantyExpiry ? (
                            <>
                              <p className="text-3xl font-extrabold text-primary tracking-tight">
                                {Math.max(0, Math.ceil((new Date(selectedItemData.warrantyExpiry).getTime() - Date.now()) / (24 * 60 * 60 * 1000)))}
                              </p>
                              <p className="text-[10px] text-outline font-bold tracking-wider mt-0.5">{language === "de" ? "TAGE ÜBRIG" : "DAYS LEFT"}</p>
                            </>
                          ) : (
                            <p className="text-sm font-semibold text-outline">{language === "de" ? "Kein Ablauf" : "No Expiry"}</p>
                          )}
                        </div>
                      </div>

                      {/* Detail metrics list */}
                      <div className="flex-1 space-y-3 w-full text-xs">
                        <div className="flex justify-between border-b border-surface-container-high pb-2">
                          <span className="text-outline font-semibold">{language === "de" ? "Garantiegeber" : "Warranty Provider"}</span>
                          <span className="font-bold text-on-surface">{selectedItemData.warrantyProvider || "N/A"}</span>
                        </div>
                        <div className="flex justify-between border-b border-surface-container-high pb-2">
                          <span className="text-outline font-semibold">{language === "de" ? "Vertragsnummer" : "Policy Plan Number"}</span>
                          <span className="font-bold text-on-surface">{selectedItemData.policyNumber || "N/A"}</span>
                        </div>
                        <div className="flex justify-between border-b border-surface-container-high pb-2">
                          <span className="text-outline font-semibold">{language === "de" ? "Aktivierungsdatum" : "Plan Activation Date"}</span>
                          <span className="font-bold text-on-surface">
                            {selectedItemData.purchaseDate ? new Date(selectedItemData.purchaseDate).toLocaleDateString(language === "de" ? "de-DE" : "en-US", { month: "short", day: "2-digit", year: "numeric" }) : "N/A"}
                          </span>
                        </div>
                        <div className="flex justify-between border-b border-surface-container-high pb-2">
                          <span className="text-outline font-semibold">{language === "de" ? "Ablaufdatum" : "Expirations Date"}</span>
                          <span className="font-bold text-on-surface">
                            {selectedItemData.warrantyExpiry ? new Date(selectedItemData.warrantyExpiry).toLocaleDateString(language === "de" ? "de-DE" : "en-US", { month: "short", day: "2-digit", year: "numeric" }) : "N/A"}
                          </span>
                        </div>
                      </div>

                    </div>
                  </div>

                </div>

                {/* Sidebar details (Purchase logs, Receipts, Maintenance logs) */}
                <div className="lg:col-span-4 space-y-6">
                  
                  {/* Purchase History */}
                  <div className="bg-surface rounded-2xl p-6 shadow-sm border border-outline-variant">
                    <h2 className="text-base font-bold text-on-surface mb-4">{language === "de" ? "Anschaffungsdaten" : "Acquisition Metrics"}</h2>
                    <div className="space-y-4 text-xs">
                      <div className="flex items-start gap-3">
                        <div className="bg-surface-container-low p-2 rounded-lg text-primary shrink-0">
                          <Store className="w-4 h-4" />
                        </div>
                        <div>
                          <p className="font-bold text-on-surface">{selectedItemData.purchaseHistoryStore}</p>
                          <p className="text-outline mt-0.5">{language === "de" ? "Händler" : "Purchased Merchant"}</p>
                        </div>
                      </div>

                      <div className="flex items-start gap-3">
                        <div className="bg-surface-container-low p-2 rounded-lg text-primary shrink-0">
                          <CreditCard className="w-4 h-4" />
                        </div>
                        <div>
                          <p className="font-bold text-on-surface">{formatCurrency(selectedItemData.purchasePrice)}</p>
                          <p className="text-outline mt-0.5">{selectedItemData.paymentMethod}</p>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Receipt scan card */}
                  <div className="bg-surface rounded-2xl p-6 shadow-sm border border-outline-variant">
                    <div className="flex justify-between items-center mb-4">
                      <h2 className="text-base font-bold text-on-surface">{language === "de" ? "Kaufbeleg & Rechnung" : "Receipt & Bill"}</h2>
                      {selectedItemData.manualUrl && (
                        <a 
                          href={selectedItemData.manualUrl} 
                          download={`${selectedItemData.name}_receipt.png`}
                          className="text-primary hover:bg-primary-container p-1 rounded transition-colors bg-transparent border-none"
                          title="Download Invoice"
                        >
                          <Download className="w-4 h-4" />
                        </a>
                      )}
                    </div>

                    <div className="relative group overflow-hidden rounded-lg border border-outline-variant aspect-[3/4] bg-surface-container-low flex flex-col items-center justify-center">
                      {selectedItemData.manualUrl ? (
                        <>
                          <img 
                            src={selectedItemData.manualUrl} 
                            alt="Receipt Scan" 
                            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                          />
                          <div className="absolute inset-0 bg-on-surface/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                            <button 
                              onClick={() => setShowReceiptZoom(selectedItemData.manualUrl || null)}
                              className="bg-white text-on-surface px-4 py-2 rounded-full font-bold text-xs flex items-center gap-1 cursor-pointer active:scale-95 border-none"
                            >
                              <ZoomIn className="w-3.5 h-3.5" />
                              <span>{language === "de" ? "Beleg anzeigen" : "View Full Receipt"}</span>
                            </button>
                          </div>
                        </>
                      ) : (
                        <div className="text-center p-6 text-outline">
                          <UploadCloud className="w-12 h-12 opacity-35 mx-auto mb-2" />
                          <p className="text-[10px] uppercase font-bold tracking-wider">{language === "de" ? "Kein Kaufbeleg hochgeladen" : "No invoice document"}</p>
                        </div>
                      )}
                    </div>
                    {selectedItemData.manualUrl && (
                      <p className="mt-3 text-[10px] text-outline text-center italic">{language === "de" ? "Verifiziertes Dokument" : "Document Verified Scan"}</p>
                    )}
                  </div>

                  {/* Maintenance log section */}
                  <div className="bg-surface rounded-2xl p-6 shadow-sm border border-outline-variant">
                    <h2 className="text-base font-bold text-on-surface mb-4">{language === "de" ? "Wartungsprotokoll" : "Maintenance Log"}</h2>
                    
                    <div className="space-y-3.5 max-h-56 overflow-y-auto custom-scrollbar pr-1">
                      {(!selectedItemData.maintenanceLog || selectedItemData.maintenanceLog.length === 0) ? (
                        <p className="text-xs text-outline italic text-center py-4">{language === "de" ? "Keine Wartungseinträge protokolliert." : "No logged maintenance entries."}</p>
                      ) : (
                        selectedItemData.maintenanceLog.map((log) => (
                          <div key={log.id} className="flex items-center justify-between text-xs bg-surface-container-low p-2.5 rounded-lg border border-outline-variant/30">
                            <div className="flex items-center gap-2">
                              <span className={`w-2 h-2 rounded-full ${log.status === 'Completed' ? 'bg-secondary' : 'bg-outline'}`} />
                              <span className="font-bold text-on-surface truncate max-w-[120px]">{log.title}</span>
                            </div>
                            <span className="text-[10px] text-outline uppercase font-semibold">{log.date}</span>
                          </div>
                        ))
                      )}

                      <button 
                        onClick={() => handleAddMaintenanceLog(selectedItemData)}
                        className="w-full mt-4 py-2.5 text-primary font-bold text-xs border border-primary/20 rounded-lg hover:bg-surface-container transition-colors cursor-pointer text-center bg-transparent"
                      >
                        {language === "de" ? "Eintrag hinzufügen" : "Add Entry"}
                      </button>
                    </div>
                  </div>

                </div>

              </div>
            </motion.div>
          )}

        </main>
      </div>

      {/* FLOATING ACTION BUTTON (+) for mobile - matching mininode-assistant.md */}
      {(activeView === "dashboard" || activeView === "inventory") && (
        <button 
          onClick={() => { resetForm(); setActiveView("add-item"); setSelectedItemId(null); }}
          className="lg:hidden fixed bottom-20 right-4 z-40 w-14 h-14 rounded-full bg-primary text-on-primary shadow-2xl flex items-center justify-center active:scale-90 transition-all hover:brightness-110 cursor-pointer border-2 border-surface"
          title={t("addItem")}
          aria-label={t("addItem")}
        >
          <Plus className="w-6 h-6 stroke-[2.5]" />
        </button>
      )}

      {/* FOOTER: Mobile bottom navigation layout matching the guidelines */}
      <nav className="lg:hidden fixed bottom-0 left-0 w-full bg-surface/85 backdrop-blur-lg border-t border-outline-variant/40 py-2.5 flex justify-around items-center z-40 shadow-[0_-4px_24px_rgba(0,0,0,0.06)] dark:shadow-[0_-4px_24px_rgba(0,0,0,0.35)] pb-safe">
        <button 
          onClick={() => { setActiveView("dashboard"); setSelectedItemId(null); }}
          className="flex flex-col items-center gap-1 text-xs bg-transparent border-none cursor-pointer relative py-1.5 px-4 rounded-xl"
        >
          {activeView === "dashboard" && (
            <motion.span 
              layoutId="activeTabPill" 
              className="absolute inset-0 bg-primary/10 rounded-full -z-10"
              transition={{ type: "spring", stiffness: 380, damping: 30 }}
            />
          )}
          <LayoutGrid className={`w-5 h-5 transition-transform duration-250 ${activeView === "dashboard" ? "text-primary scale-110" : "text-outline"}`} />
          <span className={`text-[9px] uppercase tracking-wider font-extrabold transition-colors duration-250 ${activeView === "dashboard" ? "text-primary" : "text-outline"}`}>
            {language === "de" ? "Übersicht" : "Home"}
          </span>
        </button>

        <button 
          onClick={() => { setActiveView("inventory"); setSelectedItemId(null); }}
          className="flex flex-col items-center gap-1 text-xs bg-transparent border-none cursor-pointer relative py-1.5 px-4 rounded-xl"
        >
          {activeView === "inventory" && (
            <motion.span 
              layoutId="activeTabPill" 
              className="absolute inset-0 bg-primary/10 rounded-full -z-10"
              transition={{ type: "spring", stiffness: 380, damping: 30 }}
            />
          )}
          <Folder className={`w-5 h-5 transition-transform duration-250 ${activeView === "inventory" ? "text-primary scale-110" : "text-outline"}`} />
          <span className={`text-[9px] uppercase tracking-wider font-extrabold transition-colors duration-250 ${activeView === "inventory" ? "text-primary" : "text-outline"}`}>
            {language === "de" ? "Inventar" : "Items"}
          </span>
        </button>

        <button 
          onClick={() => { resetForm(); setActiveView("add-item"); setSelectedItemId(null); }}
          className="flex flex-col items-center gap-1 text-xs bg-transparent border-none cursor-pointer relative py-1.5 px-4 rounded-xl"
        >
          {activeView === "add-item" && (
            <motion.span 
              layoutId="activeTabPill" 
              className="absolute inset-0 bg-primary/10 rounded-full -z-10"
              transition={{ type: "spring", stiffness: 380, damping: 30 }}
            />
          )}
          <Plus className={`w-5 h-5 transition-transform duration-250 ${activeView === "add-item" ? "text-primary scale-110" : "text-outline"}`} />
          <span className={`text-[9px] uppercase tracking-wider font-extrabold transition-colors duration-250 ${activeView === "add-item" ? "text-primary" : "text-outline"}`}>
            {language === "de" ? "Hinzufügen" : "Add"}
          </span>
        </button>

        <button 
          onClick={() => setShowHouseholdModal(true)}
          className="flex flex-col items-center gap-1 text-xs bg-transparent border-none cursor-pointer relative py-1.5 px-3 rounded-xl"
        >
          <Home className="w-5 h-5 text-outline" />
          <span className="text-[9px] uppercase tracking-wider font-extrabold text-outline truncate max-w-[55px]">
            {t("household")}
          </span>
        </button>

        {user && (
          <button 
            onClick={() => setShowSaveSlotsModal(true)}
            className="flex flex-col items-center gap-1 text-xs bg-transparent border-none cursor-pointer relative py-1.5 px-4 rounded-xl"
          >
            <Database className="w-5 h-5 text-outline" />
            <span className="text-[9px] uppercase tracking-wider font-extrabold text-outline">
              Backups
            </span>
          </button>
        )}
      </nav>

      {/* MODAL 0: Household & Member Management */}
      {showHouseholdModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-on-surface/40 dark:bg-black/85 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-surface border border-outline-variant rounded-2xl w-full max-w-lg p-6 shadow-2xl animate-in zoom-in-95 duration-200 max-h-[90vh] overflow-y-auto custom-scrollbar">
            <div className="flex justify-between items-center pb-4 border-b border-outline-variant/50">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-primary/10 text-primary flex items-center justify-center">
                  <Home className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-base font-bold text-on-surface">{t("manageHouseholds")}</h2>
                  <p className="text-[11px] text-outline">{language === "de" ? "Wechsle zwischen Haushalten oder verwalte die Mitglieder" : "Switch between households or manage members"}</p>
                </div>
              </div>
              <button 
                onClick={() => setShowHouseholdModal(false)}
                className="text-outline hover:text-on-surface bg-transparent border-none cursor-pointer p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* 1. Households List */}
            <div className="mt-4 space-y-3">
              <label className="text-xs font-bold text-on-surface-variant uppercase tracking-wider block">
                {language === "de" ? "Deine Haushalte" : "Your Households"}
              </label>
              <div className="space-y-2">
                {households.map(hh => {
                  const isActive = hh.id === activeHouseholdId;
                  const hhItemsCount = items.filter(i => (i.householdId || "hh-main") === hh.id).length;
                  return (
                    <div 
                      key={hh.id}
                      onClick={() => {
                        setActiveHouseholdId(hh.id);
                        setFormHouseholdId(hh.id);
                        showToast(language === "de" ? `Haushalt gewechselt: "${hh.name}"` : `Switched to household: "${hh.name}"`, "info");
                      }}
                      className={`p-3.5 rounded-xl border transition-all cursor-pointer flex items-center justify-between gap-3 ${
                        isActive 
                          ? "bg-primary/5 border-primary shadow-xs ring-1 ring-primary/20" 
                          : "bg-surface-container-low border-outline-variant/60 hover:bg-surface-container hover:border-outline"
                      }`}
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${isActive ? "bg-primary text-on-primary font-bold" : "bg-surface-container text-outline"}`}>
                          <Home className="w-4 h-4" />
                        </div>
                        <div className="min-w-0">
                          <p className="text-sm font-bold text-on-surface truncate flex items-center gap-2">
                            <span>{hh.name}</span>
                            {isActive && (
                              <span className="text-[10px] bg-primary/10 text-primary px-2 py-0.5 rounded-full font-bold">
                                {language === "de" ? "Aktiv" : "Active"}
                              </span>
                            )}
                          </p>
                          <p className="text-[11px] text-outline mt-0.5">
                            {hh.members.length} {t("householdMembers")} &bull; {hhItemsCount} {t("totalItems")}
                          </p>
                        </div>
                      </div>

                      {households.length > 1 && (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDeleteHousehold(hh.id);
                          }}
                          className="p-1.5 text-outline hover:text-error hover:bg-error-container/30 rounded-lg transition-colors border-none bg-transparent cursor-pointer"
                          title={language === "de" ? "Haushalt löschen" : "Delete household"}
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>

              {/* Form: Add New Household */}
              <form onSubmit={handleCreateHousehold} className="flex gap-2 pt-2">
                <input 
                  type="text"
                  placeholder={language === "de" ? "Neuer Haushalt (z.B. Ferienhaus)..." : "New household name..."}
                  value={newHouseholdName}
                  onChange={(e) => setNewHouseholdName(e.target.value)}
                  className="flex-1 bg-surface-container-low border border-outline-variant rounded-xl p-2.5 text-xs text-on-surface outline-hidden focus:ring-2 focus:ring-primary"
                />
                <button
                  type="submit"
                  disabled={!newHouseholdName.trim()}
                  className="px-4 py-2.5 bg-primary disabled:opacity-50 text-on-primary font-bold text-xs rounded-xl hover:brightness-110 active:scale-95 transition-all cursor-pointer border-none flex items-center gap-1 shrink-0"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>{t("newHousehold")}</span>
                </button>
              </form>
            </div>

            {/* 2. Members of the active household */}
            <div className="mt-6 pt-5 border-t border-outline-variant/40 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <label className="text-xs font-bold text-on-surface-variant uppercase tracking-wider block">
                    {t("householdMembers")} ({currentHousehold?.name})
                  </label>
                  <p className="text-[11px] text-outline mt-0.5">
                    {language === "de" ? "Personen, die Gegenständen als Besitzer zugewiesen werden können" : "People assignable as item owners"}
                  </p>
                </div>
                <span className="text-xs font-bold text-primary bg-primary/10 px-2 py-0.5 rounded-md">
                  {currentHousehold?.members.length} {language === "de" ? "Personen" : "People"}
                </span>
              </div>

              <div className="space-y-2 max-h-48 overflow-y-auto custom-scrollbar pr-1">
                {currentHousehold?.members.map(member => (
                  <div 
                    key={member.id}
                    className="p-2.5 rounded-xl bg-surface-container-low border border-outline-variant/40 flex items-center justify-between gap-3 text-xs"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div className="w-7 h-7 rounded-full bg-secondary/15 text-secondary flex items-center justify-center font-bold text-xs shrink-0">
                        {member.name.charAt(0).toUpperCase()}
                      </div>
                      <div className="min-w-0">
                        <p className="font-bold text-on-surface truncate">{member.name}</p>
                        <p className="text-[10px] text-outline">
                          {member.role === "admin" ? (language === "de" ? "Verwalter (Admin)" : "Admin")
                           : member.role === "editor" ? (language === "de" ? "Bearbeiter" : "Editor")
                           : (language === "de" ? "Nur Lesen" : "Viewer")}
                        </p>
                      </div>
                    </div>

                    {currentHousehold.members.length > 1 && (
                      <button
                        onClick={() => handleRemoveMember(member.id)}
                        className="text-outline hover:text-error p-1 rounded-md hover:bg-error-container/20 border-none bg-transparent cursor-pointer"
                        title={language === "de" ? "Mitglied entfernen" : "Remove member"}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                ))}
              </div>

              {/* Form: Add New Member */}
              <form onSubmit={handleAddMember} className="space-y-2 pt-2">
                <div className="flex gap-2">
                  <input 
                    type="text"
                    placeholder={language === "de" ? "Name (z.B. Partner/in, Kind)..." : "Member name..."}
                    value={newMemberName}
                    onChange={(e) => setNewMemberName(e.target.value)}
                    className="flex-1 bg-surface-container-low border border-outline-variant rounded-xl p-2.5 text-xs text-on-surface outline-hidden focus:ring-2 focus:ring-primary"
                  />
                  <select
                    value={newMemberRole}
                    onChange={(e) => setNewMemberRole(e.target.value as any)}
                    className="bg-surface-container-low border border-outline-variant rounded-xl px-2.5 py-2 text-xs text-on-surface outline-hidden cursor-pointer"
                  >
                    <option value="admin">{language === "de" ? "Admin" : "Admin"}</option>
                    <option value="editor">{language === "de" ? "Bearbeiter" : "Editor"}</option>
                    <option value="viewer">{language === "de" ? "Leser" : "Viewer"}</option>
                  </select>
                </div>
                <button
                  type="submit"
                  disabled={!newMemberName.trim()}
                  className="w-full py-2 bg-secondary disabled:opacity-50 text-on-secondary font-bold text-xs rounded-xl hover:brightness-110 active:scale-95 transition-all cursor-pointer border-none flex items-center justify-center gap-1.5"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>{t("addMember")}</span>
                </button>
              </form>
            </div>

            <div className="mt-6 pt-4 border-t border-outline-variant/30 flex justify-end">
              <button
                type="button"
                onClick={() => setShowHouseholdModal(false)}
                className="px-5 py-2 bg-primary text-on-primary font-bold text-xs rounded-xl hover:brightness-110 active:scale-95 transition-all cursor-pointer border-none"
              >
                {language === "de" ? "Fertig" : "Done"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 1: Authentication overlay */}
      {showAuthModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-on-surface/40 dark:bg-black/85 backdrop-blur-xs">
          <div className="bg-surface border border-outline-variant rounded-2xl w-full max-w-md p-6 shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="flex justify-between items-center pb-4 border-b border-outline-variant/50">
              <h2 className="text-lg font-bold text-on-surface">
                {isSignUp 
                  ? (language === "de" ? "Registrieren bei Haushalts Inventar" : "Sign Up to Household Inventory") 
                  : (language === "de" ? "Anmelden bei Haushalts Inventar" : "Sign In to Household Inventory")}
              </h2>
              <button 
                onClick={() => setShowAuthModal(false)}
                className="text-outline hover:text-on-surface cursor-pointer bg-transparent border-none"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAuthSubmit} className="space-y-4 mt-4">
              {authError && (
                <div className="p-3 bg-red-50 dark:bg-red-950/20 text-error text-xs rounded-lg border border-red-100 dark:border-red-900/30 font-medium">
                  {authError}
                </div>
              )}

              <div className="flex flex-col gap-1 text-xs">
                <label className="font-bold text-on-surface-variant">{language === "de" ? "Profil-Benutzername" : "Profile Username"}</label>
                <input 
                  type="text"
                  required
                  placeholder="e.g. JD"
                  value={authUsername}
                  onChange={(e) => setAuthUsername(e.target.value)}
                  className="bg-surface-container-low border border-outline-variant rounded-lg p-2.5 text-sm focus:ring-2 focus:ring-primary focus:bg-surface text-on-surface outline-hidden"
                />
              </div>

              <div className="flex flex-col gap-1 text-xs">
                <label className="font-bold text-on-surface-variant">{language === "de" ? "Passwort" : "Password"}</label>
                <input 
                  type="password"
                  required
                  placeholder={language === "de" ? "Mindestens 4 Zeichen" : "At least 4 characters"}
                  value={authPassword}
                  onChange={(e) => setAuthPassword(e.target.value)}
                  className="bg-surface-container-low border border-outline-variant rounded-lg p-2.5 text-sm focus:ring-2 focus:ring-primary focus:bg-surface text-on-surface outline-hidden"
                />
              </div>

              <button 
                type="submit"
                className="w-full py-2.5 bg-primary text-on-primary font-bold text-xs rounded-lg shadow-sm hover:brightness-110 transition-all cursor-pointer text-center border-none"
              >
                {isSignUp 
                  ? (language === "de" ? "Konto erstellen" : "Create Profile Account") 
                  : (language === "de" ? "Anmelden" : "Access Inventory Space")}
              </button>
            </form>

            <div className="mt-4 pt-4 border-t border-outline-variant/30 text-center space-y-3">
              <button 
                onClick={() => setIsSignUp(!isSignUp)}
                className="text-xs text-primary font-bold hover:underline block mx-auto bg-transparent border-none cursor-pointer"
              >
                {isSignUp 
                  ? (language === "de" ? "Bereits registriert? Hier anmelden" : "Already registered? Sign In instead") 
                  : (language === "de" ? "Konto benötigt? Jetzt registrieren" : "Need a profile? Sign Up now")}
              </button>
              
              <div className="relative flex py-2 items-center">
                <div className="flex-grow border-t border-outline-variant/30"></div>
                <span className="flex-shrink mx-4 text-[10px] text-outline uppercase font-bold tracking-wider">Or</span>
                <div className="flex-grow border-t border-outline-variant/30"></div>
              </div>

              <button 
                onClick={() => { handleGuestLogin(); setShowAuthModal(false); }}
                className="w-full py-2.5 border border-outline-variant hover:bg-surface-container-low text-on-surface font-semibold text-xs rounded-lg transition-all cursor-pointer text-center bg-transparent"
              >
                {language === "de" ? "Als Gast offline fortfahren" : "Continue Offline as Guest"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 2: Add Room Dynamic Modal */}
      {showAddRoomModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-on-surface/45 dark:bg-black/85 backdrop-blur-xs">
          <div className="bg-surface border border-outline-variant rounded-xl w-full max-w-sm p-6 shadow-xl animate-in zoom-in-95 duration-150">
            <div className="flex justify-between items-center pb-3 border-b border-outline-variant/50">
              <h2 className="text-sm font-bold text-on-surface">{language === "de" ? "Raum hinzufügen" : "Add New Room Collection"}</h2>
              <button onClick={() => setShowAddRoomModal(false)} className="text-outline hover:text-on-surface bg-transparent border-none cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>
            <form onSubmit={handleAddRoom} className="space-y-4 mt-4">
              <div className="flex flex-col gap-1 text-xs">
                <label className="font-bold text-on-surface-variant">{language === "de" ? "Raumname" : "Room Name"}</label>
                <input 
                  type="text"
                  required
                  placeholder="e.g. Workspace, Attic, Studio"
                  value={newRoomName}
                  onChange={(e) => setNewRoomName(e.target.value)}
                  className="bg-surface-container-low border border-outline-variant rounded-lg p-2.5 text-sm focus:ring-2 focus:ring-primary text-on-surface outline-hidden"
                />
              </div>
              <button 
                type="submit"
                className="w-full py-2 bg-primary text-on-primary font-bold text-xs rounded-lg hover:brightness-110 active:scale-95 transition-all cursor-pointer border-none"
              >
                {language === "de" ? "Raum registrieren" : "Register Room"}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 3: Receipt Lightbox ZOOM overlay */}
      {showReceiptZoom && (
        <div 
          onClick={() => setShowReceiptZoom(null)}
          className="fixed inset-0 z-50 flex items-center justify-center bg-on-surface/90 dark:bg-black/95 backdrop-blur-xs p-4 cursor-zoom-out animate-in fade-in duration-200"
        >
          <div className="relative max-w-3xl max-h-[90vh] overflow-hidden rounded-xl border border-white/20 bg-black">
            <img src={showReceiptZoom} alt="Zoomed Receipt" className="max-w-full max-h-[85vh] object-contain mx-auto" />
            <button 
              onClick={() => setShowReceiptZoom(null)}
              className="absolute top-4 right-4 p-2 bg-black/60 hover:bg-black/80 text-white rounded-full transition-colors border-none cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
            <p className="text-center text-xs text-white/70 py-2.5 bg-black/60">{language === "de" ? "Haushalts Inventar Beleg - Verifizierter Scan" : "Household Inventory Document - Verified Scan"}</p>
          </div>
        </div>
      )}

      {/* MODAL 4: Multiple Cloud Save Slots Backup Drawer */}
      {showSaveSlotsModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-on-surface/40 dark:bg-black/85 backdrop-blur-xs">
          <div className="bg-surface border border-outline-variant rounded-2xl w-full max-w-lg p-6 shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="flex justify-between items-center pb-4 border-b border-outline-variant/50">
              <div className="flex items-center gap-1.5">
                <Database className="w-5 h-5 text-primary" />
                <h2 className="text-lg font-bold text-on-surface">{language === "de" ? "Konto-Backup Speicherplätze" : "Account Backup Save Slots"}</h2>
              </div>
              <button onClick={() => setShowSaveSlotsModal(false)} className="text-outline hover:text-on-surface bg-transparent border-none cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-outline mt-2 leading-relaxed">
              {language === "de" 
                ? "Sichern Sie Ihr aktives Inventar und Ihren Navigationsstatus direkt in Ihrem lokalen Profil-Konto. Das Wiederherstellen synchronisiert Ihre Daten sofort." 
                : "Backup your active inventory and navigation state directly to your local host account. Resuming a slot synchronizes your lists immediately on other devices."}
            </p>

            {/* Create backup slot */}
            <div className="mt-4 p-4 bg-surface-container-low rounded-xl border border-outline-variant/30 flex gap-2 items-end">
              <div className="flex flex-col gap-1 text-xs flex-1">
                <label className="font-bold text-on-surface-variant">{language === "de" ? "Bezeichnung des Backups" : "Backup Slot Label"}</label>
                <input 
                  type="text"
                  placeholder={language === "de" ? "z.B. Stand Juni - Wohnzimmer" : "e.g., Run 1 - Active Kitchen Setup"}
                  value={newSlotLabel}
                  onChange={(e) => setNewSlotLabel(e.target.value)}
                  className="bg-surface border border-outline-variant rounded-lg p-2 text-xs focus:ring-2 focus:ring-primary text-on-surface outline-hidden"
                />
              </div>
              <button 
                onClick={handleCreateSaveSlot}
                className="py-2.5 px-4 bg-primary text-on-primary font-bold text-xs rounded-lg hover:brightness-110 active:scale-95 transition-all cursor-pointer whitespace-nowrap border-none"
              >
                {language === "de" ? "Sichern" : "Create Backup"}
              </button>
            </div>

            {/* Save slot listing */}
            <div className="mt-6 space-y-3">
              <h3 className="text-xs font-bold text-on-surface-variant uppercase tracking-wider">{language === "de" ? "Gespeicherte Backups" : "Saved Backup Slots"}</h3>
              <div className="max-h-56 overflow-y-auto custom-scrollbar space-y-2 p-1">
                {saveSlots.length === 0 ? (
                  <p className="text-xs text-outline italic text-center py-6">{language === "de" ? "Noch keine Backup-Slots für dieses Profil gespeichert." : "No cloud backup slots saved yet in this account profile."}</p>
                ) : (
                  saveSlots.map((slot) => (
                    <div 
                      key={slot.id} 
                      className="p-3 bg-surface border border-outline-variant rounded-lg flex items-center justify-between gap-3 text-xs shadow-xs hover:border-primary/45 transition-colors"
                    >
                      <div>
                        <p className="font-bold text-on-surface">{slot.label}</p>
                        <p className="text-[10px] text-outline mt-0.5">
                          {language === "de" ? "Gesichert am:" : "Saved:"} {new Date(slot.savedAt).toLocaleString(language === "de" ? "de-DE" : "en-US", { month: "short", day: "2-digit", hour: "2-digit", minute: "2-digit" })}
                        </p>
                      </div>
                      <div className="flex gap-2 shrink-0">
                        <button 
                          onClick={() => handleResumeSaveSlot(slot)}
                          className="px-3 py-1.5 bg-secondary text-white font-bold text-[10px] rounded hover:brightness-110 transition-all active:scale-95 cursor-pointer border-none"
                        >
                          {language === "de" ? "Laden" : "Restore"}
                        </button>
                        <button 
                          onClick={() => handleDeleteSaveSlot(slot.id)}
                          className="p-1.5 text-error hover:bg-error-container hover:text-on-error-container rounded transition-all cursor-pointer bg-transparent border-none"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-outline-variant/30 text-right">
              <button 
                onClick={() => setShowSaveSlotsModal(false)}
                className="px-4 py-2 border border-outline-variant text-on-surface font-semibold text-xs rounded-lg hover:bg-surface-container-low transition-colors active:scale-95 cursor-pointer bg-transparent"
              >
                {language === "de" ? "Schließen" : "Close Backups Panel"}
              </button>
            </div>

          </div>
        </div>
      )}

      {/* MODAL 5: Asset Distribution Deep Dive */}
      {showDeepDiveModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-on-surface/40 dark:bg-black/85 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-surface border border-outline-variant rounded-2xl w-full max-w-lg p-6 shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="flex justify-between items-center pb-4 border-b border-outline-variant/50">
              <div className="flex items-center gap-1.5">
                <LayoutGrid className="w-5 h-5 text-primary" />
                <h2 className="text-lg font-bold text-on-surface">
                  {language === "de" ? "Anlagenverteilung Analyse" : "Asset Distribution Analysis"}
                </h2>
              </div>
              <button onClick={() => setShowDeepDiveModal(false)} className="text-outline hover:text-on-surface bg-transparent border-none cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="mt-4 space-y-6">
              {/* Summary Stats Grid */}
              <div className="grid grid-cols-3 gap-3">
                <div className="p-3 bg-surface-container-low border border-outline-variant/30 rounded-xl text-center">
                  <p className="text-[10px] font-bold text-outline uppercase tracking-wider">{language === "de" ? "Gesamtwert" : "Total Value"}</p>
                  <p className="text-sm font-black text-on-surface mt-1">€{categoryStats.totalValue.toLocaleString(language === "de" ? "de-DE" : "en-US", { minimumFractionDigits: 0, maximumFractionDigits: 0 })}</p>
                </div>
                <div className="p-3 bg-surface-container-low border border-outline-variant/30 rounded-xl text-center">
                  <p className="text-[10px] font-bold text-outline uppercase tracking-wider">{language === "de" ? "Artikel" : "Total Items"}</p>
                  <p className="text-sm font-black text-on-surface mt-1">{items.length}</p>
                </div>
                <div className="p-3 bg-surface-container-low border border-outline-variant/30 rounded-xl text-center">
                  <p className="text-[10px] font-bold text-outline uppercase tracking-wider">{language === "de" ? "Kategorien" : "Categories"}</p>
                  <p className="text-sm font-black text-on-surface mt-1">{categoryStats.list.length}</p>
                </div>
              </div>

              {/* Dynamic Stacked Distribution Bar */}
              {items.length > 0 && (
                <div className="space-y-1.5">
                  <p className="text-xs font-bold text-on-surface-variant">{language === "de" ? "Visuelle Verteilung" : "Visual Distribution Share"}</p>
                  <div className="w-full h-4 rounded-full overflow-hidden flex bg-surface-container">
                    {categoryStats.list.map((stat) => (
                      <div 
                        key={stat.category}
                        style={{ width: `${stat.percentage}%` }}
                        className={`${getCategoryColor(stat.category)} h-full transition-all duration-500`}
                        title={`${getCategoryTranslation(stat.category, language)}: ${stat.percentage.toFixed(1)}%`}
                      />
                    ))}
                  </div>
                </div>
              )}

              {/* Category Breakdown list */}
              <div className="space-y-3">
                <h3 className="text-xs font-bold text-on-surface-variant uppercase tracking-wider">
                  {language === "de" ? "Kategorien Aufschlüsselung" : "Category Breakdown"}
                </h3>
                <div className="space-y-3 max-h-60 overflow-y-auto custom-scrollbar p-1">
                  {items.length === 0 ? (
                    <p className="text-xs text-outline italic text-center py-6">
                      {language === "de" ? "Fügen Sie Artikel hinzu, um die Verteilung zu sehen." : "No items logged. Add items to visualize distribution."}
                    </p>
                  ) : (
                    categoryStats.list.map((stat) => (
                      <div key={stat.category} className="space-y-1">
                        <div className="flex justify-between items-center text-xs">
                          <div className="flex items-center gap-2">
                            <span className={`w-2.5 h-2.5 rounded-full ${getCategoryColor(stat.category)}`} />
                            <span className="font-bold text-on-surface">{getCategoryTranslation(stat.category, language)}</span>
                            <span className="text-[10px] text-outline font-normal">({stat.count} {stat.count === 1 ? (language === "de" ? "Artikel" : "item") : (language === "de" ? "Artikel" : "items")})</span>
                          </div>
                          <div className="text-right font-semibold text-on-surface">
                            <span>€{stat.value.toLocaleString(language === "de" ? "de-DE" : "en-US", { minimumFractionDigits: 0, maximumFractionDigits: 0 })}</span>
                            <span className="text-outline text-[10px] ml-1.5">({stat.percentage.toFixed(0)}%)</span>
                          </div>
                        </div>
                        <div className="w-full h-1.5 bg-surface-container-low border border-outline-variant/30 rounded-full overflow-hidden">
                          <div 
                            style={{ width: `${stat.percentage}%` }}
                            className={`h-full ${getCategoryColor(stat.category)} rounded-full`}
                          />
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-outline-variant/30 text-right">
              <button 
                onClick={() => setShowDeepDiveModal(false)}
                className="px-4 py-2 bg-primary text-on-primary font-bold text-xs rounded-lg hover:brightness-110 active:scale-95 transition-all cursor-pointer border-none"
              >
                {language === "de" ? "Schließen" : "Close Analysis"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 6: Insurance Coverage Audit */}
      {showInsuranceModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-on-surface/40 dark:bg-black/85 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-surface border border-outline-variant rounded-2xl w-full max-w-lg p-6 shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="flex justify-between items-center pb-4 border-b border-outline-variant/50">
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-5 h-5 text-secondary" />
                <h2 className="text-lg font-bold text-on-surface">
                  {language === "de" ? "Deckungsprüfung & Versicherungsschutz" : "Coverage Audit & Policy Tuning"}
                </h2>
              </div>
              <button onClick={() => setShowInsuranceModal(false)} className="text-outline hover:text-on-surface bg-transparent border-none cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="mt-4 space-y-5">
              {/* Status Indicator Card */}
              <div className={`p-4 rounded-xl border flex gap-3 items-start ${
                items.length === 0 
                  ? "bg-surface-container-low border-outline-variant/30 text-on-surface"
                  : categoryStats.totalValue > insuranceLimit 
                    ? "bg-error/10 border-error/25 text-error-container"
                    : "bg-secondary/10 border-secondary/25 text-on-surface"
              }`}>
                <div className="shrink-0 mt-0.5">
                  {items.length === 0 ? (
                    <Info className="w-5 h-5 text-outline" />
                  ) : categoryStats.totalValue > insuranceLimit ? (
                    <ShieldAlert className="w-5 h-5 text-error" />
                  ) : (
                    <CheckCircle2 className="w-5 h-5 text-secondary" />
                  )}
                </div>
                <div className="text-xs">
                  <p className="font-bold text-on-surface">
                    {items.length === 0 
                      ? (language === "de" ? "Keine Vermögenswerte erfasst" : "No Registered Assets Yet")
                      : categoryStats.totalValue > insuranceLimit
                        ? (language === "de" ? "⚠️ Warnung: Unterversichert!" : "⚠️ Warning: Underinsured!")
                        : (language === "de" ? "Optimale Abdeckung" : "Fully Insured Coverage")}
                  </p>
                  <p className="text-outline mt-1 leading-relaxed">
                    {items.length === 0 ? (
                      language === "de"
                        ? "Fügen Sie zuerst Artikel in Ihr Inventar ein, um Ihren Versicherungsschutz mit Ihrem aktuellen Limit zu vergleichen."
                        : "Add items to your inventory to audit your total replacement value against your policy limit."
                    ) : categoryStats.totalValue > insuranceLimit ? (
                      language === "de"
                        ? `Ihr erfasstes Vermögen (€${categoryStats.totalValue.toLocaleString("de-DE", { minimumFractionDigits: 0, maximumFractionDigits: 0 })}) übersteigt Ihre Versicherungssumme (€${insuranceLimit.toLocaleString("de-DE")}) um €${(categoryStats.totalValue - insuranceLimit).toLocaleString("de-DE", { minimumFractionDigits: 0, maximumFractionDigits: 0 })}. Wir empfehlen, Ihre Versicherungspolice aufzustocken.`
                        : `Your recorded assets (€${categoryStats.totalValue.toLocaleString("en-US", { minimumFractionDigits: 0, maximumFractionDigits: 0 })}) exceed your insurance policy limit (€${insuranceLimit.toLocaleString("en-US")}) by €${(categoryStats.totalValue - insuranceLimit).toLocaleString("en-US", { minimumFractionDigits: 0, maximumFractionDigits: 0 })}. Consider adjusting your policy coverage to stay safe.`
                    ) : (
                      language === "de"
                        ? `Hervorragend! Ihr gesamtes Inventarvermögen von €${categoryStats.totalValue.toLocaleString("de-DE", { minimumFractionDigits: 0, maximumFractionDigits: 0 })} ist vollständig durch Ihr aktuelles Versicherungslimit von €${insuranceLimit.toLocaleString("de-DE")} abgedeckt.`
                        : `Excellent! Your total inventory value of €${categoryStats.totalValue.toLocaleString("en-US", { minimumFractionDigits: 0, maximumFractionDigits: 0 })} is fully protected under your active coverage limit of €${insuranceLimit.toLocaleString("en-US")}.`
                    )}
                  </p>
                </div>
              </div>

              {/* Progress visualizer */}
              {items.length > 0 && (
                <div className="space-y-1.5">
                  <div className="flex justify-between text-xs font-bold text-on-surface-variant">
                    <span>{language === "de" ? "Genutztes Limit" : "Coverage Utilization"}</span>
                    <span>{((categoryStats.totalValue / insuranceLimit) * 100).toFixed(0)}%</span>
                  </div>
                  <div className="w-full h-2.5 bg-surface-container rounded-full overflow-hidden">
                    <div 
                      style={{ width: `${Math.min(100, (categoryStats.totalValue / insuranceLimit) * 100)}%` }}
                      className={`h-full rounded-full transition-all duration-500 ${
                        categoryStats.totalValue > insuranceLimit 
                          ? "bg-error" 
                          : categoryStats.totalValue > insuranceLimit * 0.8 
                            ? "bg-amber-500" 
                            : "bg-secondary"
                      }`}
                    />
                  </div>
                  <div className="flex justify-between text-[10px] text-outline">
                    <span>€0</span>
                    <span>€{insuranceLimit.toLocaleString()} ({language === "de" ? "Aktuelles Limit" : "Active Limit"})</span>
                  </div>
                </div>
              )}

              {/* Edit coverage limit input */}
              <div className="p-4 bg-surface-container-low border border-outline-variant/30 rounded-xl space-y-3">
                <div className="flex flex-col gap-1 text-xs">
                  <label className="font-bold text-on-surface-variant">
                    {language === "de" ? "Aktuelles Hausrat-Versicherungslimit (€)" : "Active Household Content Insurance Limit (€)"}
                  </label>
                  <p className="text-[10px] text-outline leading-normal mb-1">
                    {language === "de" 
                      ? "Geben Sie die Deckungssumme Ihrer bestehenden Hausratversicherung an, um Echtzeit-Audits durchzuführen."
                      : "Enter your active insurance coverage limit to update the real-time policy safety audit."}
                  </p>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-outline font-bold text-sm">€</span>
                    <input 
                      type="number"
                      required
                      min="0"
                      step="1000"
                      value={insuranceLimit}
                      onChange={(e) => setInsuranceLimit(Math.max(0, parseFloat(e.target.value) || 0))}
                      className="bg-surface border border-outline-variant rounded-lg p-2.5 pl-7 text-sm focus:ring-2 focus:ring-primary text-on-surface outline-hidden w-full font-semibold"
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-outline-variant/30 text-right">
              <button 
                onClick={() => setShowInsuranceModal(false)}
                className="px-4 py-2 bg-secondary text-white font-bold text-xs rounded-lg hover:brightness-110 active:scale-95 transition-all cursor-pointer border-none"
              >
                {language === "de" ? "Fertigstellen" : "Save & Close"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 7: Quick Scan Receipt Flow */}
      {showScanReceiptModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-on-surface/40 dark:bg-black/85 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-surface border border-outline-variant rounded-2xl w-full max-w-lg p-6 shadow-2xl animate-in zoom-in-95 duration-200 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center pb-4 border-b border-outline-variant/50">
              <div className="flex items-center gap-2">
                <UploadCloud className="w-5 h-5 text-primary" />
                <h2 className="text-lg font-bold text-on-surface">
                  {language === "de" ? "Kaufbeleg erfassen & zuweisen" : "Scan Purchase Receipt"}
                </h2>
              </div>
              <button 
                onClick={() => { setShowScanReceiptModal(false); setScanReceiptPreview(""); }} 
                className="text-outline hover:text-on-surface bg-transparent border-none cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="mt-4 space-y-4">
              <p className="text-xs text-outline leading-relaxed">
                {language === "de" 
                  ? "Lade einen Kassenbeleg oder eine Rechnung hoch. Das Dokument wird automatisch zur Erfassung ausgewertet."
                  : "Upload a purchase bill or invoice. Document will be inspected to register your asset."}
              </p>

              {/* Upload Box */}
              <label className="cursor-pointer border-2 border-dashed border-outline-variant hover:border-primary hover:bg-primary/5 rounded-xl p-6 flex flex-col items-center justify-center gap-3 transition-all block text-center">
                <input 
                  type="file" 
                  accept="image/*,application/pdf"
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    if (!f) return;
                    if (f.size > 4 * 1024 * 1024) {
                      showToast(language === "de" ? "Datei überschreitet 4 MB Limit." : "File exceeds 4MB limit.", "error");
                      return;
                    }
                    const reader = new FileReader();
                    reader.onloadend = () => {
                      setScanReceiptPreview(reader.result as string);
                      setScanReceiptFile(f);
                      showToast(language === "de" ? "Beleg erfolgreich geladen!" : "Receipt uploaded successfully!", "success");
                    };
                    reader.readAsDataURL(f);
                  }}
                  className="hidden" 
                />
                <div className="w-12 h-12 rounded-full bg-surface-container-high flex items-center justify-center text-primary mx-auto">
                  <UploadCloud className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-xs font-bold text-on-surface">
                    {language === "de" ? "Beleg per Drag & Drop oder " : "Drag & drop receipt or "}<span className="text-primary underline">{language === "de" ? "durchsuchen" : "browse"}</span>
                  </p>
                  <p className="text-[10px] text-outline mt-1">{language === "de" ? "Unterstützt PDF, JPG, PNG bis zu 4 MB" : "Supports PDF, JPG, PNG up to 4MB"}</p>
                </div>
              </label>

              {/* Receipt Preview & Auto-Filled metadata */}
              {scanReceiptPreview ? (
                <div className="space-y-4 p-4 bg-surface-container-low rounded-xl border border-outline-variant/40">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-on-surface flex items-center gap-1.5">
                      <Sparkles className="w-4 h-4 text-primary" />
                      {language === "de" ? "Erkannte Beleg-Informationen" : "Document Detected Information"}
                    </span>
                    <span className="text-[10px] bg-emerald-100 text-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-300 px-2 py-0.5 rounded-full font-bold">
                      {language === "de" ? "Verifiziert" : "Verified"}
                    </span>
                  </div>

                  <div className="aspect-[4/3] rounded-lg overflow-hidden bg-black/5 border border-outline-variant/30 flex items-center justify-center">
                    <img src={scanReceiptPreview} alt="Receipt preview" className="w-full h-full object-contain" />
                  </div>

                  <div className="grid grid-cols-2 gap-3 text-xs">
                    <div>
                      <label className="text-[10px] font-bold text-outline uppercase">{language === "de" ? "Händler" : "Merchant"}</label>
                      <input 
                        type="text" 
                        value={scanReceiptMerchant}
                        onChange={(e) => setScanReceiptMerchant(e.target.value)}
                        className="w-full bg-surface border border-outline-variant rounded-lg p-2 text-xs text-on-surface font-semibold mt-1 outline-hidden"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] font-bold text-outline uppercase">{language === "de" ? "Kaufpreis" : "Purchase Price"}</label>
                      <input 
                        type="number" 
                        value={scanReceiptPrice}
                        onChange={(e) => setScanReceiptPrice(e.target.value)}
                        className="w-full bg-surface border border-outline-variant rounded-lg p-2 text-xs text-on-surface font-semibold mt-1 outline-hidden"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] font-bold text-outline uppercase">{language === "de" ? "Gegenstand" : "Asset Name"}</label>
                      <input 
                        type="text" 
                        value={scanReceiptName}
                        onChange={(e) => setScanReceiptName(e.target.value)}
                        className="w-full bg-surface border border-outline-variant rounded-lg p-2 text-xs text-on-surface font-semibold mt-1 outline-hidden"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] font-bold text-outline uppercase">{language === "de" ? "Kaufdatum" : "Date"}</label>
                      <input 
                        type="date" 
                        value={scanReceiptDate}
                        onChange={(e) => setScanReceiptDate(e.target.value)}
                        className="w-full bg-surface border border-outline-variant rounded-lg p-2 text-xs text-on-surface font-semibold mt-1 outline-hidden"
                      />
                    </div>
                  </div>

                  <button 
                    onClick={() => {
                      resetForm();
                      setFormName(scanReceiptName);
                      setFormPrice(scanReceiptPrice);
                      setFormDate(scanReceiptDate);
                      setFormStore(scanReceiptMerchant);
                      setFormCategory(scanReceiptCategory);
                      setFormRoom(scanReceiptLocation);
                      setFormManualUrl(scanReceiptPreview);
                      setShowScanReceiptModal(false);
                      setActiveView("add-item");
                      showToast(language === "de" ? "Beleg übernommen. Angaben überprüfen & speichern." : "Receipt attached. Review & save your item.", "info");
                    }}
                    className="w-full py-2.5 bg-primary text-on-primary font-bold text-xs rounded-xl shadow-xs hover:brightness-110 active:scale-95 transition-all cursor-pointer border-none flex items-center justify-center gap-1.5"
                  >
                    <Check className="w-4 h-4" />
                    <span>{language === "de" ? "Artikel mit diesem Beleg erfassen" : "Create Item with this Receipt"}</span>
                  </button>
                </div>
              ) : null}
            </div>
          </div>
        </div>
      )}

      {/* MODAL 8: Maintenance Entry Modal */}
      {maintenanceModalItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-on-surface/40 dark:bg-black/85 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-surface border border-outline-variant rounded-2xl w-full max-w-md p-6 shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="flex justify-between items-center pb-4 border-b border-outline-variant/50">
              <div className="flex items-center gap-2">
                <Wrench className="w-5 h-5 text-primary" />
                <h2 className="text-base font-bold text-on-surface">
                  {language === "de" ? "Wartungsaktivität erfassen" : "Log Maintenance Entry"}
                </h2>
              </div>
              <button 
                onClick={() => setMaintenanceModalItem(null)} 
                className="text-outline hover:text-on-surface bg-transparent border-none cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={(e) => { e.preventDefault(); handleSaveMaintenanceEntry(); }} className="mt-4 space-y-4">
              <div>
                <p className="text-xs text-outline mb-2">
                  {language === "de" ? "Gegenstand: " : "Asset: "}
                  <strong className="text-on-surface">{maintenanceModalItem.name}</strong>
                </p>
                <label className="text-xs font-bold text-on-surface-variant block mb-1">
                  {language === "de" ? "Beschreibung der Aktivität" : "Activity Description"}
                </label>
                <input 
                  type="text"
                  required
                  placeholder={language === "de" ? "z.B. Filterwechsel, Entkalkung, Reinigung" : "e.g., Water Filter Replacement, Descaling"}
                  value={maintenanceInputText}
                  onChange={(e) => setMaintenanceInputText(e.target.value)}
                  className="w-full bg-surface-container-low border border-outline-variant rounded-xl p-3 text-sm focus:ring-2 focus:ring-primary text-on-surface outline-hidden"
                  autoFocus
                />
              </div>

              <div className="flex gap-2 justify-end pt-3 border-t border-outline-variant/30">
                <button 
                  type="button"
                  onClick={() => setMaintenanceModalItem(null)}
                  className="px-4 py-2 border border-outline-variant text-on-surface font-semibold text-xs rounded-lg hover:bg-surface-container-low transition-colors active:scale-95 cursor-pointer bg-transparent"
                >
                  {t("cancel")}
                </button>
                <button 
                  type="submit"
                  className="px-5 py-2 bg-primary text-on-primary font-bold text-xs rounded-lg hover:brightness-110 active:scale-95 transition-all cursor-pointer border-none"
                >
                  {t("confirm")}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 9: Delete Item Confirmation Modal */}
      {deleteConfirmItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-on-surface/40 dark:bg-black/85 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-surface border border-outline-variant rounded-2xl w-full max-w-sm p-6 shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="w-12 h-12 rounded-full bg-red-100 dark:bg-red-950/40 text-error flex items-center justify-center mx-auto mb-4">
              <Trash2 className="w-6 h-6" />
            </div>

            <h3 className="text-base font-bold text-on-surface text-center">
              {language === "de" ? "Gegenstand löschen?" : "Delete Asset Item?"}
            </h3>

            <p className="text-xs text-outline text-center mt-2 leading-relaxed">
              {language === "de" 
                ? `Möchten Sie "${deleteConfirmItem.name}" wirklich dauerhaft aus Ihrem Inventar entfernen?`
                : `Are you sure you want to permanently delete "${deleteConfirmItem.name}" from your inventory?`}
            </p>

            <div className="flex gap-2 mt-6">
              <button 
                onClick={() => setDeleteConfirmItem(null)}
                className="flex-1 py-2.5 border border-outline-variant text-on-surface font-semibold text-xs rounded-xl hover:bg-surface-container transition-colors active:scale-95 cursor-pointer bg-transparent"
              >
                {t("cancel")}
              </button>
              <button 
                onClick={executeDeleteItem}
                className="flex-1 py-2.5 bg-error text-white font-bold text-xs rounded-xl hover:brightness-110 active:scale-95 transition-all cursor-pointer border-none"
              >
                {language === "de" ? "Löschen" : "Delete"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Toast Notification Banner */}
      {toastMessage && (
        <div className="fixed bottom-20 sm:bottom-6 right-4 sm:right-6 z-50 animate-in slide-in-from-bottom-5 fade-in duration-200 max-w-sm">
          <div className={`p-3.5 rounded-xl shadow-xl border flex items-center gap-2.5 text-xs font-semibold backdrop-blur-md ${
            toastMessage.type === "success" 
              ? "bg-emerald-800 text-white border-emerald-700" 
              : toastMessage.type === "error" 
                ? "bg-error text-white border-red-800" 
                : "bg-surface-container-highest text-on-surface border-outline-variant"
          }`}>
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span className="flex-1">{toastMessage.text}</span>
            <button 
              onClick={() => setToastMessage(null)}
              className="p-1 hover:bg-white/20 rounded-full transition-colors bg-transparent border-none text-white cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

    </div>
  );
}
