/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface MaintenanceLogEntry {
  id: string;
  title: string;
  date: string;
  status: "Completed" | "Scheduled";
}

export interface HouseholdMember {
  id: string;
  name: string;
  role: "admin" | "editor" | "viewer";
  isMiniNodeUser?: boolean;
}

export interface Household {
  id: string;
  name: string;
  members: HouseholdMember[];
  createdAt: number;
}

export interface InventoryItem {
  id: string;
  name: string;
  category: string;
  location: string;
  purchasePrice: number;
  purchaseDate: string; // YYYY-MM-DD
  warrantyExpiry: string; // YYYY-MM-DD
  warrantyDuration?: number; // months
  warrantyProvider?: string;
  warrantyWhereApplies?: string; // where warranty applies (store, country, provider)
  policyNumber?: string;
  owner?: string; // assigned owner name or member
  householdId?: string; // assigned household
  notes?: string;
  photoId?: string;
  photoUrl?: string;
  manualId?: string;
  manualUrl?: string;
  serialNumber?: string;
  color?: string;
  capacity?: string;
  purchaseHistoryStore?: string;
  paymentMethod?: string;
  nextMaintenanceDate?: string; // YYYY-MM-DD
  createdAt: number;
  updatedAt: number;
  maintenanceLog?: MaintenanceLogEntry[];
}

export interface MiniNodeUser {
  id: string;
  username: string;
  isGuest: boolean;
}

export interface SaveSlot {
  id: string;
  label: string;
  savedAt: number;
  version: number;
  run: {
    items: InventoryItem[];
    rooms: string[];
    selectedRoom: string;
    view: "dashboard" | "inventory" | "add-item" | "item-detail";
    selectedItemId?: string;
  };
}

export interface MiniNodeNotification {
  id: string;
  title: string;
  body: string;
  url?: string;
  timestamp: number;
  read: boolean;
}
