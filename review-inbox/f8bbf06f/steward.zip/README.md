# Neue App – Garantie- & Haushaltsinventar

Eine App für MiniNode (`shared-account`), um Haushaltsgegenstände zu erfassen, Kaufbelege zu digitalisieren, Garantien und deren Geltungsbereich nachzuverfolgen und den Wert für Versicherungsansprüche zu dokumentieren.

## Funktionen

1. **Garantien & Geltungsbereich**: Behalte den Überblick über alle Garantien, Ablaufdaten und wo diese gelten (z. B. Herstellergarantie, PlusSchutz, AppleCare+).
2. **Kaufbelege digitalisieren**: Fotografiere Rechnungen oder lade PDFs/Bilder hoch (`mn.files`), um sie bei Garantiefällen oder beim Wiederverkauf sofort griffbereit zu haben.
3. **Haushaltswert & Versicherung**: Erfasse Kaufpreise (in Cent gespeichert, deutsch formatiert) und gleiche den Gesamtwert mit deiner Versicherungssumme ab.
4. **Mehrere Haushalte & Benutzer**: Erstelle Haushalte (z. B. Hauptwohnung, Ferienhaus), lade MiniNode-Mitglieder mit Rollen (Admin, Bearbeiter, Leser) ein.
5. **Besitzerzuweisung & Filter**: Weise Gegenstände Besitzern zu und filtere per Chip direkt nach dem Eigentümer.
6. **Vorschaubilder als Kacheln**: Jeder Gegenstand zeigt ein 4:3-Vorschaubild mit dem Namen und Raum darunter.
7. **Offline-Fähig**: Alle Daten werden über `mn.kv` lokal vorgehalten und automatisch bei bestehender Verbindung abgeglichen.
8. **Papierkorb & Rückgängig**: Gelöschte Gegenstände können sofort rückgängig gemacht oder aus dem Papierkorb wiederhergestellt werden.
9. **Import & Export**: JSON-Vollsicherung sowie CSV-Export und -Import.
10. **Druckansicht**: Native Browser-Druckansicht (`window.print()`).

## Gespeicherte Daten

- `item:<id>` (in `mn.kv`): Gegenstandsdaten, Preise in Cents, Garantiedaten, Geltungsbereich, Besitzer, Pfade zu Belegen und Fotos.
- `households:list` (in `mn.kv`): Liste der angelegten Haushalte und Mitglieder.
- `settings` (in `mn.kv`): Aktiver Haushalt, Versicherungssumme, Raum- und Kategorielisten.
- `fotos/<id>/...` und `belege/<id>/...` (in `mn.files`): Bilder und Dokumente.
