/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * MiniNode Platform SDK Client
 * Compliant with MiniNode app spec (specVersion 1)
 */

export interface MiniNodeUser {
  id: string;
  name?: string;
  email?: string;
  role?: 'admin' | 'trusted' | 'user';
}

export interface MiniNodePushSchedule {
  key: string;
  at: Date | string | number;
  title: string;
  path?: string;
}

export interface MiniNodeClient {
  auth: {
    requireLogin: () => Promise<MiniNodeUser>;
    role: () => Promise<'admin' | 'trusted' | 'user'>;
  };
  kv: {
    get: <T = any>(key: string, scope?: string) => Promise<T | null>;
    set: <T = any>(key: string, value: T, scope?: string) => Promise<void>;
    list: <T = any>(prefix?: string, scope?: string) => Promise<{ key: string; value: T }[]>;
    delete: (key: string, scope?: string) => Promise<void>;
  };
  files: {
    upload: (path: string, blob: Blob | File, options?: { contentType?: string; shared?: boolean }) => Promise<{ path: string; size: number }>;
    url: (path: string) => Promise<string>;
    list: (prefix?: string) => Promise<string[]>;
    delete: (path: string) => Promise<void>;
  };
  realtime: (channel: string) => {
    on: (type: string, filter: any, handler: (payload: any) => void) => any;
    subscribe: () => () => void;
    broadcast: (event: string, payload: any) => Promise<void>;
  };
  notify: (title: string, message: string, path?: string) => Promise<void>;
  push: {
    schedule: (params: MiniNodePushSchedule) => Promise<void>;
    cancel: (key: string) => Promise<void>;
  };
  offline: {
    online: () => boolean;
    pending: () => Promise<number>;
    onChange: (cb: (online: boolean) => void) => () => void;
    onSynced: (cb: () => void) => () => void;
  };
}

// In-browser / Offline Storage Fallback using IndexedDB for seamless preview & offline compliance
class LocalMiniNodeShim implements MiniNodeClient {
  private user: MiniNodeUser = {
    id: "user-owner",
    name: "Haushalt Eigentümer",
    email: "owner@mininode.local",
    role: "admin"
  };

  private memoryKv = new Map<string, any>();
  private fileUrls = new Map<string, string>();
  private onlineStatus = typeof navigator !== 'undefined' ? navigator.onLine : true;
  private onlineListeners: ((online: boolean) => void)[] = [];
  private syncedListeners: (() => void)[] = [];
  private broadcastChannels = new Map<string, Set<(payload: any) => void>>();

  constructor() {
    if (typeof window !== 'undefined') {
      window.addEventListener('online', () => {
        this.onlineStatus = true;
        this.onlineListeners.forEach(cb => cb(true));
        this.syncedListeners.forEach(cb => cb());
      });
      window.addEventListener('offline', () => {
        this.onlineStatus = false;
        this.onlineListeners.forEach(cb => cb(false));
      });
      // Load initial offline KV cache if stored
      try {
        const raw = localStorage.getItem("mn_kv_cache");
        if (raw) {
          const parsed = JSON.parse(raw);
          for (const [k, v] of Object.entries(parsed)) {
            this.memoryKv.set(k, v);
          }
        }
      } catch (e) {
        // ignore
      }
    }
  }

  private persistCache() {
    if (typeof localStorage !== 'undefined') {
      try {
        const obj: Record<string, any> = {};
        for (const [k, v] of this.memoryKv.entries()) {
          obj[k] = v;
        }
        localStorage.setItem("mn_kv_cache", JSON.stringify(obj));
      } catch (e) {
        // ignore
      }
    }
  }

  auth = {
    requireLogin: async (): Promise<MiniNodeUser> => {
      return this.user;
    },
    role: async (): Promise<'admin' | 'trusted' | 'user'> => {
      return this.user.role || 'admin';
    }
  };

  kv = {
    get: async <T = any>(key: string, _scope?: string): Promise<T | null> => {
      return this.memoryKv.has(key) ? (this.memoryKv.get(key) as T) : null;
    },
    set: async <T = any>(key: string, value: T, _scope?: string): Promise<void> => {
      this.memoryKv.set(key, value);
      this.persistCache();
    },
    list: async <T = any>(prefix = "", _scope?: string): Promise<{ key: string; value: T }[]> => {
      const results: { key: string; value: T }[] = [];
      for (const [key, value] of this.memoryKv.entries()) {
        if (!prefix || key.startsWith(prefix)) {
          results.push({ key, value: value as T });
        }
      }
      return results;
    },
    delete: async (key: string, _scope?: string): Promise<void> => {
      this.memoryKv.delete(key);
      this.persistCache();
    }
  };

  files = {
    upload: async (path: string, blob: Blob | File): Promise<{ path: string; size: number }> => {
      const url = URL.createObjectURL(blob);
      this.fileUrls.set(path, url);
      return { path, size: blob.size };
    },
    url: async (path: string): Promise<string> => {
      if (this.fileUrls.has(path)) {
        return this.fileUrls.get(path)!;
      }
      return path;
    },
    list: async (prefix = ""): Promise<string[]> => {
      return Array.from(this.fileUrls.keys()).filter(k => !prefix || k.startsWith(prefix));
    },
    delete: async (path: string): Promise<void> => {
      const existing = this.fileUrls.get(path);
      if (existing && existing.startsWith("blob:")) {
        URL.revokeObjectURL(existing);
      }
      this.fileUrls.delete(path);
    }
  };

  realtime = (channel: string) => {
    return {
      on: (_type: string, _filter: any, handler: (payload: any) => void) => {
        if (!this.broadcastChannels.has(channel)) {
          this.broadcastChannels.set(channel, new Set());
        }
        this.broadcastChannels.get(channel)!.add(handler);
        return {
          subscribe: () => () => {
            this.broadcastChannels.get(channel)?.delete(handler);
          }
        };
      },
      subscribe: () => () => {},
      broadcast: async (_event: string, payload: any) => {
        this.broadcastChannels.get(channel)?.forEach(fn => fn({ payload }));
      }
    };
  };

  notify = async (title: string, message: string, _path?: string): Promise<void> => {
    if (typeof window !== 'undefined' && (window as any).mnui?.toast) {
      (window as any).mnui.toast(`${title}: ${message}`);
    }
  };

  push = {
    schedule: async (params: MiniNodePushSchedule): Promise<void> => {
      console.log("[MiniNode push.schedule]", params);
    },
    cancel: async (key: string): Promise<void> => {
      console.log("[MiniNode push.cancel]", key);
    }
  };

  offline = {
    online: (): boolean => {
      return this.onlineStatus;
    },
    pending: async (): Promise<number> => {
      return 0;
    },
    onChange: (cb: (online: boolean) => void): (() => void) => {
      this.onlineListeners.push(cb);
      cb(this.onlineStatus);
      return () => {
        this.onlineListeners = this.onlineListeners.filter(l => l !== cb);
      };
    },
    onSynced: (cb: () => void): (() => void) => {
      this.syncedListeners.push(cb);
      return () => {
        this.syncedListeners = this.syncedListeners.filter(l => l !== cb);
      };
    }
  };
}

let mnInstance: MiniNodeClient | null = null;

export async function getMiniNode(): Promise<MiniNodeClient> {
  if (mnInstance) return mnInstance;

  // Check if native MiniNode SDK is provided on window
  const w = typeof window !== 'undefined' ? (window as any) : null;
  if (w?.mininode?.mininode) {
    try {
      const native = await w.mininode.mininode();
      if (native && native.kv && native.auth) {
        mnInstance = native;
        return native;
      }
    } catch (e) {
      console.warn("Could not connect to native mininode(), using fallback shim", e);
    }
  }

  mnInstance = new LocalMiniNodeShim();
  return mnInstance;
}
